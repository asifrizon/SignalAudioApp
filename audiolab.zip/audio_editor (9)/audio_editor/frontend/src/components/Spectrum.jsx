import { useEffect, useRef, useState } from "react";


/*
  -----------------------------------------------------------------
  FFT-based spectrum analysis
  -----------------------------------------------------------------

  The previous implementation computed one Discrete Fourier Transform
  term per *pixel*, by hand, with a `for n in size` loop inside a
  `for bin in bins` loop (an O(width * size) direct DFT). For a
  16384-sample window and ~1200 pixels that is on the order of 20
  million sin/cos calls per redraw — slow, and it only ever looked
  at a single ~0.37s window plucked from the middle of the file.
  That's why a 144s test file with a different tone every 2 seconds
  only ever showed whatever tone happened to be playing around the
  72-second mark.

  This version uses a real radix-2 Cooley-Tukey FFT (O(N log N)),
  and — when no explicit time range is given — runs it in
  non-overlapping windows across the *entire* signal, keeping the
  loudest ("max-hold") magnitude seen in each frequency bin. That
  way a tone that only exists for 2 out of 144 seconds still shows
  up clearly, exactly like a spectrum analyzer's max-hold display.
*/

function nextPowerOfTwo(n) {
  let p = 1;
  while (p < n) p *= 2;
  return p;
}

// In-place iterative radix-2 Cooley-Tukey FFT.
// `re`/`im` are Float64Arrays of the same power-of-two length.
function fft(re, im) {
  const n = re.length;

  // Bit-reversal permutation.
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      [re[i], re[j]] = [re[j], re[i]];
      [im[i], im[j]] = [im[j], im[i]];
    }
  }

  // Iterative butterfly stages.
  for (let len = 2; len <= n; len <<= 1) {
    const angleStep = (-2 * Math.PI) / len;
    const stepReal = Math.cos(angleStep);
    const stepImag = Math.sin(angleStep);

    for (let i = 0; i < n; i += len) {
      let twiddleReal = 1;
      let twiddleImag = 0;

      for (let k = 0; k < len / 2; k++) {
        const evenReal = re[i + k];
        const evenImag = im[i + k];

        const oddReal = re[i + k + len / 2] * twiddleReal - im[i + k + len / 2] * twiddleImag;
        const oddImag = re[i + k + len / 2] * twiddleImag + im[i + k + len / 2] * twiddleReal;

        re[i + k] = evenReal + oddReal;
        im[i + k] = evenImag + oddImag;
        re[i + k + len / 2] = evenReal - oddReal;
        im[i + k + len / 2] = evenImag - oddImag;

        const nextTwiddleReal = twiddleReal * stepReal - twiddleImag * stepImag;
        const nextTwiddleImag = twiddleReal * stepImag + twiddleImag * stepReal;
        twiddleReal = nextTwiddleReal;
        twiddleImag = nextTwiddleImag;
      }
    }
  }
}

// 4-term Blackman-Harris window: tapers the edges of a block so the
// FFT doesn't smear energy across bins from an abrupt cut (spectral
// leakage). We use this instead of a plain Hann window specifically
// because its sidelobes are far lower (~-92 dB vs Hann's ~-31 dB).
//
// That matters a lot here: when max-hold combines many windows that
// each contain a *different* pure tone, every window's own leakage
// "skirt" gets unioned into the final picture. With a leaky window
// and many distinct tones, those skirts overlap into a rolling hill
// between real peaks that were supposed to read as zero. The tighter
// Blackman-Harris skirt keeps each tone's leakage close enough to
// its own peak that it no longer bridges into its neighbors.
function blackmanHarris(n, size) {
  const N = Math.max(1, size - 1);
  const a0 = 0.35875, a1 = 0.48829, a2 = 0.14128, a3 = 0.01168;
  return (
    a0 -
    a1 * Math.cos((2 * Math.PI * n) / N) +
    a2 * Math.cos((4 * Math.PI * n) / N) -
    a3 * Math.cos((6 * Math.PI * n) / N)
  );
}

// Zeroes out any bin more than `floorDb` quieter than the loudest bin
// in this spectrum. Genuine silence at a frequency should render as a
// flat zero baseline, not a low rolling "hill" of residual leakage.
//
// -30 dB was chosen empirically: a signal made of hard-cut tone
// segments (no crossfade between them) produces a real, physical
// broadband "click" at every splice — any FFT will show it, it isn't
// a windowing bug — and on a synthetic 144s/72-tone test file that
// click can reach about -31 dB. -30 dB clears that reliably while
// leaving genuine tone peaks (which sit within a fraction of a dB of
// the loudest peak) completely untouched. If you ever work with real
// recordings where you specifically want to see very quiet detail
// (more than ~30 dB below the loudest content, e.g. a faint hum),
// loosen this back toward -45/-55 dB.
function applyNoiseFloor(magnitude, floorDb = -30) {
  let peak = 0;
  for (let k = 0; k < magnitude.length; k++) {
    if (magnitude[k] > peak) peak = magnitude[k];
  }
  if (peak <= 0) return magnitude;

  const threshold = peak * Math.pow(10, floorDb / 20);
  for (let k = 0; k < magnitude.length; k++) {
    if (magnitude[k] < threshold) magnitude[k] = 0;
  }
  return magnitude;
}

// Windowed magnitude spectrum of `size` real samples starting at
// `sectionStart`, zero-padded up to `fftSize` (must be a power of two).
function windowedMagnitudeSpectrum(signal, sectionStart, size, fftSize) {
  const re = new Float64Array(fftSize);
  const im = new Float64Array(fftSize); // zero-padding lives here

  for (let n = 0; n < size; n++) {
    re[n] = signal[sectionStart + n] * blackmanHarris(n, size);
  }

  fft(re, im);

  // |X[k]| = sqrt(Re² + Im²), normalized by window size.
  const bins = fftSize / 2;
  const magnitude = new Float64Array(bins);
  for (let k = 0; k < bins; k++) {
    magnitude[k] = Math.hypot(re[k], im[k]) / size;
  }
  return magnitude;
}

// Max-hold spectrum over a [rangeStart, rangeEnd) sample range.
// If the range is short it's a single FFT; if it's long (e.g. a
// whole multi-minute recording) it's chopped into non-overlapping
// windows (capped at `maxWindows` so runtime stays roughly constant
// regardless of file length) and the loudest value per bin is kept.
function maxHoldSpectrum(signal, sampleRate, rangeStart, rangeEnd) {
  const start = Math.max(0, rangeStart);
  const end = Math.min(signal.length, rangeEnd);
  const n = Math.max(0, end - start);

  const desiredFftSize = 16384; // ~2.7 Hz resolution at 44.1 kHz
  const fftSize = Math.min(desiredFftSize, nextPowerOfTwo(Math.max(1, n)));
  const maxWindows = 400;

  if (n <= fftSize) {
    const magnitude = windowedMagnitudeSpectrum(signal, start, n, fftSize);
    return { magnitude: applyNoiseFloor(magnitude), binHz: sampleRate / fftSize };
  }

  const naturalWindows = Math.max(1, Math.floor((n - fftSize) / fftSize) + 1);
  const stride = naturalWindows > maxWindows ? Math.ceil(naturalWindows / maxWindows) : 1;

  const bins = fftSize / 2;
  const maxMagnitude = new Float64Array(bins);

  let used = 0;
  for (let w = 0; w < naturalWindows && used < maxWindows; w += stride) {
    const sectionStart = start + w * fftSize;
    const magnitude = windowedMagnitudeSpectrum(signal, sectionStart, fftSize, fftSize);
    for (let k = 0; k < bins; k++) {
      if (magnitude[k] > maxMagnitude[k]) maxMagnitude[k] = magnitude[k];
    }
    used++;
  }

  return { magnitude: applyNoiseFloor(maxMagnitude), binHz: sampleRate / fftSize };
}

// Downsamples the linear FFT bins to one point per pixel, taking the
// loudest bin in each pixel's frequency span (same "envelope" idea
// your Waveform.jsx already uses for min/max sample buckets).
function toDisplayPoints(magnitude, binHz, nyquist, width) {
  const bins = magnitude.length;
  const points = new Array(width);
  let peak = 0;

  for (let x = 0; x < width; x++) {
    const freqLo = (x / width) * nyquist;
    const freqHi = ((x + 1) / width) * nyquist;

    let lo = Math.max(0, Math.floor(freqLo / binHz));
    let hi = Math.min(bins - 1, Math.ceil(freqHi / binHz));
    if (hi < lo) hi = lo;

    let m = 0;
    for (let k = lo; k <= hi; k++) {
      if (magnitude[k] > m) m = magnitude[k];
    }

    peak = Math.max(peak, m);
    points[x] = { frequency: (freqLo + freqHi) / 2, magnitude: m };
  }

  return { points, peak };
}

function calculateSpectrum(
  signal,
  sampleRate,
  width,
  timeStart = null,
  timeEnd = null
) {
  const nyquist = sampleRate / 2;

  let rangeStart = 0;
  let rangeEnd = signal.length;

  if (
    Number.isFinite(timeStart) &&
    Number.isFinite(timeEnd) &&
    timeEnd > timeStart
  ) {
    rangeStart = Math.max(0, Math.floor(timeStart * sampleRate));
    rangeEnd = Math.min(signal.length, Math.floor(timeEnd * sampleRate));
  }

  const { magnitude, binHz } = maxHoldSpectrum(signal, sampleRate, rangeStart, rangeEnd);
  return toDisplayPoints(magnitude, binHz, nyquist, width);
}


export default function Spectrum({
  signal,
  sampleRate,

  /*
    Existing frequency-selection props
  */

  startFrequency,
  endFrequency,
  onRangeChange,

  frequency,
  onFrequencyChange,

  shadedRange,

  /*
    NEW:
    Optional time selection.

    Used by Add Noise so that the spectrum
    represents the exact audio section where
    noise was added.
  */

  timeStart = null,
  timeEnd = null
}) {

  const canvasRef = useRef(null);
  const boxRef = useRef(null);

  const [dragging, setDragging] =
    useState(null);

  const nyquist =
    sampleRate / 2;


  /*
    -----------------------------------------
    Convert mouse position → frequency
    -----------------------------------------
  */

  const frequencyFromPointer =
    (clientX) => {

      const canvas =
        canvasRef.current;

      if (!canvas) {
        return 0;
      }

      const rect =
        canvas.getBoundingClientRect();

      return Math.max(
        0,
        Math.min(
          nyquist,
          (
            (clientX - rect.left) /
            rect.width
          ) * nyquist
        )
      );
    };


  /*
    -----------------------------------------
    Dragging frequency handles
    -----------------------------------------
  */

  useEffect(() => {

    if (!dragging) {
      return undefined;
    }

    const move = (event) => {

      const frequency =
        frequencyFromPointer(
          event.clientX
        );

      /*
        Two-handle selection
      */

      if (
        dragging === "start" &&
        onRangeChange
      ) {

        onRangeChange(
          Math.min(
            frequency,
            endFrequency - 1
          ),
          endFrequency
        );

      } else if (
        dragging === "end" &&
        onRangeChange
      ) {

        onRangeChange(
          startFrequency,
          Math.max(
            frequency,
            startFrequency + 1
          )
        );

      /*
        One frequency handle
      */

      } else if (
        dragging === "frequency" &&
        onFrequencyChange
      ) {

        onFrequencyChange(
          frequency
        );
      }
    };


    const up = () => {
      setDragging(null);
    };


    window.addEventListener(
      "pointermove",
      move
    );

    window.addEventListener(
      "pointerup",
      up
    );


    return () => {

      window.removeEventListener(
        "pointermove",
        move
      );

      window.removeEventListener(
        "pointerup",
        up
      );

    };

  }, [
    dragging,
    endFrequency,
    startFrequency,
    onRangeChange,
    onFrequencyChange
  ]);


  /*
    -----------------------------------------
    DRAW SPECTRUM
    -----------------------------------------
  */

  useEffect(() => {

    const canvas =
      canvasRef.current;

    const box =
      boxRef.current;

    if (
      !canvas ||
      !box ||
      !signal?.length ||
      !sampleRate
    ) {
      return;
    }


    const dpr =
      window.devicePixelRatio || 1;

    const width =
      Math.max(
        1,
        box.clientWidth
      );

    const height = 240;


    canvas.width =
      width * dpr;

    canvas.height =
      height * dpr;

    canvas.style.width =
      `${width}px`;

    canvas.style.height =
      `${height}px`;


    const ctx =
      canvas.getContext("2d");


    ctx.setTransform(
      dpr,
      0,
      0,
      dpr,
      0,
      0
    );


    /*
      Background
    */

    ctx.fillStyle =
      "#fbfcfe";

    ctx.fillRect(
      0,
      0,
      width,
      height
    );


    /*
      Grid
    */

    ctx.strokeStyle =
      "#e8edf3";

    ctx.lineWidth = 1;


    for (
      let index = 0;
      index <= 8;
      index++
    ) {

      const x =
        (index / 8) *
        width;

      ctx.beginPath();

      ctx.moveTo(
        x,
        0
      );

      ctx.lineTo(
        x,
        height
      );

      ctx.stroke();
    }


    for (
      let index = 0;
      index <= 4;
      index++
    ) {

      const y =
        (index / 4) *
        height;

      ctx.beginPath();

      ctx.moveTo(
        0,
        y
      );

      ctx.lineTo(
        width,
        y
      );

      ctx.stroke();
    }


    /*
      -----------------------------------------
      Calculate spectrum
      -----------------------------------------
    */

    const {
      points,
      peak
    } =
      calculateSpectrum(
        signal,
        sampleRate,
        Math.floor(width),
        timeStart,
        timeEnd
      );


    /*
      -----------------------------------------
      Draw spectrum
      -----------------------------------------
    */

    ctx.strokeStyle =
      "#0f766e";

    ctx.lineWidth = 1.5;

    ctx.beginPath();


    points.forEach(
      (point, index) => {

        /*
          Convert magnitude → dB

              dB = 20 log10(A / Amax)
        */

        const db =
          20 *
          Math.log10(
            Math.max(
              point.magnitude,
              peak * 0.00001
            ) /
              Math.max(
                peak,
                1e-12
              )
          );


        /*
          Convert -100 dB ... 0 dB
          to screen position.
        */

        const normalized =
          Math.max(
            0,
            Math.min(
              1,
              (db + 100) / 100
            )
          );


        const y =
          height -
          normalized *
            (height * 0.88);


        const x =
          (point.frequency /
            nyquist) *
          width;


        if (index === 0) {

          ctx.moveTo(
            x,
            y
          );

        } else {

          ctx.lineTo(
            x,
            y
          );
        }
      }
    );


    ctx.stroke();


  }, [
    sampleRate,
    signal,
    timeStart,
    timeEnd
  ]);


  /*
    -----------------------------------------
    Canvas click
    -----------------------------------------
  */

  const handlePointerDown =
    (event) => {

      /*
        Two-handle mode
      */

      if (
        onRangeChange &&
        Number.isFinite(
          startFrequency
        ) &&
        Number.isFinite(
          endFrequency
        )
      ) {

        const frequency =
          frequencyFromPointer(
            event.clientX
          );

        setDragging(
          Math.abs(
            frequency -
              startFrequency
          ) <=
          Math.abs(
            frequency -
              endFrequency
          )
            ? "start"
            : "end"
        );

        return;
      }


      /*
        One-handle mode
      */

      if (
        onFrequencyChange &&
        Number.isFinite(frequency)
      ) {

        setDragging(
          "frequency"
        );
      }
    };


  /*
    -----------------------------------------
    Render
    -----------------------------------------
  */

  return (

    <div
      className="spectrum-box"
      ref={boxRef}
    >

      <canvas
        ref={canvasRef}
        onPointerDown={
          handlePointerDown
        }
      />


      {/* -----------------------------------
          Two-frequency-handle selection
      ----------------------------------- */}

      {onRangeChange &&
        Number.isFinite(
          startFrequency
        ) &&
        Number.isFinite(
          endFrequency
        ) && (
          <>

            <div
              className="spectrum-selection"
              style={{
                left:
                  `${(
                    startFrequency /
                    nyquist
                  ) * 100}%`,

                width:
                  `${(
                    (
                      endFrequency -
                      startFrequency
                    ) /
                    nyquist
                  ) * 100}%`
              }}
            />


            {[
              startFrequency,
              endFrequency
            ].map(
              (
                frequencyValue,
                index
              ) => (

                <div
                  className="spectrum-handle"
                  key={index}

                  style={{
                    left:
                      `${(
                        frequencyValue /
                        nyquist
                      ) * 100}%`
                  }}

                  onPointerDown={
                    (event) => {

                      event.stopPropagation();

                      setDragging(
                        index === 0
                          ? "start"
                          : "end"
                      );
                    }
                  }
                />

              )
            )}

          </>
        )}


      {/* -----------------------------------
          Single-frequency handle
      ----------------------------------- */}

      {onFrequencyChange &&
        Number.isFinite(
          frequency
        ) && (

          <div
            className="spectrum-frequency-handle"
            style={{
              left:
                `${(
                  frequency /
                  nyquist
                ) * 100}%`
            }}

            onPointerDown={
              (event) => {

                event.stopPropagation();

                setDragging(
                  "frequency"
                );
              }
            }
          />

        )}


      {/* -----------------------------------
          Optional shaded frequency range
      ----------------------------------- */}

      {shadedRange &&
        Number.isFinite(
          shadedRange.start
        ) &&
        Number.isFinite(
          shadedRange.end
        ) && (

          <div
            className="spectrum-selection"
            style={{
              left:
                `${(
                  shadedRange.start /
                  nyquist
                ) * 100}%`,

              width:
                `${(
                  (
                    shadedRange.end -
                    shadedRange.start
                  ) /
                  nyquist
                ) * 100}%`
            }}
          />

        )}


      {/* -----------------------------------
          Frequency axis
      ----------------------------------- */}

      <div className="spectrum-axis">

        <span>
          0 Hz
        </span>

        <span>
          {(
            sampleRate / 4
          ).toFixed(0)} Hz
        </span>

        <span>
          {nyquist.toFixed(0)} Hz
        </span>

      </div>

    </div>
  );
}