
import { useState } from "react";

export default function BPM({ audioData, processing }) {
  const [result, setResult] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState("");

  const calculateBPM = async () => {
    if (!audioData?.signal?.length) {
      setError("Please upload a heartbeat audio file first.");
      return;
    }

    setError("");
    setResult(null);
    setAnalyzing(true);

    try {
      const response = await fetch(
        "http://localhost:5000/calculate-bpm",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            signal: audioData.signal,
            sample_rate: audioData.sample_rate,
          }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error || "BPM calculation failed."
        );
      }

      setResult(data);
    } catch (e) {
      setError(e.message);
    } finally {
      setAnalyzing(false);
    }
  };

  /*
   * Convert backend values safely to numbers.
   *
   * This is important because values such as beat_intervals
   * may arrive as strings instead of JavaScript Numbers.
   */
  const toNumber = (value) => {
    if (value === null || value === undefined || value === "") {
      return null;
    }

    const number = Number(value);

    return Number.isFinite(number) ? number : null;
  };

  const formatTime = (time) => {
    const number = toNumber(time);

    if (number === null) {
      return "--";
    }

    return `${number.toFixed(2)} s`;
  };

  const formatBPM = () => {
    const bpm = toNumber(result?.bpm);

    if (bpm === null) {
      return "--";
    }

    return Math.round(bpm);
  };

  const formatNumber = (value, decimals = 2, suffix = "") => {
    const number = toNumber(value);

    if (number === null) {
      return "--";
    }

    return `${number.toFixed(decimals)}${suffix}`;
  };

  const getBeatInterval = (index) => {
    if (
      index <= 0 ||
      !Array.isArray(result?.beat_intervals)
    ) {
      return null;
    }

    return toNumber(result.beat_intervals[index - 1]);
  };

  return (
    <div className="page-content bpm-page">

      {/* ------------------------------------------------ */}
      {/* Header */}
      {/* ------------------------------------------------ */}

      <div className="page-header">
        <div>
          <h1>Heartbeat BPM</h1>

          <p>
            Calculate heartbeats per minute from heartbeat audio
            using signal processing.
          </p>
        </div>
      </div>

      {/* ------------------------------------------------ */}
      {/* Analyze button */}
      {/* ------------------------------------------------ */}

      <div className="bpm-control-card">

        <div>
          <h2>Heartbeat Analysis</h2>

          <p>
            Upload a heartbeat recording and analyze the signal
            to detect individual beats and calculate BPM.
          </p>
        </div>

        <button
          className="primary-button"
          onClick={calculateBPM}
          disabled={
            analyzing ||
            processing ||
            !audioData?.signal?.length
          }
        >
          {analyzing
            ? "Analyzing Heartbeat..."
            : "Calculate BPM"}
        </button>

      </div>

      {/* ------------------------------------------------ */}
      {/* Error */}
      {/* ------------------------------------------------ */}

      {error && (
        <div className="error-message">
          {error}
        </div>
      )}

      {/* ------------------------------------------------ */}
      {/* BPM result */}
      {/* ------------------------------------------------ */}

      {result && (
        <>

          <div className="bpm-result-card">

            <div className="bpm-main-result">

              <span className="bpm-label">
                HEART RATE
              </span>

              <div className="bpm-value">
                {formatBPM()}
              </div>

              <span className="bpm-unit">
                BPM
              </span>

            </div>

            <div className="bpm-stat">

              <span className="bpm-stat-label">
                Detected Beats
              </span>

              <strong>
                {toNumber(result.number_of_beats) ?? "--"}
              </strong>

            </div>

            <div className="bpm-stat">

              <span className="bpm-stat-label">
                Average Interval
              </span>

              <strong>
                {formatNumber(
                  result.average_interval,
                  2,
                  " s"
                )}
              </strong>

            </div>

            <div className="bpm-stat">

              <span className="bpm-stat-label">
                Recording Duration
              </span>

              <strong>
                {formatNumber(
                  result.duration,
                  2,
                  " s"
                )}
              </strong>

            </div>

          </div>

          {/* -------------------------------------------- */}
          {/* Signal properties */}
          {/* -------------------------------------------- */}

          <div className="bpm-analysis-card">

            <h2>Signal Properties</h2>

            <div className="bpm-properties">

              <div className="bpm-property">

                <span>
                  Sample Rate
                </span>

                <strong>
                  {toNumber(result.sample_rate) ?? "--"} Hz
                </strong>

              </div>

              <div className="bpm-property">

                <span>
                  RMS
                </span>

                <strong>
                  {formatNumber(result.rms, 5)}
                </strong>

              </div>

              <div className="bpm-property">

                <span>
                  Maximum Amplitude
                </span>

                <strong>
                  {formatNumber(
                    result.maximum_amplitude,
                    5
                  )}
                </strong>

              </div>

              <div className="bpm-property">

                <span>
                  Detection Method
                </span>

                <strong>
                  Energy Peak Detection
                </strong>

              </div>

            </div>

          </div>

          {/* -------------------------------------------- */}
          {/* Detected beats */}
          {/* -------------------------------------------- */}

          <div className="bpm-analysis-card">

            <div className="bpm-section-heading">

              <div>
                <h2>Detected Heartbeats</h2>

                <p>
                  Peak locations detected from the heartbeat
                  energy envelope.
                </p>
              </div>

              <span className="beat-count">
                {toNumber(result.number_of_beats) ?? 0} beats
              </span>

            </div>

            {Array.isArray(result.beat_times) &&
            result.beat_times.length > 0 ? (

              <div className="heartbeat-list">

                {result.beat_times.map(
                  (time, index) => {

                    const interval =
                      getBeatInterval(index);

                    return (
                      <div
                        className="heartbeat-row"
                        key={`${time}-${index}`}
                      >

                        <div className="heartbeat-number">
                          {index + 1}
                        </div>

                        <div className="heartbeat-time">

                          <span>
                            Beat
                          </span>

                          <strong>
                            {formatTime(time)}
                          </strong>

                        </div>

                        <div className="heartbeat-interval">

                          <span>
                            Interval
                          </span>

                          <strong>
                            {interval !== null
                              ? `${interval.toFixed(2)} s`
                              : "—"}
                          </strong>

                        </div>

                      </div>
                    );
                  }
                )}

              </div>

            ) : (

              <div className="no-beats">
                No clear heartbeat peaks were detected.
              </div>

            )}

          </div>

          {/* -------------------------------------------- */}
          {/* Formula explanation */}
          {/* -------------------------------------------- */}

          <div className="bpm-formula-card">

            <h2>How BPM Was Calculated</h2>

            <div className="formula-step">

              <span>1</span>

              <div>
                <strong>
                  Detect heartbeat peaks
                </strong>

                <p>
                  The signal energy envelope is analyzed to
                  locate individual heartbeat events.
                </p>
              </div>

            </div>

            <div className="formula-step">

              <span>2</span>

              <div>
                <strong>
                  Calculate beat interval
                </strong>

                <p>
                  The time difference between consecutive
                  heartbeat peaks is calculated.
                </p>
              </div>

            </div>

            <div className="formula-step">

              <span>3</span>

              <div>
                <strong>
                  Calculate BPM
                </strong>

                <p className="formula">
                  BPM = 60 / Average Beat Interval
                </p>
              </div>

            </div>

          </div>

        </>
      )}

    </div>
  );
}

