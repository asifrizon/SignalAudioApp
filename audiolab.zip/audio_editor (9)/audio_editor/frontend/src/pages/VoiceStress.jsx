import React, { useState } from "react";
import { analyzeVoiceStress } from "../services/audioApi";

function MetricCard({ label, value, unit = "", hint }) {
  return (
    <div className="stress-metric-card">
      <div className="stress-metric-label">{label}</div>
      <div className="stress-metric-value">
        {value}
        {unit && <span>{unit}</span>}
      </div>
      {hint && <div className="stress-metric-hint">{hint}</div>}
    </div>
  );
}

function ScoreBar({ label, score }) {
  const value = Math.max(0, Math.min(100, Number(score) || 0));

  return (
    <div className="stress-score-row">
      <div className="stress-score-header">
        <span>{label}</span>
        <strong>{value.toFixed(0)}</strong>
      </div>
      <div className="stress-score-track">
        <div className="stress-score-fill" style={{ width: `${value}%` }} />
      </div>
    </div>
  );
}

function VoiceStress({ audioData, processing }) {
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleAnalyze = async () => {
    if (!audioData?.signal || !audioData?.sample_rate) {
      setError("Please upload a speech recording first.");
      return;
    }

    try {
      setLoading(true);
      setError("");
      setResult(null);

      const data = await analyzeVoiceStress(
        audioData.signal,
        audioData.sample_rate
      );

      setResult(data);
    } catch (err) {
      console.error("Voice Stress Error:", err);
      setError(err.message || "Voice stress analysis failed.");
    } finally {
      setLoading(false);
    }
  };

  const levelClass = (level) => {
    if (level === "Elevated") return "stress-high";
    if (level === "Moderate") return "stress-moderate";
    return "stress-low";
  };

  const score = Number(result?.stress_score || 0);
  const confidence = Number(result?.confidence || 0);
  const quality = Number(result?.data_quality?.score || 0);

  return (
    <div className="voice-stress-page">
      <div className="stress-page-header">
        <div>
          <h1>Voice Stress Analysis</h1>
          <p>
            Acoustic analysis of vocal patterns associated with stress and arousal.
          </p>
        </div>
        <div className="stress-method-badge">Professional acoustic analysis</div>
      </div>

      <div className="stress-info-banner">
        <strong>What this measures:</strong> pitch activation, vocal instability,
        phonation quality, energy changes and speech continuity. It does not determine
        a person's mental state or detect deception.
      </div>

      <div className="stress-audio-info">
        <div>
          <span>Recording</span>
          <strong>{audioData?.filename || "No audio loaded"}</strong>
        </div>
        <div>
          <span>Duration</span>
          <strong>
            {audioData?.duration ? `${audioData.duration.toFixed(2)} s` : "—"}
          </strong>
        </div>
        <div>
          <span>Sample rate</span>
          <strong>{audioData?.sample_rate ? `${audioData.sample_rate} Hz` : "—"}</strong>
        </div>
      </div>

      <button
        className="stress-analyze-button"
        onClick={handleAnalyze}
        disabled={!audioData || loading || processing}
      >
        {loading ? "Analyzing acoustic features…" : "Analyze Voice"}
      </button>

      {error && <div className="stress-error">{error}</div>}

      {result && (
        <div className="stress-result">
          <div className={`stress-summary ${levelClass(result.stress_level)}`}>
            <div>
              <div className="stress-summary-eyebrow">ACOUSTIC STRESS INDICATOR</div>
              <div className="stress-summary-level">{result.stress_level}</div>
              <p>
                Score <strong>{score.toFixed(1)}</strong> / 100
              </p>
            </div>
            <div className="stress-score-ring">
              <span>{score.toFixed(0)}</span>
              <small>/100</small>
            </div>
          </div>

          <div className="stress-quality-grid">
            <MetricCard
              label="Analysis confidence"
              value={confidence.toFixed(0)}
              unit="%"
              hint="Based on speech coverage, pitch coverage and consistency"
            />
            <MetricCard
              label="Recording quality"
              value={quality.toFixed(0)}
              unit="%"
              hint="Higher values mean cleaner, more usable acoustic evidence"
            />
            <MetricCard
              label="Speech activity"
              value={Number(result.data_quality.speech_activity_percent).toFixed(1)}
              unit="%"
              hint="Portion of the recording classified as speech"
            />
            <MetricCard
              label="Pitch coverage"
              value={Number(result.data_quality.pitch_coverage_percent).toFixed(1)}
              unit="%"
              hint="Frames with a reliable fundamental-frequency estimate"
            />
          </div>

          <section className="stress-section">
            <div className="stress-section-title">
              <h2>Primary indicators</h2>
              <span>0 = lower acoustic signal · 100 = stronger signal</span>
            </div>
            <div className="stress-score-list">
              <ScoreBar label="Voice instability" score={result.feature_scores.voice_instability} />
              <ScoreBar label="Pitch activation" score={result.feature_scores.pitch} />
              <ScoreBar label="Energy change" score={result.feature_scores.energy_change} />
              <ScoreBar label="Spectral tension" score={result.feature_scores.spectral_tension} />
              <ScoreBar label="Speech fragmentation" score={result.feature_scores.speech_fragmentation} />
            </div>
          </section>

          {result.drivers?.length > 0 && (
            <section className="stress-section">
              <div className="stress-section-title">
                <h2>Strongest observed signals</h2>
              </div>
              <div className="stress-drivers">
                {result.drivers.map((driver) => (
                  <div className="stress-driver" key={driver.feature}>
                    <span>{driver.feature}</span>
                    <strong>{Number(driver.score).toFixed(0)}</strong>
                  </div>
                ))}
              </div>
            </section>
          )}

          <section className="stress-section">
            <div className="stress-section-title">
              <h2>Acoustic measurements</h2>
              <span>Measured from the uploaded recording</span>
            </div>
            <div className="stress-metrics-grid">
              <MetricCard label="Mean pitch" value={Number(result.features.mean_pitch_hz).toFixed(1)} unit="Hz" />
              <MetricCard label="Pitch variation" value={Number(result.features.pitch_variation_hz).toFixed(1)} unit="Hz" />
              <MetricCard label="Jitter" value={Number(result.features.jitter_percent).toFixed(2)} unit="%" hint="Cycle-to-cycle pitch-period variation" />
              <MetricCard label="Shimmer" value={Number(result.features.shimmer_percent).toFixed(2)} unit="%" hint="Cycle-to-cycle amplitude variation" />
              <MetricCard label="HNR" value={Number(result.features.hnr_db).toFixed(1)} unit="dB" hint="Harmonic-to-noise ratio" />
              <MetricCard label="Pause ratio" value={(Number(result.features.pause_ratio) * 100).toFixed(1)} unit="%" />
              <MetricCard label="Spectral centroid" value={Number(result.features.spectral_centroid_hz).toFixed(0)} unit="Hz" />
              <MetricCard label="Spectral slope" value={Number(result.features.spectral_slope_db_per_octave).toFixed(1)} unit="dB/oct" />
            </div>
          </section>

          <div className="stress-method">
            <strong>Method:</strong> {result.method}
          </div>

          <div className="stress-warning">
            <strong>Interpretation note:</strong> {result.warning}
          </div>
        </div>
      )}
    </div>
  );
}

export default VoiceStress;
