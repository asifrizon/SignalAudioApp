
import { useState } from "react";

import Spectrum from "../components/Spectrum";

export default function BirdID({
  audioData,
  onProcess,
  processing,
  onAccept,
}) {
  const [result, setResult] = useState(null);
  const [notice, setNotice] = useState("");
  const [segmentAction, setSegmentAction] = useState(null);

  const analyze = async () => {
    setNotice("");

    const r = await onProcess(
      "/identify-bird",
      {}
    );

    if (r) {
      setResult(r);
    } else {
      // onProcess already surfaced the real error
      // in the top-level banner.
      setResult(null);
    }
  };

  // ==========================================================
  // PLAY ONE DETECTED SEGMENT
  // ==========================================================

  const createWavBuffer = (
    signal,
    sampleRate
  ) => {
    const buffer = new ArrayBuffer(
      44 + signal.length * 2
    );

    const view = new DataView(buffer);

    const writeString = (
      offset,
      text
    ) => {
      for (
        let i = 0;
        i < text.length;
        i++
      ) {
        view.setUint8(
          offset + i,
          text.charCodeAt(i)
        );
      }
    };

    writeString(0, "RIFF");

    view.setUint32(
      4,
      36 + signal.length * 2,
      true
    );

    writeString(8, "WAVE");

    writeString(12, "fmt ");

    view.setUint32(
      16,
      16,
      true
    );

    view.setUint16(
      20,
      1,
      true
    );

    view.setUint16(
      22,
      1,
      true
    );

    view.setUint32(
      24,
      sampleRate,
      true
    );

    view.setUint32(
      28,
      sampleRate * 2,
      true
    );

    view.setUint16(
      32,
      2,
      true
    );

    view.setUint16(
      34,
      16,
      true
    );

    writeString(36, "data");

    view.setUint32(
      40,
      signal.length * 2,
      true
    );

    for (
      let i = 0;
      i < signal.length;
      i++
    ) {
      const sample = Math.max(
        -1,
        Math.min(1, signal[i])
      );

      view.setInt16(
        44 + i * 2,
        sample < 0
          ? sample * 0x8000
          : sample * 0x7fff,
        true
      );
    }

    return buffer;
  };

  const playSegment = async (
    segment
  ) => {
    if (
      !audioData?.signal ||
      !audioData?.sample_rate
    ) {
      return;
    }

    const startSample = Math.floor(
      segment.start_time *
        audioData.sample_rate
    );

    const endSample = Math.floor(
      segment.end_time *
        audioData.sample_rate
    );

    const segmentSignal =
      audioData.signal.slice(
        startSample,
        endSample
      );

    if (
      segmentSignal.length === 0
    ) {
      return;
    }

    try {
      const audioContext =
        new (
          window.AudioContext ||
          window.webkitAudioContext
        )();

      const wavBuffer =
        createWavBuffer(
          segmentSignal,
          audioData.sample_rate
        );

      const audioBuffer =
        await audioContext.decodeAudioData(
          wavBuffer
        );

      const source =
        audioContext.createBufferSource();

      source.buffer = audioBuffer;

      source.connect(
        audioContext.destination
      );

      source.start();

      source.onended = () => {
        audioContext.close();
      };
    } catch (error) {
      console.error(
        "Could not play segment:",
        error
      );

      setNotice(
        "Could not play this bird sound segment."
      );
    }
  };

  // ==========================================================
  // DELETE ONE BIRD SOUND SEGMENT
  // ==========================================================

  const deleteSegment = async (
    segment
  ) => {
    if (!audioData?.signal) {
      return;
    }

    const confirmed =
      window.confirm(
        `Delete bird sound segment ${
          segment.segment
        } (${segment.start_time.toFixed(
          2
        )}s – ${segment.end_time.toFixed(
          2
        )}s)?`
      );

    if (!confirmed) {
      return;
    }

    setSegmentAction(
      `delete-${segment.segment}`
    );

    setNotice("");

    try {
      const response =
        await fetch(
          "http://localhost:5000/delete-section",
          {
            method: "POST",

            headers: {
              "Content-Type":
                "application/json",
            },

            body: JSON.stringify({
              signal:
                audioData.signal,

              sample_rate:
                audioData.sample_rate,

              start_time:
                segment.start_time,

              end_time:
                segment.end_time,
            }),
          }
        );

      const data =
        await response.json();

      if (!response.ok) {
        throw new Error(
          data.error ||
            "Failed to delete bird sound."
        );
      }

      // Replace the current audio in App.jsx.
      if (onAccept) {
        onAccept({
          ...audioData,

          signal:
            data.signal,

          sample_rate:
            data.sample_rate,

          samples:
            data.samples,

          duration:
            data.duration,
        });
      }

      // Old analysis is no longer valid because
      // deleting one segment changes all later timings.
      setResult(null);

      setNotice(
        `Bird sound segment ${
          segment.segment
        } was deleted. Analyze the updated audio again.`
      );
    } catch (error) {
      console.error(
        "Failed to delete segment:",
        error
      );

      setNotice(
        error.message ||
          "Failed to delete bird sound."
      );
    } finally {
      setSegmentAction(null);
    }
  };

  const topMatch = result?.best_match;

const expectedRange =
  topMatch?.expected_frequency_range;

const shadedRange =
  expectedRange &&
  expectedRange.low != null &&
  expectedRange.high != null
    ? {
        start: expectedRange.low,
        end: expectedRange.high,
      }
    : result?.features &&
      result.features.bandwidth_low != null &&
      result.features.bandwidth_high != null
    ? {
        start: result.features.bandwidth_low,
        end: result.features.bandwidth_high,
      }
    : null;

  // Audio analysis calculated by backend
  const audioAnalysis =
    result?.audio_analysis;

  return (
    <div className="tool-page">

      {/* =================================================
          ANALYZE
      ================================================= */}

      <div className="tool-card controls-card">

        <h2>
          Bird call identification
        </h2>

        <p>
          Runs an STFT over the clip, detects
          call activity, extracts pitch and
          timing features, and matches them
          against a small reference library
          of common species.
        </p>

        <button
          className="primary-button"
          onClick={analyze}
          disabled={processing}
        >
          {processing
            ? "Analyzing…"
            : "Analyze bird call"}
        </button>

        {notice && (
          <p className="frequency-selection">
            {notice}
          </p>
        )}

      </div>

      {result && (
        <>

          {/* =================================================
              EXTRACTED FEATURES
          ================================================= */}

          <div className="tool-card">

            <span className="eyebrow">
              EXTRACTED FEATURES
            </span>

            <h2>
              What the signal looks like
            </h2>

            <p>
              {
                result.features
                  .num_calls_detected
              }{" "}
              call
              {result.features
                .num_calls_detected === 1
                ? ""
                : "s"}{" "}
              detected across{" "}
              {result.features
                .analyzed_duration
                .toFixed(2)}{" "}
              s of audio.
            </p>

            <div className="bird-feature-grid">

              <div className="bird-feature-item">
                <span>
                  Dominant frequency
                </span>

                <strong>
                  {result.features
                    .dominant_frequency
                    .toFixed(0)}{" "}
                  Hz
                </strong>
              </div>

              <div className="bird-feature-item">
                <span>
                  Bandwidth
                </span>

                <strong>
                  {result.features
                    .bandwidth_low
                    .toFixed(0)}
                  –
                  {result.features
                    .bandwidth_high
                    .toFixed(0)}{" "}
                  Hz
                </strong>
              </div>

              <div className="bird-feature-item">
                <span>
                  Spectral centroid
                </span>

                <strong>
                  {result.features
                    .spectral_centroid
                    .toFixed(0)}{" "}
                  Hz
                </strong>
              </div>

              <div className="bird-feature-item">
                <span>
                  Avg. call duration
                </span>

                <strong>
                  {result.features
                    .call_duration
                    .toFixed(2)}{" "}
                  s
                </strong>
              </div>

              <div className="bird-feature-item">
                <span>
                  Pulse rate
                </span>

                <strong>
                  {result.features
                    .pulse_rate
                    .toFixed(2)}{" "}
                  calls/s
                </strong>
              </div>

            </div>

          </div>


          {/* =================================================
              BIRD SOUND SEGMENTS
          ================================================= */}

          {result.bird_segments &&
            result.bird_segments.length > 0 && (

            <div className="tool-card">

              <span className="eyebrow">
                BIRD SOUND SEGMENTS
              </span>

              <h2>
                Individual bird sounds
              </h2>

              <p>
                Each detected sound is analyzed
                separately. Species shown here
                are possible matches, not
                guaranteed identifications.
              </p>

              <div className="bird-segment-identification-list">

                {result.bird_segments.map(
                  (segment) => {

                    const match =
                      segment.best_match;

                    return (
                      <div
                        className="bird-segment-identification-item"
                        key={segment.segment}
                      >

                        <div className="bird-segment-identification-header">

                          <div>

                            <span className="eyebrow">
                              SEGMENT{" "}
                              {segment.segment}
                            </span>

                            <h3>
                              {match
                                ? `Possible: ${match.common_name}`
                                : "Possible: Unknown bird"}
                            </h3>

                            {match && (
                              <em>
                                {
                                  match.scientific_name
                                }
                              </em>
                            )}

                          </div>

                          <div className="bird-segment-confidence">

                            {segment.confidence >
                            0
                              ? `${segment.confidence.toFixed(
                                  0
                                )}%`
                              : "No confident match"}

                          </div>

                        </div>


                        <div className="bird-segment-details">

                          <div>
                            <span>
                              Start
                            </span>

                            <strong>
                              {segment.start_time.toFixed(
                                2
                              )}{" "}
                              s
                            </strong>
                          </div>

                          <div>
                            <span>
                              End
                            </span>

                            <strong>
                              {segment.end_time.toFixed(
                                2
                              )}{" "}
                              s
                            </strong>
                          </div>

                          <div>
                            <span>
                              Duration
                            </span>

                            <strong>
                              {segment.duration.toFixed(
                                2
                              )}{" "}
                              s
                            </strong>
                          </div>

                          <div>
                            <span>
                              Frequency
                            </span>

                            <strong>
                              {segment.features
                                ? `${segment.features.dominant_frequency.toFixed(
                                    0
                                  )} Hz`
                                : "—"}
                            </strong>
                          </div>

                        </div>


                        {match && (
                          <p className="bird-segment-description">
                            {
                              match.sound_description
                            }
                          </p>
                        )}


                        <div className="bird-segment-actions">

                          <button
                            className="secondary-button"
                            onClick={() =>
                              playSegment(
                                segment
                              )
                            }
                          >
                            ▶ Play segment
                          </button>


                          <button
                            className="danger-button"
                            onClick={() =>
                              deleteSegment(
                                segment
                              )
                            }
                            disabled={
                              segmentAction ===
                              `delete-${segment.segment}`
                            }
                          >
                            {segmentAction ===
                            `delete-${segment.segment}`
                              ? "Deleting…"
                              : "Delete bird sound"}
                          </button>

                        </div>

                      </div>
                    );
                  }
                )}

              </div>

            </div>
          )}


          {/* =================================================
              AUDIO EVIDENCE
          ================================================= */}

          {audioAnalysis && (
            <div className="tool-card">

              <span className="eyebrow">
                AUDIO EVIDENCE
              </span>

              <h2>
                Frequency analysis
              </h2>

              <p>
                Frequency characteristics
                calculated directly from the
                uploaded audio using FFT.
              </p>

              <div className="bird-feature-grid">

                <div className="bird-feature-item">
                  <span>
                    Audio duration
                  </span>

                  <strong>
                    {audioAnalysis.duration.toFixed(
                      2
                    )}{" "}
                    s
                  </strong>
                </div>

                <div className="bird-feature-item">
                  <span>
                    Sampling rate
                  </span>

                  <strong>
                    {
                      audioAnalysis.sampling_rate
                    }{" "}
                    Hz
                  </strong>
                </div>

                <div className="bird-feature-item">
                  <span>
                    Dominant frequency
                  </span>

                  <strong>
                    {audioAnalysis.dominant_frequency.toFixed(
                      0
                    )}{" "}
                    Hz
                  </strong>
                </div>

                <div className="bird-feature-item">
                  <span>
                    Frequency range
                  </span>

                  <strong>
                    {audioAnalysis
                      .frequency_range[0]
                      .toFixed(0)}
                    {" – "}
                    {audioAnalysis
                      .frequency_range[1]
                      .toFixed(0)}
                    {" Hz"}
                  </strong>
                </div>

                <div className="bird-feature-item">
                  <span>
                    Sound segments
                  </span>

                  <strong>
                    {
                      audioAnalysis
                        .number_of_segments
                    }
                  </strong>
                </div>

              </div>


              {/* =================================================
                  FREQUENCY PEAKS
              ================================================= */}

              {audioAnalysis.peaks &&
                audioAnalysis.peaks.length >
                  0 && (

                <div className="bird-frequency-section">

                  <span className="eyebrow">
                    DETECTED FREQUENCY PEAKS
                  </span>

                  <div className="bird-frequency-list">

                    {audioAnalysis.peaks.map(
                      (
                        peak,
                        index
                      ) => (

                        <div
                          className="bird-frequency-item"
                          key={index}
                        >

                          <div>

                            <span>
                              Peak{" "}
                              {index + 1}
                            </span>

                            <strong>
                              {peak.frequency.toFixed(
                                0
                              )}{" "}
                              Hz
                            </strong>

                          </div>

                          <span>
                            Magnitude:{" "}
                            {peak.magnitude.toFixed(
                              2
                            )}
                          </span>

                        </div>

                      )
                    )}

                  </div>

                </div>
              )}


              {/* =================================================
                  SOUND SEGMENTS
              ================================================= */}

              {audioAnalysis.segments &&
                audioAnalysis.segments.length >
                  0 && (

                <div className="bird-frequency-section">

                  <span className="eyebrow">
                    DETECTED SOUND SEGMENTS
                  </span>

                  <div className="bird-segment-list">

                    {audioAnalysis.segments.map(
                      (segment) => (

                        <div
                          className="bird-segment-item"
                          key={segment.segment}
                        >

                          <div>
                            <span>
                              Segment
                            </span>

                            <strong>
                              {segment.segment}
                            </strong>
                          </div>

                          <div>
                            <span>
                              Start
                            </span>

                            <strong>
                              {segment.start_time.toFixed(
                                2
                              )}{" "}
                              s
                            </strong>
                          </div>

                          <div>
                            <span>
                              End
                            </span>

                            <strong>
                              {segment.end_time.toFixed(
                                2
                              )}{" "}
                              s
                            </strong>
                          </div>

                          <div>
                            <span>
                              Duration
                            </span>

                            <strong>
                              {segment.duration.toFixed(
                                2
                              )}{" "}
                              s
                            </strong>
                          </div>

                          <div>
                            <span>
                              Dominant frequency
                            </span>

                            <strong>
                              {segment.dominant_frequency.toFixed(
                                0
                              )}{" "}
                              Hz
                            </strong>
                          </div>

                        </div>
                      )
                    )}

                  </div>

                </div>
              )}

            </div>
          )}


          {/* =================================================
              SPECTRUM WITH MATCHED BAND HIGHLIGHTED
          ================================================= */}

          <div className="tool-card spectrum-card">

            <div>

              <span className="eyebrow">
                FREQUENCY DOMAIN
              </span>

              <h2>
                Spectrum
              </h2>

              <p>
                {topMatch
                  ? `Shaded region is the expected call band for the top match, ${topMatch.common_name}.`
                  : "Shaded region is the detected call's bandwidth."}
              </p>

            </div>

            <Spectrum
              signal={audioData.signal}
              sampleRate={
                audioData.sample_rate
              }
              shadedRange={
                shadedRange
              }
            />

          </div>


          {/* =================================================
              MATCH RESULTS
          ================================================= */}

          <div className="tool-card">

            <span className="eyebrow">
              MATCH RESULTS
            </span>

            <h2>
              {topMatch
                ? `Best match: ${topMatch.common_name}`
                : "No confident match"}
            </h2>

            <p>
              {topMatch
                ? `Scored against ${result.species_considered} reference species in the library.`
                : "The strongest match scored below the confidence threshold — treat these as rough leads, not an identification."}
            </p>

            <div className="bird-match-list">

              {result.matches.map(
                (
                  match,
                  index
                ) => (

                  <div
                    className={`bird-match-item ${
                      index === 0
                        ? "top"
                        : ""
                    }`}
                    key={
                      match.species_id
                    }
                  >

                    <div className="bird-match-head">

                      <div>

                        <strong>
                          {
                            match.common_name
                          }
                        </strong>

                        <em>
                          {
                            match.scientific_name
                          }
                        </em>

                      </div>

                      <span className="bird-confidence-value">
                        {match.confidence.toFixed(
                          0
                        )}
                        %
                      </span>

                    </div>

                    <div className="bird-confidence-bar">

                      <div
                        className="bird-confidence-fill"
                        style={{
                          width: `${match.confidence}%`,
                        }}
                      />

                    </div>

                    <p>
                      {
                        match.sound_description
                      }
                    </p>

                  </div>
                )
              )}

            </div>

          </div>

        </>
      )}

    </div>
  );
}

