# noise_canceller.py
"""
Realistic background-noise reduction for bird recordings.

This version uses spectral gating through the `noisereduce` package.
The goal is not to make the recording unnaturally silent. Instead it
reduces continuous/slowly changing background noise while preserving
bird-call harmonics and short calls.

Public API is unchanged:
    remove_background_noise(signal, sample_rate)
"""

import numpy as np

try:
    import noisereduce as nr
except ImportError as exc:
    raise ImportError(
        "This noise canceller requires 'noisereduce'. "
        "Install it with: pip install noisereduce"
    ) from exc

try:
    from scipy.signal import butter, sosfiltfilt
except ImportError as exc:
    raise ImportError(
        "This noise canceller requires 'scipy'. "
        "Install it with: pip install scipy"
    ) from exc


# ============================================================
# HELPERS
# ============================================================

def _to_mono(signal):
    """Convert mono/stereo input to a 1-D float64 signal."""
    x = np.asarray(signal, dtype=np.float64)

    if x.ndim == 0:
        x = x.reshape(1)
    elif x.ndim > 1:
        # Works for both (samples, channels) and common (channels, samples)
        # layouts by choosing the dimension with the most samples.
        if x.shape[0] < x.shape[-1]:
            x = np.mean(x, axis=0)
        else:
            x = np.mean(x, axis=1)

    return x.reshape(-1)


def _remove_dc(signal):
    """Remove DC offset without changing the signal's dynamics."""
    if len(signal) == 0:
        return signal

    return signal - np.mean(signal)


def _remove_subsonic_rumble(signal, sample_rate):
    """
    Remove only very-low-frequency rumble.

    35 Hz is deliberately low so that normal bird-call fundamentals
    are not affected. This is useful for handling microphone handling
    noise, HVAC rumble, and wind-induced subsonic energy.
    """
    cutoff = 35.0

    if sample_rate <= cutoff * 2.2 or len(signal) < 32:
        return signal

    sos = butter(
        2,
        cutoff,
        btype="highpass",
        fs=sample_rate,
        output="sos",
    )

    try:
        return sosfiltfilt(
            sos,
            signal,
        )
    except ValueError:
        # Very short recordings can be shorter than filtfilt's padding.
        return signal


def _find_quiet_noise_clip(signal, sample_rate):
    """
    Find a likely background-only region automatically.

    This is used only as an optional noise reference. The actual
    denoiser still uses its own time-varying noise estimate, so one
    accidentally imperfect quiet section does not completely determine
    the result.

    Returns None if no useful clip can be found.
    """
    if len(signal) < int(sample_rate * 0.5):
        return None

    frame_length = max(
        256,
        int(sample_rate * 0.25),
    )
    hop = max(
        128,
        int(sample_rate * 0.125),
    )

    if len(signal) < frame_length:
        return None

    starts = range(
        0,
        len(signal) - frame_length + 1,
        hop,
    )

    candidates = []

    for start in starts:
        frame = signal[
            start:start + frame_length
        ]

        rms = np.sqrt(
            np.mean(frame ** 2)
            + 1e-12
        )

        # A robust measure that is less sensitive to a single click.
        peak = np.percentile(
            np.abs(frame),
            95,
        )

        candidates.append(
            (
                rms,
                peak,
                start,
            )
        )

    if not candidates:
        return None

    # First choose among the quietest ~20% of frames, then prefer
    # the one with the lowest high-percentile amplitude.
    candidates.sort(
        key=lambda item: item[0]
    )

    quiet_count = max(
        1,
        int(len(candidates) * 0.20),
    )

    quiet = candidates[:quiet_count]

    quiet.sort(
        key=lambda item: item[1]
    )

    _, _, start = quiet[0]

    # Keep the reference reasonably short. A shorter noise reference
    # reduces the chance of including an entire bird phrase.
    duration = min(
        1.0,
        len(signal) / sample_rate,
    )

    end = min(
        len(signal),
        start + int(duration * sample_rate),
    )

    clip = signal[start:end]

    if len(clip) < int(sample_rate * 0.25):
        return None

    return clip


def _safe_peak_normalize(signal, target=0.97):
    """Prevent clipping without changing loudness aggressively."""
    peak = float(
        np.max(
            np.abs(signal)
        )
    )

    if peak <= 1e-12:
        return signal

    if peak > target:
        return signal * (
            target / peak
        )

    return signal


def _measure_rms(signal):
    if len(signal) == 0:
        return 0.0

    return float(
        np.sqrt(
            np.mean(signal ** 2)
            + 1e-12
        )
    )


# ============================================================
# MAIN FUNCTION
# ============================================================

def remove_background_noise(
    signal,
    sample_rate,
):
    """
    Realistic adaptive background-noise removal.

    Best suited to:
      - fan / AC noise
      - room hiss
      - microphone self-noise
      - road/background ambience
      - moderate wind rumble
      - electrical background noise

    The algorithm deliberately avoids hard spectral gating because
    hard gates often produce the robotic/watery sound that is
    especially noticeable on bird calls.
    """
    if sample_rate <= 0:
        raise ValueError(
            "Invalid sample rate."
        )

    original = _to_mono(signal)

    if len(original) == 0:
        raise ValueError(
            "Audio signal is empty."
        )

    original_length = len(original)

    # Keep a normalized working copy. The original amplitude is restored
    # later without globally boosting the noise floor.
    original = _remove_dc(
        original
    )

    original_peak = float(
        np.max(
            np.abs(original)
        )
    )

    if original_peak <= 1e-12:
        return {
            "signal": original.tolist(),
            "sample_rate": int(sample_rate),
            "duration": original_length / sample_rate,
            "noise_frames_used": 0,
            "total_frames": 0,
            "noise_reduction_percent": 0.0,
            "method": "No signal to process",
        }

    working = (
        original / original_peak
    )

    # Remove only subsonic rumble before spectral denoising.
    working = _remove_subsonic_rumble(
        working,
        sample_rate,
    )

    # --------------------------------------------------------
    # Noise reference
    # --------------------------------------------------------
    #
    # We find a likely quiet region, but DO NOT use it as the
    # sole noise model. The non-stationary spectral gate tracks
    # the noise through the recording.
    noise_clip = _find_quiet_noise_clip(
        working,
        sample_rate,
    )

    # --------------------------------------------------------
    # Spectral denoising
    # --------------------------------------------------------
    #
    # Important tuning:
    #
    # prop_decrease < 1.0:
    #   prevents over-cleaning and metallic artifacts.
    #
    # time_constant_s:
    #   lets the noise estimate follow gradual changes.
    #
    # freq_mask_smooth_hz:
    #   smooths the mask so individual bird harmonics are not
    #   chopped into isolated bins.
    #
    # time_mask_smooth_ms:
    #   preserves short bird calls instead of making them fade
    #   in/out unnaturally.
    #
    # thresh_n_mult_nonstationary:
    #   keeps the gate from opening for every tiny fluctuation.
    #
    # 2048 FFT:
    #   gives substantially better frequency resolution for
    #   tonal bird calls than a very small FFT.
    #
    # 512 hop:
    #   provides smooth reconstruction.
    #
    denoised = nr.reduce_noise(
        y=working,
        sr=int(sample_rate),
        stationary=False,
        y_noise=noise_clip,
        prop_decrease=0.88,
        time_constant_s=1.5,
        freq_mask_smooth_hz=300,
        time_mask_smooth_ms=70,
        thresh_n_mult_nonstationary=1.5,
        sigmoid_slope_nonstationary=8,
        n_fft=2048,
        win_length=2048,
        hop_length=512,
        clip_noise_stationary=True,
        use_tqdm=False,
        n_jobs=1,
    )

    denoised = np.asarray(
        denoised,
        dtype=np.float64,
    ).reshape(-1)

    # noisereduce should preserve length, but enforce it because the
    # audio editor expects the exact original number of samples.
    if len(denoised) > original_length:
        denoised = denoised[
            :original_length
        ]
    elif len(denoised) < original_length:
        denoised = np.pad(
            denoised,
            (
                0,
                original_length
                - len(denoised),
            ),
        )

    # Remove tiny reconstruction DC offset.
    denoised -= np.mean(
        denoised
    )

    # --------------------------------------------------------
    # Realistic level preservation
    # --------------------------------------------------------
    #
    # Do NOT match full-recording RMS.
    #
    # The old implementation did this and could amplify residual
    # background noise again. We only restore a little level if
    # denoising made the useful signal noticeably quieter.
    #
    original_rms = _measure_rms(
        working
    )

    cleaned_rms = _measure_rms(
        denoised
    )

    if cleaned_rms > 1e-12:
        ratio = (
            original_rms
            / cleaned_rms
        )

        # Only a very modest correction.
        ratio = float(
            np.clip(
                ratio,
                0.96,
                1.06,
            )
        )

        denoised *= ratio

    # Final anti-clipping protection.
    denoised = _safe_peak_normalize(
        denoised,
        target=0.97,
    )

    # --------------------------------------------------------
    # Approximate noise reduction statistic
    # --------------------------------------------------------
    #
    # Compare the quietest 15% of original and processed frames.
    # This is only a UI metric; it is not used to control processing.
    frame_length = max(
        256,
        int(sample_rate * 0.032),
    )
    hop_length = max(
        128,
        int(sample_rate * 0.016),
    )

    def frame_rms(x):
        if len(x) < frame_length:
            x = np.pad(
                x,
                (
                    0,
                    frame_length - len(x),
                ),
            )

        count = (
            1
            + max(
                0,
                len(x) - frame_length
            ) // hop_length
        )

        values = []

        for i in range(count):
            start = i * hop_length
            frame = x[
                start:start + frame_length
            ]

            if len(frame) < frame_length:
                frame = np.pad(
                    frame,
                    (
                        0,
                        frame_length
                        - len(frame),
                    ),
                )

            values.append(
                np.sqrt(
                    np.mean(
                        frame ** 2
                    )
                    + 1e-12
                )
            )

        return np.asarray(
            values
        )

    before_rms = frame_rms(
        working
    )
    after_rms = frame_rms(
        denoised
    )

    noise_count = max(
        1,
        int(len(before_rms) * 0.15),
    )

    before_noise = float(
        np.median(
            np.sort(before_rms)[
                :noise_count
            ]
        )
    )

    after_noise = float(
        np.median(
            np.sort(after_rms)[
                :noise_count
            ]
        )
    )

    if before_noise > 1e-12:
        reduction_percent = (
            1.0
            - (
                after_noise
                / before_noise
            )
        ) * 100.0
    else:
        reduction_percent = 0.0

    reduction_percent = float(
        np.clip(
            reduction_percent,
            0.0,
            100.0,
        )
    )

    return {
        "signal": denoised.tolist(),

        "sample_rate": int(
            sample_rate
        ),

        "duration": (
            original_length
            / sample_rate
        ),

        "noise_frames_used": int(
            max(
                1,
                int(
                    len(before_rms)
                    * 0.15
                ),
            )
        ),

        "total_frames": int(
            len(before_rms)
        ),

        "noise_reduction_percent": round(
            reduction_percent,
            2,
        ),

        "method": (
            "Adaptive spectral gating with "
            "bird-call-preserving smoothing, "
            "subsonic rumble removal, and "
            "non-stationary noise tracking"
        ),
    }
