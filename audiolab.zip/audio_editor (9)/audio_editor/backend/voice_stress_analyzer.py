"""
Professional acoustic voice-stress analysis.

Important:
    This module estimates acoustic patterns that can be associated with
    vocal stress/arousal. It does NOT diagnose psychological stress,
    anxiety, deception, or a medical condition.

Design goals:
    * robust pitch tracking using Praat/Parselmouth
    * true Praat jitter/shimmer/HNR measurements
    * spectral tension / voice-quality descriptors
    * adaptive voice activity detection
    * robust statistics instead of raw frame averages
    * data-quality/confidence reporting
    * no emotion->stress shortcut and no uncalibrated ML classifier
    * interpretable contributing indicators
"""

from __future__ import annotations

import numpy as np
import librosa
import parselmouth
from parselmouth.praat import call
from scipy import signal as scipy_signal


EPS = 1e-10
MIN_DURATION_SEC = 2.0
MAX_ANALYSIS_SEC = 120.0
FRAME_SEC = 0.025
HOP_SEC = 0.010
PITCH_FLOOR = 60.0
PITCH_CEILING = 500.0


def _finite(values):
    values = np.asarray(values, dtype=float).reshape(-1)
    return values[np.isfinite(values)]


def _robust_median(values, default=0.0):
    values = _finite(values)
    return float(np.median(values)) if values.size else float(default)


def _robust_std(values, default=0.0):
    values = _finite(values)
    return float(1.4826 * np.median(np.abs(values - np.median(values)))) if values.size else float(default)


def _percentile(values, q, default=0.0):
    values = _finite(values)
    return float(np.percentile(values, q)) if values.size else float(default)


def _clip01(x):
    return float(np.clip(x, 0.0, 1.0))


def _scale(value, low, high):
    if high <= low:
        return 0.0
    return _clip01((value - low) / (high - low))


def _two_sided_scale(value, low, high):
    """Score unusually high or low values, with 0 at the center."""
    if low <= value <= high:
        return 0.0
    if value < low:
        return _clip01((low - value) / max(abs(low), EPS))
    return _clip01((value - high) / max(abs(high), EPS))


def _normalize_audio(signal):
    x = np.asarray(signal, dtype=float).reshape(-1)
    x = x[np.isfinite(x)]
    if x.size == 0:
        raise ValueError("Audio signal is empty.")

    # Remove DC offset but do not peak-normalize. Peak normalization would
    # destroy useful intensity information and make loudness comparisons less
    # meaningful.
    x = x - np.mean(x)
    peak = np.max(np.abs(x))
    if peak < EPS:
        raise ValueError("Audio signal contains no usable acoustic energy.")

    # Prevent pathological integer/full-scale values from dominating the
    # feature calculations while preserving relative dynamics.
    if peak > 1.0:
        x = x / peak
    return x


def _preprocess_for_analysis(x, sr):
    """Gentle speech-band conditioning used only for acoustic analysis."""
    # Speech stress features are most reliable above very low-frequency rumble
    # and below strong ultrasonic/mic noise.
    low = 60.0
    high = min(8000.0, sr * 0.45)
    if high <= low:
        return x

    sos = scipy_signal.butter(4, [low, high], btype="bandpass", fs=sr, output="sos")
    return scipy_signal.sosfiltfilt(sos, x)


def _frame_rms(x, sr):
    frame = max(1, int(FRAME_SEC * sr))
    hop = max(1, int(HOP_SEC * sr))
    if len(x) < frame:
        x = np.pad(x, (0, frame - len(x)))
    rms = librosa.feature.rms(y=x.astype(np.float32), frame_length=frame, hop_length=hop, center=False)[0]
    times = librosa.frames_to_time(np.arange(len(rms)), sr=sr, hop_length=hop, n_fft=frame)
    return rms, times


def _adaptive_voiced_mask(rms, sr):
    """Energy VAD with a relative floor; conservative for background noise."""
    if rms.size == 0:
        return np.array([], dtype=bool)

    floor = _percentile(rms, 20, 0.0)
    upper = _percentile(rms, 85, floor)
    dynamic_floor = floor + 0.18 * max(upper - floor, EPS)
    threshold = max(dynamic_floor, upper * 0.08)

    voiced = rms >= threshold

    # Remove isolated single-frame decisions and bridge tiny gaps.
    kernel = np.ones(3, dtype=int)
    smoothed = np.convolve(voiced.astype(int), kernel, mode="same") >= 2
    return smoothed


def _pitch_measurements(sound):
    pitch = sound.to_pitch_cc(
        time_step=HOP_SEC,
        pitch_floor=PITCH_FLOOR,
        max_number_of_candidates=15,
        very_accurate=True,
        silence_threshold=0.03,
        voicing_threshold=0.45,
        octave_cost=0.01,
        octave_jump_cost=0.35,
        voiced_unvoiced_cost=0.14,
        pitch_ceiling=PITCH_CEILING,
    )
    freq = np.asarray(pitch.selected_array["frequency"], dtype=float)
    freq = freq[np.isfinite(freq) & (freq > 0)]
    return freq


def _praat_voice_quality(sound):
    """True Praat measurements: jitter, shimmer and HNR."""
    duration = sound.duration
    start, end = 0.0, duration
    try:
        point_process = call(
            sound,
            "To PointProcess (periodic, cc)",
            PITCH_FLOOR,
            PITCH_CEILING,
        )

        jitter = float(call(
            point_process,
            "Get jitter (local)",
            start, end,
            0.0001, 0.02,
            1.3,
        ))

        shimmer = float(call(
            [sound, point_process],
            "Get shimmer (local)",
            start, end,
            0.0001, 0.02,
            1.3, 1.6,
        ))
    except Exception:
        jitter = float("nan")
        shimmer = float("nan")

    try:
        harmonicity = sound.to_harmonicity_cc(
            time_step=HOP_SEC,
            minimum_pitch=PITCH_FLOOR,
            silence_threshold=0.1,
            periods_per_window=4.5,
        )
        hnr_values = _finite(harmonicity.values[0])
        hnr_values = hnr_values[np.abs(hnr_values) < 100]
        hnr = _robust_median(hnr_values, 0.0)
    except Exception:
        hnr = 0.0

    return jitter, shimmer, hnr


def _spectral_features(x, sr, voiced_mask=None):
    y = x.astype(np.float32)
    n_fft = 1024 if sr >= 16000 else 512
    hop = max(1, int(HOP_SEC * sr))

    centroid = librosa.feature.spectral_centroid(y=y, sr=sr, n_fft=n_fft, hop_length=hop)[0]
    bandwidth = librosa.feature.spectral_bandwidth(y=y, sr=sr, n_fft=n_fft, hop_length=hop)[0]
    rolloff = librosa.feature.spectral_rolloff(y=y, sr=sr, roll_percent=0.85, n_fft=n_fft, hop_length=hop)[0]
    zcr = librosa.feature.zero_crossing_rate(y=y, frame_length=n_fft, hop_length=hop)[0]

    # MFCC variability captures changes in voice timbre/phonation without
    # treating any one MFCC as a direct stress measurement.
    mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13, n_fft=n_fft, hop_length=hop)

    if voiced_mask is not None and len(voiced_mask) == len(centroid):
        use = voiced_mask
    else:
        use = np.ones_like(centroid, dtype=bool)

    if not np.any(use):
        use = np.ones_like(centroid, dtype=bool)

    # Spectral tilt: slope of log magnitude vs log frequency in the speech band.
    stft = np.abs(librosa.stft(y, n_fft=n_fft, hop_length=hop, center=False)) + EPS
    freqs = librosa.fft_frequencies(sr=sr, n_fft=n_fft)
    band = (freqs >= 300) & (freqs <= min(5000, sr * 0.45))
    if np.sum(band) >= 8:
        log_f = np.log10(freqs[band])
        slopes = []
        for col in stft[:, :].T:
            log_a = 20 * np.log10(col[band])
            slopes.append(np.polyfit(log_f, log_a, 1)[0])
        spectral_slope = _robust_median(slopes, 0.0)
    else:
        spectral_slope = 0.0

    return {
        "spectral_centroid_hz": _robust_median(centroid[use]),
        "spectral_bandwidth_hz": _robust_median(bandwidth[use]),
        "spectral_rolloff_hz": _robust_median(rolloff[use]),
        "zero_crossing_rate": _robust_median(zcr[use]),
        "spectral_slope_db_per_octave": spectral_slope,
        "mfcc1_std": _robust_std(mfcc[0]),
        "mfcc2_std": _robust_std(mfcc[1]),
        "mfcc3_std": _robust_std(mfcc[2]),
    }


def _within_clip_change(values, split=0.35):
    values = _finite(values)
    if values.size < 8:
        return 0.0
    n = max(3, int(values.size * split))
    first = np.median(values[:n])
    last = np.median(values[-n:])
    if abs(first) < EPS:
        return 0.0
    return float((last - first) / abs(first))


def _segment_consistency(values, window=5):
    values = _finite(values)
    if values.size < window * 2:
        return 0.5
    chunks = np.array_split(values, min(window, values.size))
    meds = np.array([np.median(c) for c in chunks if len(c)])
    if len(meds) < 2 or np.median(np.abs(meds)) < EPS:
        return 0.5
    cv = np.std(meds) / (abs(np.mean(meds)) + EPS)
    return float(1.0 / (1.0 + cv))


def _score_indicators(features, changes):
    """
    Conservative acoustic indicator score.

    Fixed ranges are deliberately broad. They are not clinical cut-offs;
    they are normalization ranges for an interpretable product UI.
    """
    # Voice-quality instability.
    jitter_score = _scale(features["jitter_percent"], 0.6, 3.0)
    shimmer_score = _scale(features["shimmer_percent"], 3.0, 10.0)
    # Lower HNR means less periodic/clean phonation.
    hnr_score = _scale(18.0 - features["hnr_db"], 0.0, 12.0)

    # Pitch activation: use both absolute F0 and within-clip increase.
    pitch_abs = _scale(features["mean_pitch_hz"], 120.0, 240.0)
    pitch_change = _scale(max(changes["pitch_relative_change"], 0.0), 0.05, 0.35)

    # Intensity change is useful only as a secondary cue because microphones
    # and distance can change level dramatically.
    energy_change = _scale(max(changes["energy_relative_change"], 0.0), 0.10, 0.50)

    # Spectral tilt becomes less negative with stronger high-frequency energy.
    # This is a weak cue, so it has low weight.
    slope_score = _scale(features["spectral_slope_db_per_octave"], -18.0, -8.0)

    # Pausing / continuity: extreme fragmentation is a weak stress-related cue.
    pause_score = _scale(features["pause_ratio"], 0.35, 0.70)

    return {
        "pitch": 100 * (0.65 * pitch_abs + 0.35 * pitch_change),
        "voice_instability": 100 * (0.45 * jitter_score + 0.35 * shimmer_score + 0.20 * hnr_score),
        "energy_change": 100 * energy_change,
        "spectral_tension": 100 * slope_score,
        "speech_fragmentation": 100 * pause_score,
    }


def _quality_score(duration, voiced_ratio, pitch_coverage, jitter, shimmer, hnr):
    duration_score = _clip01((duration - MIN_DURATION_SEC) / 5.0)
    voiced_score = _clip01((voiced_ratio - 0.10) / 0.35)
    pitch_score = _clip01((pitch_coverage - 0.20) / 0.50)
    quality_metrics = []
    if np.isfinite(jitter): quality_metrics.append(1.0)
    if np.isfinite(shimmer): quality_metrics.append(1.0)
    if hnr > 0: quality_metrics.append(_clip01(hnr / 20.0))
    metric_score = np.mean(quality_metrics) if quality_metrics else 0.0
    return float(100 * (0.20 * duration_score + 0.30 * voiced_score + 0.35 * pitch_score + 0.15 * metric_score))


def _level(score):
    if score < 30:
        return "Low"
    if score < 60:
        return "Moderate"
    return "Elevated"


def _build_drivers(scores):
    labels = {
        "voice_instability": "Voice instability",
        "pitch": "Pitch activation",
        "energy_change": "Energy change",
        "spectral_tension": "Spectral tension",
        "speech_fragmentation": "Speech fragmentation",
    }
    ranked = sorted(scores.items(), key=lambda item: item[1], reverse=True)
    return [
        {"feature": labels[k], "score": round(float(v), 1)}
        for k, v in ranked[:3]
        if v >= 25
    ]


def analyze_voice_stress(signal, sample_rate):
    """Analyze acoustic stress-related patterns in one speech recording."""
    try:
        sr = int(sample_rate)
    except Exception as exc:
        raise ValueError("Invalid sample rate.") from exc

    if sr < 8000 or sr > 96000:
        raise ValueError("Sample rate should be between 8 kHz and 96 kHz.")

    x = _normalize_audio(signal)
    duration = len(x) / sr
    if duration < MIN_DURATION_SEC:
        raise ValueError(f"Please provide at least {MIN_DURATION_SEC:.0f} seconds of speech for a reliable analysis.")
    if duration > MAX_ANALYSIS_SEC:
        # Keep the first two minutes deterministic and responsive.
        x = x[: int(MAX_ANALYSIS_SEC * sr)]
        duration = MAX_ANALYSIS_SEC

    analysis_signal = _preprocess_for_analysis(x, sr)
    sound = parselmouth.Sound(analysis_signal, sampling_frequency=sr)

    rms, _ = _frame_rms(analysis_signal, sr)
    voiced_mask = _adaptive_voiced_mask(rms, sr)
    voiced_ratio = float(np.mean(voiced_mask)) if voiced_mask.size else 0.0

    if voiced_ratio < 0.08:
        raise ValueError("Very little speech was detected. Use a clearer speech recording with less background noise.")

    pitch_values = _pitch_measurements(sound)
    pitch_coverage = len(pitch_values) / max(1, len(rms))

    jitter, shimmer, hnr = _praat_voice_quality(sound)
    spectral = _spectral_features(analysis_signal, sr, voiced_mask)

    mean_pitch = _robust_median(pitch_values)
    pitch_std = _robust_std(pitch_values)
    pitch_p10 = _percentile(pitch_values, 10)
    pitch_p90 = _percentile(pitch_values, 90)

    voiced_rms = rms[voiced_mask[: len(rms)]] if len(voiced_mask) == len(rms) else rms
    mean_energy = _robust_median(voiced_rms)
    energy_db = 20 * np.log10(max(mean_energy, EPS))
    pause_ratio = float(1.0 - voiced_ratio)

    pitch_change = _within_clip_change(pitch_values)
    energy_change = _within_clip_change(voiced_rms)

    # Pitch/energy trajectory consistency helps distinguish one isolated burst
    # from a sustained pattern.
    consistency = np.mean([
        _segment_consistency(pitch_values),
        _segment_consistency(voiced_rms),
    ])

    features = {
        "mean_pitch_hz": mean_pitch,
        "pitch_variation_hz": pitch_std,
        "pitch_p10_hz": pitch_p10,
        "pitch_p90_hz": pitch_p90,
        "mean_energy": mean_energy,
        "mean_energy_dbfs": energy_db,
        "pause_ratio": pause_ratio,
        "voiced_activity_percent": voiced_ratio * 100,
        "jitter_percent": float(jitter * 100) if np.isfinite(jitter) else 0.0,
        "shimmer_percent": float(shimmer * 100) if np.isfinite(shimmer) else 0.0,
        "hnr_db": float(hnr),
        **spectral,
    }

    changes = {
        "pitch_relative_change": pitch_change,
        "energy_relative_change": energy_change,
    }

    indicator_scores = _score_indicators(features, changes)

    # Voice instability is the most important acoustic-quality component.
    # Other dimensions are intentionally secondary because they are strongly
    # affected by microphone placement, speaking style and content.
    raw_score = (
        0.38 * indicator_scores["voice_instability"] +
        0.22 * indicator_scores["pitch"] +
        0.15 * indicator_scores["energy_change"] +
        0.10 * indicator_scores["spectral_tension"] +
        0.15 * indicator_scores["speech_fragmentation"]
    )

    # If the evidence is inconsistent, pull the result toward the center
    # rather than pretending the system is certain.
    consistency_factor = 0.70 + 0.30 * consistency
    score = float(np.clip(raw_score * consistency_factor, 0, 100))

    quality = _quality_score(
        duration,
        voiced_ratio,
        pitch_coverage,
        jitter,
        shimmer,
        hnr,
    )

    confidence = float(np.clip(
        0.55 * quality +
        0.25 * pitch_coverage * 100 +
        0.20 * consistency * 100,
        0,
        100,
    ))

    return {
        "stress_score": round(score, 1),
        "stress_level": _level(score),
        "confidence": round(confidence, 1),
        "data_quality": {
            "score": round(quality, 1),
            "duration_seconds": round(duration, 2),
            "speech_activity_percent": round(voiced_ratio * 100, 1),
            "pitch_coverage_percent": round(pitch_coverage * 100, 1),
            "consistency_percent": round(consistency * 100, 1),
        },
        "features": {k: round(float(v), 4) for k, v in features.items()},
        "changes": {k: round(float(v * 100), 2) for k, v in changes.items()},
        "feature_scores": {k: round(float(v), 1) for k, v in indicator_scores.items()},
        "drivers": _build_drivers(indicator_scores),
        "method": "Praat/Parselmouth acoustic analysis + adaptive VAD + interpretable multi-feature scoring",
        "warning": (
            "Acoustic voice-stress analysis can identify patterns such as vocal instability, "
            "pitch activation and phonation changes, but these signals are not specific to "
            "psychological stress. Use this as a screening/monitoring aid, not as a diagnosis "
            "or a lie/deception detector. Results are sensitive to microphone quality, illness, "
            "fatigue, emotion, speaking style and background noise."
        ),
    }


# Backward-compatible name for the existing backend route.
def analyze_voice_stress_hybrid(signal, sample_rate, *args, **kwargs):
    return analyze_voice_stress(signal, sample_rate)
