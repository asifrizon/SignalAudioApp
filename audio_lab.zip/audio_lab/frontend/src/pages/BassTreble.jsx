import { useEffect, useState } from "react";
import OutputPreview from "../components/OutputPreview";
import Spectrum from "../components/Spectrum";

export default function BassTreble({ audioData, onProcess, onAccept, processing }) {
  const [bass, setBass] = useState(0);
  useEffect(() => {
    setResult(null);
  }, [audioData]);
  const [treble, setTreble] = useState(0);
  const nyquist = audioData.sample_rate / 2;
  const [startFrequency, setStartFrequency] = useState(Math.min(1000, nyquist - 2));
  const [endFrequency, setEndFrequency] = useState(Math.min(3000, nyquist));
  const [bandGain, setBandGain] = useState(0);
  const [result, setResult] = useState(null);

  const apply = async () => {
    const r = await onProcess("/bass-treble", {
      bass_gain: bass,
      treble_gain: treble,
      band_start_frequency: startFrequency,
      band_end_frequency: endFrequency,
      band_gain: bandGain,
    });
    if (r) setResult(r);
  };

  return (
    <div className="tool-page">
      <div className="tool-card controls-card">
        <h2>Bass & Treble</h2>
        <label>Bass <strong>{bass} dB</strong></label>
        <input type="range" min="-48" max="48" step=".5" value={bass} onChange={e => setBass(+e.target.value)} />
        <label>Treble <strong>{treble} dB</strong></label>
        <input type="range" min="-48" max="48" step=".5" value={treble} onChange={e => setTreble(+e.target.value)} />
        <label>Selected range gain <strong>{bandGain} dB</strong></label>
        <input type="range" min="-48" max="48" step=".5" value={bandGain} onChange={e => setBandGain(+e.target.value)} />
        <div className="frequency-inputs">
          <label>Band from <input type="number" min="0" max={nyquist - 1} value={Math.round(startFrequency)} onChange={e => setStartFrequency(Math.max(0, Math.min(Number(e.target.value) || 0, endFrequency - 1)))} /></label>
          <label>Band to <input type="number" min="1" max={nyquist} value={Math.round(endFrequency)} onChange={e => setEndFrequency(Math.min(nyquist, Math.max(Number(e.target.value) || 1, startFrequency + 1)))} /></label>
        </div>
        <button className="primary-button" onClick={apply} disabled={processing}>{processing ? "Processing…" : "Apply EQ"}</button>
      </div>
      <div className="tool-card spectrum-card">
        <div><span className="eyebrow">FREQUENCY DOMAIN</span><h2>Customize a frequency band</h2><p>Drag the red handles, then set the gain for the selected range.</p></div>
        <Spectrum signal={audioData.signal} sampleRate={audioData.sample_rate} startFrequency={startFrequency} endFrequency={endFrequency} onRangeChange={(start, end) => { setStartFrequency(start); setEndFrequency(end); }} />
        <div className="frequency-selection">Selected: {startFrequency.toFixed(0)}–{endFrequency.toFixed(0)} Hz at {bandGain} dB</div>
      </div>
      {result && <>
        <div className="tool-card spectrum-card">
          <div><span className="eyebrow">RESULTING FREQUENCY DOMAIN</span><h2>Processed spectrum</h2><p>Review the frequency changes before keeping the audio.</p></div>
          <Spectrum signal={result.signal} sampleRate={result.sample_rate} />
        </div>
        <OutputPreview result={result} onAccept={onAccept} onDiscard={() => setResult(null)} />
      </>}
    </div>
  );
}
