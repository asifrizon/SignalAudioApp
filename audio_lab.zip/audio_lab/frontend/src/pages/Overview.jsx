export default function Overview({ audioData, onUpload, processing }) {
  if (!audioData) {
    return (
      <div className="empty-card">
        <div className="empty-icon">♫</div>
        <h2>Start an audio project</h2>
        <p>Import a WAV or MP3 file to visualize and process its discrete-time signal.</p>
        <label className="primary-button">
          {processing ? "Loading…" : "Choose audio file"}
          <input
            hidden
            type="file"
            accept=".wav,.mp3,audio/wav,audio/mpeg"
            onChange={e => e.target.files?.[0] && onUpload(e.target.files[0])}
          />
        </label>
      </div>
    );
  }

  return (
    <div className="info-grid">
      <div className="info-card"><small>Sample rate</small><strong>{audioData.sample_rate} Hz</strong></div>
      <div className="info-card"><small>Samples</small><strong>{audioData.samples.toLocaleString()}</strong></div>
      <div className="info-card"><small>Duration</small><strong>{audioData.duration.toFixed(2)} s</strong></div>
      <div className="info-card"><small>Channels</small><strong>{audioData.channels ?? 1}</strong></div>
    </div>
  );
}
