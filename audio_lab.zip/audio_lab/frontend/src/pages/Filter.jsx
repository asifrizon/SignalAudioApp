import { useEffect, useState } from "react";
import OutputPreview from "../components/OutputPreview";
import Spectrum from "../components/Spectrum";

const filterOptions = [
  { id: "high-pass", label: "High-pass", description: "Keep frequencies above the cutoff." },
  { id: "low-pass", label: "Low-pass", description: "Keep frequencies below the cutoff." },
  { id: "band-pass", label: "Band-pass", description: "Keep frequencies inside the selected band." },
];

export default function Filter({ audioData, onProcess, onAccept, processing }) {
  const nyquist = audioData.sample_rate / 2;
  const [filterType, setFilterType] = useState("high-pass");
  useEffect(() => {
    setResult(null);
  }, [audioData]);
  const [cutoffFrequency, setCutoffFrequency] = useState(Math.min(1200, nyquist - 1));
  const [startFrequency, setStartFrequency] = useState(Math.min(600, nyquist - 2));
  const [endFrequency, setEndFrequency] = useState(Math.min(2400, nyquist));
  const [result, setResult] = useState(null);

  const apply = async () => {
    const r = await onProcess("/filter", {
      filter_type: filterType,
      cutoff_frequency: cutoffFrequency,
      start_frequency: startFrequency,
      end_frequency: endFrequency,
    });
    if (r) setResult(r);
  };

  const updateCutoff = value => setCutoffFrequency(Math.max(0, Math.min(nyquist, Number(value) || 0)));
  const updateStart = value => setStartFrequency(Math.max(0, Math.min(Number(value) || 0, endFrequency - 1)));
  const updateEnd = value => setEndFrequency(Math.min(nyquist, Math.max(Number(value) || 1, startFrequency + 1)));

  return (
    <div className="tool-page">
      <div className="tool-card controls-card">
        <h2>Frequency filter</h2>
        <p>Choose a filter, set its frequency range, then preview the result.</p>
        <div className="filter-options">
          {filterOptions.map(option => (
            <button
              className={`filter-option ${filterType === option.id ? "selected" : ""}`}
              key={option.id}
              onClick={() => setFilterType(option.id)}
              type="button"
            >
              <strong>{option.label}</strong>
              <span>{option.description}</span>
            </button>
          ))}
        </div>

        {filterType === "band-pass" ? (
          <div className="frequency-inputs">
            <label>Band from <input type="number" min="0" max={nyquist - 1} value={Math.round(startFrequency)} onChange={e => updateStart(e.target.value)} /></label>
            <label>Band to <input type="number" min="1" max={nyquist} value={Math.round(endFrequency)} onChange={e => updateEnd(e.target.value)} /></label>
          </div>
        ) : (
          <label>Cutoff frequency <strong>{cutoffFrequency.toFixed(0)} Hz</strong></label>
        )}
        {filterType !== "band-pass" && <input type="range" min="0" max={nyquist} step="1" value={cutoffFrequency} onChange={e => updateCutoff(e.target.value)} />}
        <button className="primary-button" onClick={apply} disabled={processing}>{processing ? "Processing..." : "Apply filter"}</button>
      </div>

      <div className="tool-card spectrum-card">
        <div><span className="eyebrow">FREQUENCY DOMAIN</span><h2>Set the filter range</h2><p>{filterOptions.find(option => option.id === filterType).description}</p></div>
        {filterType === "band-pass" ? (
          <Spectrum signal={audioData.signal} sampleRate={audioData.sample_rate} startFrequency={startFrequency} endFrequency={endFrequency} onRangeChange={(start, end) => { setStartFrequency(start); setEndFrequency(end); }} />
        ) : (
          <Spectrum
            signal={audioData.signal}
            sampleRate={audioData.sample_rate}
            frequency={cutoffFrequency}
            onFrequencyChange={updateCutoff}
            shadedRange={filterType === "high-pass"
              ? { start: 0, end: cutoffFrequency }
              : { start: cutoffFrequency, end: nyquist }}
          />
        )}
        <div className="frequency-selection">
          {filterType === "band-pass" ? `Kept range: ${startFrequency.toFixed(0)}-${endFrequency.toFixed(0)} Hz` : `Cutoff: ${cutoffFrequency.toFixed(0)} Hz`}
        </div>
      </div>

      {result && <>
        <div className="tool-card spectrum-card">
          <div><span className="eyebrow">RESULTING FREQUENCY DOMAIN</span><h2>Filtered spectrum</h2><p>Review the filtered frequency content before keeping the audio.</p></div>
          <Spectrum signal={result.signal} sampleRate={result.sample_rate} />
        </div>
        <OutputPreview result={result} onAccept={onAccept} onDiscard={() => setResult(null)} />
      </>}
    </div>
  );
}