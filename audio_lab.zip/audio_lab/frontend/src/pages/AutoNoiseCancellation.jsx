import React, { useState } from "react";
import { removeBackgroundNoise } from "../services/audioApi";

function WaveformPreview({
  signal,
  color = "#2563eb",
}) {
  const points = React.useMemo(() => {
    if (!signal || signal.length === 0) return "";

    const width = 900;
    const height = 190;
    const mid = height / 2;
    const step = Math.max(1, Math.floor(signal.length / 180));
    const values = [];

    for (let i = 0; i < signal.length; i += step) {
      const end = Math.min(i + step, signal.length);
      let peak = 0;

      for (let j = i; j < end; j += 1) {
        peak = Math.max(peak, Math.abs(Number(signal[j]) || 0));
      }

      values.push(Math.min(peak, 1));
    }

    return values.map((value, index) => {
      const x = (index / Math.max(values.length - 1, 1)) * width;
      const amplitude = value * 78;
      return `${x.toFixed(1)},${(mid - amplitude).toFixed(1)}`;
    }).join(" ");
  }, [signal]);

  const lowerPoints = points
    ? points.split(" ").reverse().map((point) => {
        const [x, y] = point.split(",");
        return `${x},${(190 - Number(y)).toFixed(1)}`;
      }).join(" ")
    : "";

  return (
    <div className="noise-waveform">
      <svg viewBox="0 0 900 190" preserveAspectRatio="none">
        <line
          x1="0"
          y1="95"
          x2="900"
          y2="95"
          className="noise-wave-center"
        />

        {points && (
          <>
            <polygon
              points={`${points} ${lowerPoints}`}
              fill={color}
              opacity="0.09"
            />

            <polyline
              points={points}
              fill="none"
              stroke={color}
              strokeWidth="2"
              strokeLinejoin="round"
              strokeLinecap="round"
            />

            <polyline
              points={lowerPoints}
              fill="none"
              stroke={color}
              strokeWidth="2"
              strokeLinejoin="round"
              strokeLinecap="round"
              opacity="0.7"
            />
          </>
        )}
      </svg>
    </div>
  );
}



function AutoNoiseCancellation({
  audioData,
  onAccept,
  processing = false,
}) {
  const [cleanedAudio, setCleanedAudio] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleCleanNoise = async () => {
    if (!audioData || !audioData.signal) {
      setError("Please load an audio file first.");
      return;
    }

    try {
      setLoading(true);
      setError("");
      setCleanedAudio(null);

      const result = await removeBackgroundNoise(
        audioData.signal,
        audioData.sample_rate
      );

      setCleanedAudio(result);
    } catch (err) {
      setError(err.message || "Noise cancellation failed.");
    } finally {
      setLoading(false);
    }
  };

  const handleAccept = () => {
    if (!cleanedAudio) return;

    onAccept({
      ...audioData,
      signal: cleanedAudio.signal,
      sample_rate: cleanedAudio.sample_rate,
      duration: cleanedAudio.duration,
    });
  };

  if (!audioData) {
    return (
      <div className="page noise-cancellation-page colorful-noise-page">
        <div className="noise-hero">
          <div className="noise-hero-icon">🔇</div>
          <div>
            <span className="noise-eyebrow">AUDIO ENHANCEMENT</span>
            <h1>Auto Noise Cancellation</h1>
            <p>Clean unwanted background noise while preserving the main audio signal.</p>
          </div>
          <div className="noise-live-badge"><i /> Signal ready</div>
        </div>
      </div>
    );
  }

  return (
    <div className="page noise-cancellation-page colorful-noise-page">
      <div className="noise-hero">
        <div className="noise-hero-icon">🔇</div>
        <div>
          <span className="noise-eyebrow">AUDIO ENHANCEMENT</span>
          <h1>Auto Noise Cancellation</h1>
          <p>Reduce fan, AC, hiss, traffic, electrical hum and microphone background noise.</p>
        </div>
        <div className="noise-live-badge"><i /> Automatic mode</div>
      </div>

      <div className="noise-feature-strip">
        <span>🎙 Voice preservation</span>
        <span>🌬 Fan & AC</span>
        <span>⚡ Electrical hum</span>
        <span>🚗 Background traffic</span>
      </div>

      <p className="noise-description">
        Automatically reduce unwanted background noise such as
        fan, AC, hiss, traffic, computer fan, electrical hum,
        and microphone noise.
      </p>

      {/* Audio Information */}
      <div className="noise-info noise-info-colorful">
        <h3>Current Audio</h3>

        <p>
          <strong>File:</strong>{" "}
          {audioData.filename || "Current audio"}
        </p>

        <p>
          <strong>Sample Rate:</strong>{" "}
          {audioData.sample_rate} Hz
        </p>

        <p>
          <strong>Duration:</strong>{" "}
          {Number(audioData.duration || 0).toFixed(2)} seconds
        </p>
      </div>

      {/* Clean Button */}
      <button className="noise-clean-primary"
        onClick={handleCleanNoise}
        disabled={loading || processing}
      >
        {loading
          ? "Analyzing & Removing Noise..."
          : "🔇 Remove Background Noise"}
      </button>

      {/* Error */}
      {error && (
        <p className="error">
          {error}
        </p>
      )}

      {/* Result */}
      {cleanedAudio && (
        <div className="noise-result noise-result-colorful">

          <h3>Noise Cancellation Complete</h3>

          

          <p>
            <span className="noise-stat-label">Noise Frames Used</span><strong>{" "}
            {cleanedAudio.noise_frames_used}</strong>
          </p>

          <p>
            <span className="noise-stat-label">Total Frames</span><strong>{" "}
            {cleanedAudio.total_frames}</strong>
          </p>

          <p>
            <span className="noise-stat-label">Estimated RMS Reduction</span><strong>{" "}
            {cleanedAudio.noise_reduction_percent}%</strong>
          </p>

          {/* Before / After Waveforms */}
          <div className="before-after">

            <div className="noise-preview-card before">
              <div className="noise-preview-header">
                <div>
                  <span className="noise-preview-badge">
                    ORIGINAL
                  </span>
                  <h4>🎤 Before</h4>
                  <p>Original audio with background noise.</p>
                </div>

                <span className="noise-preview-status noise-status-before">
                  Noise present
                </span>
              </div>

              <WaveformPreview
                signal={audioData.signal}
                color="#64748b"
              />

              <div className="noise-wave-footer">
                <span>0:00</span>
                <span>
                  {Number(audioData.duration || 0).toFixed(2)}s
                </span>
              </div>
            </div>

            <div className="noise-preview-card after">
              <div className="noise-preview-header">
                <div>
                  <span className="noise-preview-badge clean">
                    CLEANED
                  </span>
                  <h4>✨ After</h4>
                  <p>
                    Audio after automatic background-noise reduction.
                  </p>
                </div>

                <span className="noise-preview-status noise-status-after">
                  Cleaner signal
                </span>
              </div>

              <WaveformPreview
                signal={cleanedAudio.signal}
                color="#2563eb"
              />

              <div className="noise-wave-footer">
                <span>0:00</span>
                <span>
                  {Number(cleanedAudio.duration || 0).toFixed(2)}s
                </span>
              </div>
            </div>

          </div>

          {/* Accept */}
          <button className="noise-accept-primary" onClick={handleAccept}>
            ✅ Accept Cleaned Audio
          </button>

          <p>
            Or keep the original audio by doing nothing.
          </p>

        </div>
      )}
    </div>
  );
}

export default AutoNoiseCancellation;