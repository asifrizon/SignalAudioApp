import { useEffect, useState } from "react";

import OutputPreview from "../components/OutputPreview";
import Spectrum from "../components/Spectrum";
import TrimWaveform from "../components/TrimWaveform";


export default function NoiseRemoval({
  audioData,
  onProcess,
  onAccept,
  processing
}) {
  useEffect(() => {
    setRemoveResult(null);
    setNoiseResult(null);
  }, [audioData]);

  const nyquist =
    audioData.sample_rate / 2;


  /*
    -----------------------------------------
    NOISE REMOVAL STATE
    -----------------------------------------
  */

  const [
    startFrequency,
    setStartFrequency
  ] = useState(
    Math.min(
      900,
      nyquist - 2
    )
  );


  const [
    endFrequency,
    setEndFrequency
  ] = useState(
    Math.min(
      1100,
      nyquist
    )
  );


  const [
    removeResult,
    setRemoveResult
  ] = useState(null);


  /*
    -----------------------------------------
    ADD NOISE STATE
    -----------------------------------------
  */

  const [
    startTime,
    setStartTime
  ] = useState(0);


  const [
    endTime,
    setEndTime
  ] = useState(
    Math.min(
      2,
      audioData.duration
    )
  );


  const [
    noiseFrequency,
    setNoiseFrequency
  ] = useState(1000);


  const [
    noiseAmplitude,
    setNoiseAmplitude
  ] = useState(0.25);


  const [
    noiseResult,
    setNoiseResult
  ] = useState(null);

  const [
    previewTime,
    setPreviewTime
  ] = useState(0);


  /*
    -----------------------------------------
    REMOVE NOISE
    -----------------------------------------
  */

  const applyRemoveNoise =
    async () => {

      const r =
        await onProcess(
          "/remove-noise",
          {
            start_frequency:
              startFrequency,

            end_frequency:
              endFrequency
          }
        );


      if (r) {
        setRemoveResult(r);
      }
    };


  /*
    -----------------------------------------
    ADD NOISE
    -----------------------------------------
  */

  const applyAddNoise =
    async () => {

      const r =
        await onProcess(
          "/add-noise",
          {
            start_time:
              startTime,

            end_time:
              endTime,

            noise_frequency:
              noiseFrequency,

            noise_amplitude:
              noiseAmplitude
          }
        );


      if (r) {
        setNoiseResult(r);
      }
    };


  return (

    <div className="tool-page">

      {/* =================================================
          REMOVE NOISE
      ================================================= */}

      <div className="tool-card controls-card">

        <h2>
          Frequency-based noise removal
        </h2>

        <p>
          Select a frequency range and remove
          it from the audio.
        </p>


        <label>
          Selected range{" "}

          <strong>
            {startFrequency.toFixed(0)}
            –
            {endFrequency.toFixed(0)}
            {" "}Hz
          </strong>
        </label>


        <div className="frequency-inputs">

          <label>
            Delete from

            <input
              type="number"
              min="0"
              max={nyquist - 1}
              value={
                Math.round(
                  startFrequency
                )
              }

              onChange={(e) => {

                const value =
                  Number(
                    e.target.value
                  ) || 0;

                setStartFrequency(
                  Math.max(
                    0,
                    Math.min(
                      value,
                      endFrequency - 1
                    )
                  )
                );
              }}
            />

          </label>


          <label>
            Delete to

            <input
              type="number"
              min="1"
              max={nyquist}
              value={
                Math.round(
                  endFrequency
                )
              }

              onChange={(e) => {

                const value =
                  Number(
                    e.target.value
                  ) || 1;

                setEndFrequency(
                  Math.min(
                    nyquist,
                    Math.max(
                      value,
                      startFrequency + 1
                    )
                  )
                );
              }}
            />

          </label>

        </div>


        <button
          className="primary-button"
          onClick={
            applyRemoveNoise
          }
          disabled={processing}
        >
          {processing
            ? "Processing…"
            : "Remove frequency"}
        </button>

      </div>


      {/* =================================================
          REMOVE NOISE SPECTRUM
      ================================================= */}

      <div className="tool-card spectrum-card">

        <div>

          <span className="eyebrow">
            FREQUENCY DOMAIN
          </span>

          <h2>
            Select frequencies
          </h2>

          <p>
            Drag the handles to select
            the frequencies to remove.
          </p>

        </div>


        <Spectrum
          signal={
            audioData.signal
          }

          sampleRate={
            audioData.sample_rate
          }

          startFrequency={
            startFrequency
          }

          endFrequency={
            endFrequency
          }

          onRangeChange={
            (
              start,
              end
            ) => {

              setStartFrequency(
                start
              );

              setEndFrequency(
                end
              );

            }
          }
        />

      </div>


      {/* =================================================
          REMOVE NOISE RESULT
      ================================================= */}

      {removeResult && (

        <>

          <div className="tool-card spectrum-card">

            <div>

              <span className="eyebrow">
                RESULTING FREQUENCY DOMAIN
              </span>

              <h2>
                Filtered spectrum
              </h2>

              <p>
                The selected frequency
                range has been removed.
              </p>

            </div>


            <Spectrum
              signal={
                removeResult.signal
              }

              sampleRate={
                removeResult.sample_rate
              }
            />

          </div>


          <OutputPreview
            result={
              removeResult
            }

            onAccept={
              onAccept
            }

            onDiscard={() =>
              setRemoveResult(null)
            }
          />

        </>

      )}


      {/* =================================================
          ADD NOISE
      ================================================= */}

      <div className="tool-card controls-card">

        <h2>
          Add noise
        </h2>

        <p>
          Select a portion of the audio
          and add a sinusoidal noise
          at a chosen frequency.
        </p>

        {/* Time range */}

        <div className="frequency-inputs">

          <label>

            Noise from

            <input
              type="number"
              min="0"
              max={
                audioData.duration
              }
              step="0.01"

              value={
                startTime
              }

              onChange={(e) => {

                const value =
                  Number(
                    e.target.value
                  ) || 0;

                setStartTime(
                  Math.max(
                    0,
                    Math.min(
                      value,
                      endTime - 0.01
                    )
                  )
                );

              }}
            />

            s

          </label>


          <label>

            Noise to

            <input
              type="number"
              min="0.01"
              max={
                audioData.duration
              }
              step="0.01"

              value={
                endTime
              }

              onChange={(e) => {

                const value =
                  Number(
                    e.target.value
                  ) || 0.01;

                setEndTime(
                  Math.min(
                    audioData.duration,
                    Math.max(
                      value,
                      startTime + 0.01
                    )
                  )
                );

              }}
            />

            s

          </label>

        </div>


        {/* Noise frequency */}

        <label>

          Noise frequency{" "}

          <strong>
            {noiseFrequency.toFixed(0)}
            {" "}Hz
          </strong>

        </label>


        <input
          type="range"
          min="1"
          max={nyquist}
          step="1"

          value={
            noiseFrequency
          }

          onChange={(e) =>
            setNoiseFrequency(
              Number(
                e.target.value
              )
            )
          }
        />


        {/* Exact frequency input */}

        <label>

          Frequency (Hz)

          <input
            type="number"
            min="0"
            max={nyquist}
            step="1"

            value={
              noiseFrequency
            }

            onChange={(e) => {

              const value =
                Number(
                  e.target.value
                ) || 0;

              setNoiseFrequency(
                Math.max(
                  0,
                  Math.min(
                    nyquist,
                    value
                  )
                )
              );

            }}
          />

        </label>


        {/* Noise amplitude */}

        <label>

          Noise amplitude{" "}

          <strong>
            {noiseAmplitude.toFixed(2)}
          </strong>

        </label>


        <input
          type="range"
          min="0"
          max="1"
          step="0.01"

          value={
            noiseAmplitude
          }

          onChange={(e) =>
            setNoiseAmplitude(
              Number(
                e.target.value
              )
            )
          }
        />


        <button
          className="primary-button"
          onClick={
            applyAddNoise
          }
          disabled={
            processing ||
            startTime >= endTime
          }
        >
          {processing
            ? "Processing…"
            : "Add noise"}
        </button>

      </div>

      <div className="tool-card noise-range-card">
        <div className="tool-card-head">
          <div>
            <span className="eyebrow">TIME DOMAIN</span>
            <h2>Select where to add noise</h2>
            <p>Drag the two playheads or use the time inputs above.</p>
          </div>
          <div className="selection-pill">{(endTime - startTime).toFixed(2)} s selected</div>
        </div>
        <TrimWaveform
          signal={audioData.signal}
          duration={audioData.duration}
          start={startTime}
          end={endTime}
          currentTime={previewTime}
          onChange={(start, end) => {
            setStartTime(start);
            setEndTime(end);
          }}
          onSeek={setPreviewTime}
          waveformColor="#2563eb"
          selectionColor="rgba(37, 99, 235, 0.12)"
          handleColor="#2563eb"
          showLabels={false}
          showPlaybackControls={false}
          regionLabel="NOISE"
        />
      </div>


      {/* =================================================
          ORIGINAL FREQUENCY DOMAIN (whole file)
          Intentionally NOT scoped to startTime/endTime: those
          change continuously while dragging the playheads below,
          and re-running the FFT on every drag frame is what was
          causing the lag. This spectrum only depends on the audio
          itself, so it's computed once and stays put while you pick
          where to add noise.
      ================================================= */}

      <div className="tool-card spectrum-card">

        <div>

          <span className="eyebrow">
            ORIGINAL FREQUENCY DOMAIN
          </span>

          <h2>
            Full audio spectrum
          </h2>

          <p>
            The complete frequency content of your
            current audio, for reference while you
            choose where to add noise below.
          </p>

        </div>


        <Spectrum
          signal={
            audioData.signal
          }

          sampleRate={
            audioData.sample_rate
          }
        />

      </div>


      {/* =================================================
          ADD NOISE RESULT
      ================================================= */}

      {noiseResult && (

        <>

          <div className="tool-card spectrum-card">

            <div>

              <span className="eyebrow">
                RESULTING FREQUENCY DOMAIN
              </span>

              <h2>
                After adding noise
              </h2>

              <p>
                Compare this with the original
                spectrum above — the added
                frequency should appear here.
              </p>

            </div>


            <Spectrum
              signal={
                noiseResult.signal
              }

              sampleRate={
                noiseResult.sample_rate
              }
            />


            <div className="frequency-selection">

              Added noise:

              {" "}

              <strong>
                {noiseResult.noise_frequency.toFixed(0)}
                {" "}Hz
              </strong>

              {" · "}

              Amplitude:

              {" "}

              <strong>
                {noiseResult.noise_amplitude.toFixed(2)}
              </strong>

              {" · "}

              Region:

              {" "}

              <strong>
                {noiseResult.noise_start_time.toFixed(2)}
                {" – "}
                {noiseResult.noise_end_time.toFixed(2)}
                {" "}s
              </strong>

            </div>

          </div>


          <OutputPreview
            result={
              noiseResult
            }

            onAccept={
              onAccept
            }

            onDiscard={() =>
              setNoiseResult(null)
            }
          />

        </>

      )}

    </div>
  );
}