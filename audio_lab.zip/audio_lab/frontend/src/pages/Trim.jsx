import { useEffect, useState } from "react";
import TrimWaveform from "../components/TrimWaveform";
import OutputPreview from "../components/OutputPreview";

export default function Trim({ audioData, onProcess, onAccept, processing }) {
  const [start, setStart] = useState(audioData.duration * 0.25);
  useEffect(() => {
    setResult(null);
  }, [audioData]);
  const [end, setEnd] = useState(audioData.duration * 0.75);
  const [result, setResult] = useState(null);
  const [previewTime, setPreviewTime] = useState(0);

  const updateStart = (value) => {
    const next = Number(value);
    if (!Number.isFinite(next)) return;
    setStart(Math.max(0, Math.min(next, end - 0.01)));
  };

  const updateEnd = (value) => {
    const next = Number(value);
    if (!Number.isFinite(next)) return;
    setEnd(Math.min(audioData.duration, Math.max(next, start + 0.01)));
  };

  const handleDelete = async () => {
    const output = await onProcess("/delete-section", {
      start_time: start,
      end_time: end,
    });
    if (output) setResult(output);
  };

  return (
    <div className="tool-page">
      <div className="tool-card">
        <div className="tool-card-head">
          <div>
            <h2>Delete a section</h2>
            <p>Drag the two red edit playheads. Everything between them will be deleted.</p>
          </div>
          <div className="selection-pill">{(end - start).toFixed(2)} s selected for deletion</div>
        </div>

        <TrimWaveform
          signal={audioData.signal}
          duration={audioData.duration}
          start={start}
          end={end}
          currentTime={previewTime}
          onChange={(a, b) => { setStart(a); setEnd(b); }}
          onSeek={setPreviewTime}
          showPlaybackButtons={false}
        />

        <div className="trim-summary">
          <div><span>Delete from</span><input type="number" min="0" max={Math.max(0, end - 0.01)} step="0.01" value={start.toFixed(2)} onChange={e => updateStart(e.target.value)} /></div>
          <div><span>Delete to</span><input type="number" min={Math.min(audioData.duration, start + 0.01)} max={audioData.duration} step="0.01" value={end.toFixed(2)} onChange={e => updateEnd(e.target.value)} /></div>
          <div><span>Remaining</span><strong>{(audioData.duration - (end - start)).toFixed(2)} s</strong></div>
        </div>

        <button className="danger-button" onClick={handleDelete} disabled={processing}>
          {processing ? "Deleting…" : "Delete selected section"}
        </button>
      </div>

      {result && <OutputPreview result={result} onAccept={onAccept} onDiscard={() => setResult(null)} />}
    </div>
  );
}
