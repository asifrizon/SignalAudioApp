import { useEffect, useState } from "react";
import OutputPreview from "../components/OutputPreview";
import Waveform from "../components/Waveform";

export default function Reverse({ audioData, onProcess, onAccept, processing }) {
  const [result, setResult] = useState(null);
  useEffect(() => {
    setResult(null);
  }, [audioData]);

  const apply = async () => {
    const r = await onProcess("/reverse", {});
    if (r) setResult(r);
  };

  return (
    <div className="tool-page">
      <div className="reverse-setup-grid">
        <div className="tool-card controls-card reverse-controls-card">
          <span className="eyebrow">TIME REVERSAL</span>
          <h2>Reverse audio</h2>
          <p>Flip the clip from end to beginning. The preview updates instantly before processing.</p>
          <button className="primary-button" onClick={apply} disabled={processing}>{processing ? "Processing..." : "Reverse audio"}</button>
        </div>

        <div className="tool-card reverse-preview-card">
          <div className="tool-card-head">
            <div>
              <span className="eyebrow">INSTANT PREVIEW</span>
              <h2>Waveform mirror</h2>
              <p>This is a browser-side preview of the reversed sample order.</p>
            </div>
            <span className="reverse-arrow" aria-hidden="true">↔</span>
          </div>
          <div className="reverse-preview-waveform">
            <Waveform signal={audioData.signal} duration={audioData.duration} currentTime={0} onSeek={() => {}} zoom={1} height={150} />
          </div>
        </div>
      </div>

      {result && <OutputPreview result={result} onAccept={onAccept} onDiscard={() => setResult(null)} />}
    </div>
  );
}