import React, { useState } from "react";
import { analyzeVoiceStress } from "../services/audioApi";

function MetricCard({ label, value, unit = "", hint }) {
  return (
    <div className="stress-metric-card">
      <div className="stress-metric-label">{label}</div>
      <div className="stress-metric-value">
        {value}
        {unit && <span>{unit}</span>}
      </div>
      {hint && <div className="stress-metric-hint">{hint}</div>}
    </div>
  );
}

function ScoreBar({ label, score }) {
  const value = Math.max(0, Math.min(100, Number(score) || 0));

  return (
    <div className="stress-score-row">
      <div className="stress-score-header">
        <span>{label}</span>
        <strong>{value.toFixed(0)}</strong>
      </div>
      <div className="stress-score-track">
        <div className="stress-score-fill" style={{ width: `${value}%` }} />
      </div>
    </div>
  );
}


function StressGauge({ score, level }) {
  const value = Math.max(0, Math.min(100, Number(score) || 0));

  return (
    <div className="stress-gauge">
      <div
        className="stress-gauge-arc"
        style={{ "--stress-value": `${value * 3.6}deg` }}
      >
        <div className="stress-gauge-inner">
          <strong>{value.toFixed(0)}</strong>
          <span>/ 100</span>
        </div>
      </div>
      <div className="stress-gauge-label">{level}</div>
    </div>
  );
}

function SignalPulse({ scores }) {
  const values = [
    scores?.voice_instability,
    scores?.pitch,
    scores?.energy_change,
    scores?.spectral_tension,
    scores?.speech_fragmentation,
  ].map((v) => Math.max(8, Math.min(100, Number(v) || 0)));

  return (
    <div className="signal-pulse">
      {values.map((value, index) => (
        <span
          key={index}
          style={{
            height: `${18 + value * 0.62}%`,
            animationDelay: `${index * 0.11}s`,
          }}
        />
      ))}
    </div>
  );
}

function VoiceStress({ audioData, processing }) {
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [activeView, setActiveView] = useState("overview");
  const [showMethod, setShowMethod] = useState(false);

  const handleAnalyze = async () => {
    if (!audioData?.signal || !audioData?.sample_rate) {
      setError("Please upload a speech recording first.");
      return;
    }

    try {
      setLoading(true);
      setError("");
      setResult(null);

      const data = await analyzeVoiceStress(
        audioData.signal,
        audioData.sample_rate
      );

      setResult(data);
    } catch (err) {
      console.error("Voice Stress Error:", err);
      setError(err.message || "Voice stress analysis failed.");
    } finally {
      setLoading(false);
    }
  };

  const levelClass = (level) => {
    if (level === "Elevated") return "stress-high";
    if (level === "Moderate") return "stress-moderate";
    return "stress-low";
  };

  const score = Number(result?.stress_score || 0);
  const confidence = Number(result?.confidence || 0);
  const quality = Number(result?.data_quality?.score || 0);

  return (
    <div className="voice-stress-page">
      <div className="stress-page-header stress-hero">
        <div className="stress-hero-copy">
          <div className="stress-hero-icon">◉</div>
          <div>
            <div className="stress-eyebrow">AUDIO INTELLIGENCE</div>
            <h1>Voice Stress Analysis</h1>
          <p>
            Acoustic analysis of vocal patterns associated with stress and arousal.
          </p>
          </div>
        </div>
        <div className="stress-method-badge"><span className="stress-badge-dot" />Professional acoustic analysis</div>
      </div>

      <div className="stress-info-banner">
        <div className="stress-info-icon">i</div>
        <div>
          <strong>What this measures</strong>
          <p>
            Pitch activation, vocal instability, phonation quality, energy changes
            and speech continuity. It does not determine a person's mental state
            or detect deception.
          </p>
        </div>
      </div>

      <div className="stress-audio-info stress-audio-panel">
        <div>
          <span>Recording</span>
          <strong>{audioData?.filename || "No audio loaded"}</strong>
        </div>
        <div>
          <span>Duration</span>
          <strong>
            {audioData?.duration ? `${audioData.duration.toFixed(2)} s` : "—"}
          </strong>
        </div>
        <div>
          <span>Sample rate</span>
          <strong>{audioData?.sample_rate ? `${audioData.sample_rate} Hz` : "—"}</strong>
        </div>
      </div>

      <button
        className="stress-analyze-button stress-analyze-primary"
        onClick={handleAnalyze}
        disabled={!audioData || loading || processing}
      >
        <span className="stress-button-icon">{loading ? "◌" : "◈"}</span>
        {loading ? "Analyzing acoustic features…" : "Analyze Voice"}
        {!loading && <span className="stress-button-arrow">→</span>}
      </button>

      {error && <div className="stress-error">{error}</div>}

      {result && (
        <div className="stress-result">
          <div className="stress-dashboard-top">
            <div className="stress-live-card">
              <div className="stress-live-head">
                <div>
                  <span className="stress-section-kicker">LIVE ACOUSTIC PROFILE</span>
                  <h2>Voice signal overview</h2>
                </div>
                <span className="stress-live-pill">
                  <i /> Analysis complete
                </span>
              </div>

              <div className="stress-live-content">
                <StressGauge score={score} level={result.stress_level} />

                <div className="stress-profile-copy">
                  <span className="stress-profile-label">CURRENT INDICATOR</span>
                  <div className="stress-profile-level">{result.stress_level}</div>
                  <p>
                    Acoustic score <strong>{score.toFixed(1)}</strong> out of 100.
                    The indicator summarizes the measured vocal feature profile.
                  </p>

                  <div className="stress-mini-stats">
                    <div>
                      <span>Confidence</span>
                      <strong>{confidence.toFixed(0)}%</strong>
                    </div>
                    <div>
                      <span>Quality</span>
                      <strong>{quality.toFixed(0)}%</strong>
                    </div>
                    <div>
                      <span>Speech</span>
                      <strong>{Number(result.data_quality.speech_activity_percent).toFixed(0)}%</strong>
                    </div>
                  </div>
                </div>

                <div className="stress-signal-card">
                  <div className="stress-signal-head">
                    <span>Signal activity</span>
                    <strong>5 factors</strong>
                  </div>
                  <SignalPulse scores={result.feature_scores} />
                  <div className="stress-signal-axis">
                    <span>Lower</span>
                    <span>Higher</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="stress-tabbar">
            {[
              ["overview", "Overview"],
              ["indicators", "Indicators"],
              ["measurements", "Measurements"],
            ].map(([key, label]) => (
              <button
                key={key}
                className={activeView === key ? "active" : ""}
                onClick={() => setActiveView(key)}
              >
                {label}
              </button>
            ))}
          </div>

          {activeView === "overview" && (
            <>
              <div className="stress-quality-grid">
                <MetricCard
                  label="Analysis confidence"
                  value={confidence.toFixed(0)}
                  unit="%"
                  hint="Speech coverage, pitch coverage and consistency"
                />
                <MetricCard
                  label="Recording quality"
                  value={quality.toFixed(0)}
                  unit="%"
                  hint="Usable acoustic evidence in the recording"
                />
                <MetricCard
                  label="Speech activity"
                  value={Number(result.data_quality.speech_activity_percent).toFixed(1)}
                  unit="%"
                  hint="Portion classified as speech"
                />
                <MetricCard
                  label="Pitch coverage"
                  value={Number(result.data_quality.pitch_coverage_percent).toFixed(1)}
                  unit="%"
                  hint="Frames with reliable pitch estimates"
                />
              </div>

              <section className="stress-section stress-feature-section">
                <div className="stress-section-title">
                  <div>
                    <span className="stress-section-kicker">SIGNAL BREAKDOWN</span>
                    <h2>Primary acoustic indicators</h2>
                  </div>
                  <span>Tap a metric to inspect its strength</span>
                </div>

                <div className="stress-score-list">
                  <ScoreBar label="Voice instability" score={result.feature_scores.voice_instability} />
                  <ScoreBar label="Pitch activation" score={result.feature_scores.pitch} />
                  <ScoreBar label="Energy change" score={result.feature_scores.energy_change} />
                  <ScoreBar label="Spectral tension" score={result.feature_scores.spectral_tension} />
                  <ScoreBar label="Speech fragmentation" score={result.feature_scores.speech_fragmentation} />
                </div>
              </section>

              {result.drivers?.length > 0 && (
                <section className="stress-section">
                  <div className="stress-section-title">
                    <div>
                      <span className="stress-section-kicker">KEY EVIDENCE</span>
                      <h2>Strongest observed signals</h2>
                    </div>
                  </div>
                  <div className="stress-drivers">
                    {result.drivers.map((driver, index) => (
                      <div className="stress-driver stress-driver-interactive" key={driver.feature}>
                        <div className="stress-driver-rank">{String(index + 1).padStart(2, "0")}</div>
                        <div className="stress-driver-name">
                          <span>{driver.feature}</span>
                          <div className="stress-driver-track">
                            <i style={{ width: `${Math.min(100, Number(driver.score) || 0)}%` }} />
                          </div>
                        </div>
                        <strong>{Number(driver.score).toFixed(0)}</strong>
                      </div>
                    ))}
                  </div>
                </section>
              )}
            </>
          )}

          {activeView === "indicators" && (
            <section className="stress-section stress-indicator-explorer">
              <div className="stress-section-title">
                <div>
                  <span className="stress-section-kicker">INDICATOR EXPLORER</span>
                  <h2>Acoustic signal strengths</h2>
                </div>
                <span>0 = lower · 100 = stronger</span>
              </div>

              <div className="stress-indicator-grid">
                {[
                  ["Voice instability", result.feature_scores.voice_instability],
                  ["Pitch activation", result.feature_scores.pitch],
                  ["Energy change", result.feature_scores.energy_change],
                  ["Spectral tension", result.feature_scores.spectral_tension],
                  ["Speech fragmentation", result.feature_scores.speech_fragmentation],
                ].map(([label, value]) => {
                  const v = Math.max(0, Math.min(100, Number(value) || 0));
                  return (
                    <div className="stress-indicator-card" key={label}>
                      <div className="stress-indicator-card-top">
                        <span>{label}</span>
                        <strong>{v.toFixed(0)}</strong>
                      </div>
                      <div className="stress-indicator-gauge">
                        <i style={{ width: `${v}%` }} />
                      </div>
                      <small>
                        {v < 30 ? "Low acoustic signal" : v < 65 ? "Moderate acoustic signal" : "Strong acoustic signal"}
                      </small>
                    </div>
                  );
                })}
              </div>
            </section>
          )}

          {activeView === "measurements" && (
            <section className="stress-section">
              <div className="stress-section-title">
                <div>
                  <span className="stress-section-kicker">RAW MEASUREMENTS</span>
                  <h2>Acoustic measurements</h2>
                </div>
                <span>Measured from the uploaded recording</span>
              </div>

              <div className="stress-metrics-grid">
                <MetricCard label="Mean pitch" value={Number(result.features.mean_pitch_hz).toFixed(1)} unit="Hz" />
                <MetricCard label="Pitch variation" value={Number(result.features.pitch_variation_hz).toFixed(1)} unit="Hz" />
                <MetricCard label="Jitter" value={Number(result.features.jitter_percent).toFixed(2)} unit="%" hint="Cycle-to-cycle pitch-period variation" />
                <MetricCard label="Shimmer" value={Number(result.features.shimmer_percent).toFixed(2)} unit="%" hint="Cycle-to-cycle amplitude variation" />
                <MetricCard label="HNR" value={Number(result.features.hnr_db).toFixed(1)} unit="dB" hint="Harmonic-to-noise ratio" />
                <MetricCard label="Pause ratio" value={(Number(result.features.pause_ratio) * 100).toFixed(1)} unit="%" />
                <MetricCard label="Spectral centroid" value={Number(result.features.spectral_centroid_hz).toFixed(0)} unit="Hz" />
                <MetricCard label="Spectral slope" value={Number(result.features.spectral_slope_db_per_octave).toFixed(1)} unit="dB/oct" />
              </div>
            </section>
          )}

          <div className="stress-footer-tools">
            <button
              className={`stress-method-toggle ${showMethod ? "open" : ""}`}
              onClick={() => setShowMethod(!showMethod)}
            >
              <span>
                <b>Analysis method</b>
                <small>How this result was produced</small>
              </span>
              <strong>{showMethod ? "−" : "+"}</strong>
            </button>

            {showMethod && (
              <div className="stress-method stress-method-expanded">
                <strong>Method:</strong> {result.method}
              </div>
            )}

            <div className="stress-warning">
              <strong>Interpretation note</strong>
              <span>{result.warning}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default VoiceStress;
