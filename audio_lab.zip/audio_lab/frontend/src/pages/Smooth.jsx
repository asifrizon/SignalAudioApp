import { useEffect, useState } from "react";
import OutputPreview from "../components/OutputPreview";

export default function Smooth({ audioData, onProcess, onAccept, processing }) {
  const [windowSize, setWindowSize] = useState(5);
  useEffect(() => {
    setResult(null);
  }, [audioData]);
  const [result, setResult] = useState(null);
  const requestedMax = Math.min(audioData.signal.length, Math.max(20001, Math.round(audioData.sample_rate * 0.5)));
  const maxWindow = Math.max(1, requestedMax % 2 ? requestedMax : requestedMax - 1);
  const effectiveWindow = Math.min(windowSize, maxWindow);

  const apply = async () => {
    const r = await onProcess("/smooth", { window_size: effectiveWindow });
    if (r) setResult(r);
  };

  return (
    <div className="tool-page">
      <div className="tool-card controls-card">
        <h2>Moving-average smoothing</h2>
        <p>Uses h[n] = 1/M [1, 1, …, 1]. The window size must be odd.</p>
        <label>Window size <strong>{effectiveWindow}</strong></label>
        <input type="range" min="1" max={maxWindow} step="2" value={effectiveWindow} onChange={e => setWindowSize(+e.target.value)} />
        <button className="primary-button" onClick={apply} disabled={processing}>{processing ? "Processing…" : "Apply smoothing"}</button>
      </div>
      {result && <OutputPreview result={result} onAccept={onAccept} onDiscard={() => setResult(null)} />}
    </div>
  );
}
