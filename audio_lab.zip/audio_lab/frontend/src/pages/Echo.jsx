import { useEffect, useState } from "react";
import OutputPreview from "../components/OutputPreview";

export default function Echo({ audioData, onProcess, onAccept, processing }) {
  const [delay, setDelay] = useState(.25);
  useEffect(() => {
    setResult(null);
  }, [audioData]);
  const [gain, setGain] = useState(.5);
  const [result, setResult] = useState(null);
  const maxDelay = Math.max(10, Math.min(30, Math.ceil(audioData.duration * 2)));
  const maxGain = 5;
  const effectiveDelay = Math.min(delay, maxDelay);

  const apply = async () => {
    const r = await onProcess("/echo", { delay: effectiveDelay, gain });
    if (r) setResult(r);
  };

  return (
    <div className="tool-page">
      <div className="tool-card controls-card">
        <h2>Echo effect</h2>
        <label>Delay <strong>{effectiveDelay.toFixed(2)} s</strong></label>
        <input type="range" min=".05" max={maxDelay} step=".01" value={effectiveDelay} onChange={e => setDelay(+e.target.value)} />
        <label>Gain <strong>{gain.toFixed(2)}</strong></label>
        <input type="range" min="0" max={maxGain} step=".01" value={gain} onChange={e => setGain(+e.target.value)} />
        <button className="primary-button" onClick={apply} disabled={processing}>{processing ? "Processing…" : "Apply echo"}</button>
      </div>
      {result && <OutputPreview result={result} onAccept={onAccept} onDiscard={() => setResult(null)} />}
    </div>
  );
}
