import { useEffect, useState } from "react";
import OutputPreview from "../components/OutputPreview";

export default function Fade({ audioData, onProcess, onAccept, processing, onFadePreview }) {
  const maxDuration = Math.max(0.01, Math.min(10, audioData.duration));
  useEffect(() => {
    setResult(null);
  }, [audioData]);
  const [fadeInDuration, setFadeInDuration] = useState(Math.min(0.5, maxDuration));
  const [fadeOutDuration, setFadeOutDuration] = useState(Math.min(0.5, maxDuration));
  const [curve, setCurve] = useState("linear");
  const [result, setResult] = useState(null);

  useEffect(() => {
    onFadePreview({ fadeInDuration, fadeOutDuration });
  }, [fadeInDuration, fadeOutDuration, onFadePreview]);

  const apply = async () => {
    const r = await onProcess("/fade", {
      fade_in_duration: fadeInDuration,
      fade_out_duration: fadeOutDuration,
      curve,
    });
    if (r) setResult(r);
  };

  return (
    <div className="tool-page">
      <div className="tool-card controls-card">
        <h2>Fade audio</h2>
        <p>Smooth the clip boundaries to prevent clicks and pops.</p>

        <label>Fade in <strong>{fadeInDuration.toFixed(2)} s</strong></label>
        <input type="range" min="0" max={maxDuration} step=".01" value={fadeInDuration} onChange={e => setFadeInDuration(+e.target.value)} />

        <label>Fade out <strong>{fadeOutDuration.toFixed(2)} s</strong></label>
        <input type="range" min="0" max={maxDuration} step=".01" value={fadeOutDuration} onChange={e => setFadeOutDuration(+e.target.value)} />

        <div className="curve-toggle" role="group" aria-label="Fade curve">
          <button type="button" className={curve === "linear" ? "selected" : ""} onClick={() => setCurve("linear")}>Linear</button>
          <button type="button" className={curve === "exponential" ? "selected" : ""} onClick={() => setCurve("exponential")}>Exponential</button>
        </div>
        <button className="primary-button" onClick={apply} disabled={processing}>{processing ? "Processing..." : "Apply fade"}</button>
      </div>

      <div className="tool-card fade-summary">
        <span className="eyebrow">ORIGINAL AUDIO</span>
        <h2>Fade regions</h2>
        <p>The shaded regions show where the envelope will be applied.</p>
        <div className="fade-summary-grid">
          <div><span>Start</span><strong>{fadeInDuration.toFixed(2)} s</strong></div>
          <div><span>End</span><strong>{fadeOutDuration.toFixed(2)} s</strong></div>
          <div><span>Curve</span><strong>{curve}</strong></div>
        </div>
      </div>

      {result && <OutputPreview result={result} onAccept={onAccept} onDiscard={() => setResult(null)} />}
    </div>
  );
}