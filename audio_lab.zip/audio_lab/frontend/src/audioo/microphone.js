let mediaStream = null;
let audioContext = null;
let sourceNode = null;
let analyserNode = null;
let mediaRecorder = null;

let recordedChunks = [];


export async function startMicrophone(onAudioLevel) {
    if (mediaStream) {
        return;
    }

    mediaStream = await navigator.mediaDevices.getUserMedia({
        audio: {
            echoCancellation: false,
            noiseSuppression: false,
            autoGainControl: false
        }
    });

    audioContext = new AudioContext();

    sourceNode = audioContext.createMediaStreamSource(mediaStream);

    analyserNode = audioContext.createAnalyser();
    analyserNode.fftSize = 2048;
    analyserNode.smoothingTimeConstant = 0.8;

    sourceNode.connect(analyserNode);

    // -----------------------------
    // Microphone level
    // -----------------------------

    const data = new Uint8Array(analyserNode.fftSize);

    const updateLevel = () => {
        if (!analyserNode) return;

        analyserNode.getByteTimeDomainData(data);

        let sum = 0;

        for (let i = 0; i < data.length; i++) {
            const normalized = (data[i] - 128) / 128;
            sum += normalized * normalized;
        }

        const rms = Math.sqrt(sum / data.length);

        if (onAudioLevel) {
            onAudioLevel(rms);
        }

        requestAnimationFrame(updateLevel);
    };

    updateLevel();

    // -----------------------------
    // Recording
    // -----------------------------

    recordedChunks = [];

    mediaRecorder = new MediaRecorder(mediaStream);

    mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
            recordedChunks.push(event.data);
        }
    };

    mediaRecorder.start();
}


export function stopMicrophone() {
    return new Promise((resolve) => {

        if (!mediaStream || !mediaRecorder) {
            resolve(null);
            return;
        }

        mediaRecorder.onstop = async () => {

            try {
                // Create recorded WebM blob
                const recordedBlob = new Blob(
                    recordedChunks,
                    {
                        type: mediaRecorder.mimeType || "audio/webm"
                    }
                );

                // Convert WebM → WAV
                const wavBlob = await convertToWav(recordedBlob);

                // Stop microphone
                mediaStream.getTracks().forEach(
                    track => track.stop()
                );

                mediaStream = null;

                // Disconnect nodes
                if (sourceNode) {
                    sourceNode.disconnect();
                    sourceNode = null;
                }

                if (analyserNode) {
                    analyserNode.disconnect();
                    analyserNode = null;
                }

                if (audioContext) {
                    await audioContext.close();
                    audioContext = null;
                }

                mediaRecorder = null;
                recordedChunks = [];

                resolve(wavBlob);

            } catch (error) {

                console.error(
                    "Microphone WAV conversion error:",
                    error
                );

                resolve(null);
            }
        };

        mediaRecorder.stop();
    });
}


// ---------------------------------------------------------
// Convert recorded browser audio to WAV
// ---------------------------------------------------------

async function convertToWav(blob) {

    const arrayBuffer = await blob.arrayBuffer();

    const decodeContext = new AudioContext();

    const audioBuffer =
        await decodeContext.decodeAudioData(arrayBuffer);

    const channelData =
        audioBuffer.getChannelData(0);

    const sampleRate =
        audioBuffer.sampleRate;

    const wavBuffer =
        encodeWav(channelData, sampleRate);

    await decodeContext.close();

    return new Blob(
        [wavBuffer],
        {
            type: "audio/wav"
        }
    );
}


// ---------------------------------------------------------
// Encode Float32 PCM → WAV
// ---------------------------------------------------------

function encodeWav(samples, sampleRate) {

    const buffer =
        new ArrayBuffer(44 + samples.length * 2);

    const view =
        new DataView(buffer);

    writeString(view, 0, "RIFF");

    view.setUint32(
        4,
        36 + samples.length * 2,
        true
    );

    writeString(view, 8, "WAVE");

    writeString(view, 12, "fmt ");

    view.setUint32(16, 16, true);

    // PCM
    view.setUint16(20, 1, true);

    // Mono
    view.setUint16(22, 1, true);

    view.setUint32(
        24,
        sampleRate,
        true
    );

    // Byte rate
    view.setUint32(
        28,
        sampleRate * 2,
        true
    );

    // Block align
    view.setUint16(32, 2, true);

    // 16-bit PCM
    view.setUint16(34, 16, true);

    writeString(view, 36, "data");

    view.setUint32(
        40,
        samples.length * 2,
        true
    );

    let offset = 44;

    for (let i = 0; i < samples.length; i++) {

        let sample =
            Math.max(-1, Math.min(1, samples[i]));

        sample =
            sample < 0
                ? sample * 0x8000
                : sample * 0x7fff;

        view.setInt16(
            offset,
            sample,
            true
        );

        offset += 2;
    }

    return buffer;
}


function writeString(view, offset, string) {

    for (let i = 0; i < string.length; i++) {

        view.setUint8(
            offset + i,
            string.charCodeAt(i)
        );
    }
}


export function isMicrophoneActive() {
    return mediaStream !== null;
}