import { useRef, useState } from "react";
import Sidebar from "./components/Sidebar";
import TopBar from "./components/TopBar";
import AudioPlayer from "./components/AudioPlayer";
import Waveform from "./components/Waveform";
import Overview from "./pages/Overview";
import Trim from "./pages/Trim";
import Echo from "./pages/Echo";
import Smooth from "./pages/Smooth";
import BassTreble from "./pages/BassTreble";
import NoiseRemoval from "./pages/NoiseRemoval";
import Filter from "./pages/Filter";
import Fade from "./pages/Fade";
import Reverse from "./pages/Reverse";
import BirdID from "./pages/BirdID";
import BPM from "./pages/BPM";
import VoiceStress from "./pages/VoiceStress";
import AutoNoiseCancellation from "./pages/AutoNoiseCancellation";
import {
  createPlayableAudio,
  uploadAudio,
  processAudio
} from "./services/audioApi";
import {
  stopMicrophone
} from "./audioo/microphone";
import "./App.css";

const pages = {
  overview: { title: "Overview", subtitle: "Your current audio project" },
  trim: { title: "Trim", subtitle: "Delete a selected section of the waveform" },
  echo: { title: "Echo", subtitle: "Add a delayed copy of the signal" },
  smooth: { title: "Smooth", subtitle: "Apply a moving-average filter" },
  bass: { title: "Bass & Treble", subtitle: "Shape the frequency content" },
  noise: { title: "Noise Removal", subtitle: "Remove a selected frequency band" },
  filter: { title: "Filter", subtitle: "Keep a selected frequency range" },
  fade: { title: "Fade", subtitle: "Smooth the start and end of the clip" },
  reverse: { title: "Reverse", subtitle: "Play the clip from end to beginning" },
  birdid: { title: "Bird Call ID", subtitle: "Identify a bird species from its call" },
  bpm: { title: "Heartbeat BPM", subtitle: "Calculate heart rate from an audio recording" },

  // =========================
  // VOICE STRESS
  // =========================
  voicestress: {
    title: "Voice Stress",
    subtitle: "Analyze stress-related features in the voice"
  },

  // =========================
  // AUTO NOISE CANCELLATION
  // =========================
  noisecancel: {
    title: "Auto Noise Cancellation",
    subtitle: "Reduce unwanted background noise"
  }
};

function App() {
  const audioRef = useRef(null);
  const [page, setPage] = useState("overview");
  const [audioData, setAudioData] = useState(null);
  const [audioUrl, setAudioUrl] = useState("");
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState("");
  const [fadePreview, setFadePreview] = useState({
    fadeInDuration: 0,
    fadeOutDuration: 0
  });

  const loadResult = async (result, originalFile = null) => {
    const next = {
      ...result,
      file: originalFile,
      shape: result.shape ?? [result.samples],
    };

    setAudioData(next);
    setCurrentTime(0);
    setZoom(1);

    try {
      const url = await createPlayableAudio(
        next.signal,
        next.sample_rate
      );
      setAudioUrl(url);
    } catch (e) {
      setError(e.message);
    }
  };

  const handleUpload = async (file) => {
    setError("");
    setProcessing(true);

    try {
      const result = await uploadAudio(file);
      await loadResult(result, file);
      setPage("overview");
    } catch (e) {
      setError(e.message);
    } finally {
      setProcessing(false);
    }
  };

  // ============================================================
  // MICROPHONE
  // Record microphone audio and send it through the EXISTING
  // upload flow. Nothing else in the project is changed.
  // ============================================================
  const handleMicrophoneStop = async () => {
    setError("");
    setProcessing(true);

    try {
      const blob = await stopMicrophone();

      if (!blob) {
        throw new Error("No microphone recording was captured.");
      }

      const file = new File(
        [blob],
        `microphone-${Date.now()}.webm`,
        {
          type: blob.type || "audio/webm",
        }
      );

      // Use the existing upload system
      await handleUpload(file);

    } catch (e) {
      setError(e.message);
    } finally {
      setProcessing(false);
    }
  };

  const replaceSignal = async (result) => {
    await loadResult(
      result,
      audioData?.file ?? null
    );
  };

  const runProcess = async (endpoint, body) => {
    if (!audioData) return null;

    setError("");
    setProcessing(true);

    try {
      const result = await processAudio(endpoint, {
        signal: audioData.signal,
        sample_rate: audioData.sample_rate,
        ...body,
      });

      return result;
    } catch (e) {
      setError(e.message);
      return null;
    } finally {
      setProcessing(false);
    }
  };

  const seek = (time) => {
    if (!audioRef.current) return;

    audioRef.current.currentTime = Math.max(
      0,
      Math.min(
        time,
        audioData?.duration ?? 0
      )
    );

    setCurrentTime(
      audioRef.current.currentTime
    );
  };

  const play = () => {
    if (!audioRef.current || !audioUrl) return;
    audioRef.current.play();
  };

  const pause = () => {
    audioRef.current?.pause();
  };

  const stop = () => {
    if (!audioRef.current) return;

    audioRef.current.pause();
    audioRef.current.currentTime = 0;
    setCurrentTime(0);
  };

  const exportCurrentAudio = async () => {
    if (!audioData) return;

    try {
      const url = await createPlayableAudio(
        audioData.signal,
        audioData.sample_rate
      );

      const link = document.createElement("a");

      link.href = url;
      link.download =
        `${(audioData.filename || "audio").replace(/\.[^/.]+$/, "")}-processed.wav`;

      link.click();

      setTimeout(
        () => URL.revokeObjectURL(url),
        1000
      );
    } catch (e) {
      setError(e.message);
    }
  };

  const renderPage = () => {
    if (!audioData) {
      return (
        <Overview
          onUpload={handleUpload}
          processing={processing}
        />
      );
    }

    switch (page) {
      case "trim":
        return (
          <Trim
            audioData={audioData}
            onProcess={runProcess}
            onAccept={replaceSignal}
            processing={processing}
          />
        );

      case "echo":
        return (
          <Echo
            audioData={audioData}
            onProcess={runProcess}
            onAccept={replaceSignal}
            processing={processing}
          />
        );

      case "smooth":
        return (
          <Smooth
            audioData={audioData}
            onProcess={runProcess}
            onAccept={replaceSignal}
            processing={processing}
          />
        );

      case "bass":
        return (
          <BassTreble
            audioData={audioData}
            onProcess={runProcess}
            onAccept={replaceSignal}
            processing={processing}
          />
        );

      case "noise":
        return (
          <NoiseRemoval
            audioData={audioData}
            onProcess={runProcess}
            onAccept={replaceSignal}
            processing={processing}
          />
        );

      case "filter":
        return (
          <Filter
            audioData={audioData}
            onProcess={runProcess}
            onAccept={replaceSignal}
            processing={processing}
          />
        );

      case "fade":
        return (
          <Fade
            audioData={audioData}
            onProcess={runProcess}
            onAccept={replaceSignal}
            processing={processing}
            onFadePreview={setFadePreview}
          />
        );

      case "reverse":
        return (
          <Reverse
            audioData={audioData}
            onProcess={runProcess}
            onAccept={replaceSignal}
            processing={processing}
          />
        );

      case "birdid":
        return (
          <BirdID
            audioData={audioData}
            onProcess={runProcess}
            processing={processing}
            onAccept={replaceSignal}
          />
        );

      case "bpm":
        return (
          <BPM
            audioData={audioData}
            processing={processing}
          />
        );

      // ============================================================
      // VOICE STRESS
      // ============================================================
      case "voicestress":
        return (
          <VoiceStress
            audioData={audioData}
            processing={processing}
          />
        );

      // ============================================================
      // AUTO NOISE CANCELLATION
      // ============================================================
      case "noisecancel":
        return (
          <AutoNoiseCancellation
            audioData={audioData}
            onAccept={replaceSignal}
            processing={processing}
          />
        );

      default:
        return (
          <Overview
            audioData={audioData}
            onUpload={handleUpload}
            processing={processing}
          />
        );
    }
  };

  return (
    <div className="app-shell">
      <Sidebar
        page={page}
        setPage={setPage}
        hasAudio={!!audioData}
      />

      <main className="main-area">
<TopBar
  title={pages[page].title}
  subtitle={pages[page].subtitle}
  onUpload={handleUpload}
  onMicrophoneStop={handleMicrophoneStop}
  hasAudio={!!audioData}
  processing={processing}
  onExport={exportCurrentAudio}
/>

        {audioData && (
          <>
            <section className="workspace-waveform">
              <div className="section-heading">
                <div>
                  <h2>
                    {audioData.filename || "Current audio"}
                  </h2>

                  <span>
                    {audioData.duration.toFixed(2)} s ·{" "}
                    {audioData.sample_rate} Hz
                  </span>
                </div>

                <div className="zoom-controls">
                  <button
                    onClick={() =>
                      setZoom(z =>
                        Math.max(1, z / 1.5)
                      )
                    }
                  >
                    −
                  </button>

                  <span>
                    {zoom.toFixed(1)}×
                  </span>

                  <button
                    onClick={() =>
                      setZoom(z =>
                        Math.min(16, z * 1.5)
                      )
                    }
                  >
                    +
                  </button>

                  <button
                    onClick={() => setZoom(1)}
                  >
                    Reset
                  </button>
                </div>
              </div>

              <Waveform
                signal={audioData.signal}
                duration={audioData.duration}
                currentTime={currentTime}
                onSeek={seek}
                zoom={zoom}
                fadeInDuration={
                  page === "fade"
                    ? fadePreview.fadeInDuration
                    : 0
                }
                fadeOutDuration={
                  page === "fade"
                    ? fadePreview.fadeOutDuration
                    : 0
                }
              />
            </section>

            <AudioPlayer
              audioRef={audioRef}
              src={audioUrl}
              isPlaying={isPlaying}
              currentTime={currentTime}
              duration={audioData.duration}
              onPlay={play}
              onPause={pause}
              onStop={stop}
              onSeek={seek}
              onTimeUpdate={setCurrentTime}
              onEnded={() =>
                setIsPlaying(false)
              }
              setIsPlaying={setIsPlaying}
            />
          </>
        )}

        {error && (
          <div className="error-banner">
            {error}
          </div>
        )}

        <section className="page-content">
          {renderPage()}
        </section>
      </main>
    </div>
  );
}

export default App;