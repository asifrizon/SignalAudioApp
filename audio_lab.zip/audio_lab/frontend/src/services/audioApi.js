const API = "http://127.0.0.1:5000";

async function jsonRequest(endpoint, body) {
  const response = await fetch(`${API}${endpoint}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  const result = await response.json();

  if (!response.ok) {
    throw new Error(result.error || "Audio processing failed.");
  }

  return result;
}

export async function uploadAudio(file) {
  const formData = new FormData();
  formData.append("audio", file);

  const response = await fetch(`${API}/upload`, {
    method: "POST",
    body: formData,
  });

  const result = await response.json();

  if (!response.ok) {
    throw new Error(result.error || "Audio upload failed.");
  }

  return result;
}

export async function createPlayableAudio(signal, sampleRate) {
  const response = await fetch(`${API}/create-audio`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ signal, sample_rate: sampleRate }),
  });

  if (!response.ok) throw new Error("Could not create playable audio.");

  const blob = await response.blob();
  return URL.createObjectURL(blob);
}

export function processAudio(endpoint, body) {
  return jsonRequest(endpoint, body);
}

// ============================================================
// VOICE STRESS ANALYSIS
// ============================================================

export async function analyzeVoiceStress(signal, sampleRate) {
  const response = await fetch(`${API}/voice-stress`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      signal: signal,
      sample_rate: sampleRate,
    }),
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(
      data.error || "Voice stress analysis failed"
    );
  }

  return data;
}


// ============================================================
// AUTO NOISE CANCELLATION
// ============================================================

export async function removeBackgroundNoise(signal, sampleRate) {
  const response = await fetch(`${API}/auto-noise-cancellation`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      signal: signal,
      sample_rate: sampleRate,
    }),
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(
      data.error || "Auto noise cancellation failed"
    );
  }

  return data;
}