import { useEffect, useRef, useState } from "react";
import { createPlayableAudio } from "../services/audioApi";
import Waveform from "./Waveform";

export default function OutputPreview({ result, onAccept, onDiscard }) {
  const audioRef = useRef(null);
  const [url, setUrl] = useState("");
  const [playing, setPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);

  useEffect(() => {
    let active = true;
    let generatedUrl = "";
    createPlayableAudio(result.signal, result.sample_rate).then(u => {
      generatedUrl = u;
      if (active) setUrl(u);
    });
    return () => {
      active = false;
      if (generatedUrl) URL.revokeObjectURL(generatedUrl);
    };
  }, [result]);

  useEffect(() => {
    setCurrentTime(0);
    setPlaying(false);
    if (audioRef.current) audioRef.current.currentTime = 0;
  }, [result]);

  const seek = (time) => {
    if (!audioRef.current) return;
    const nextTime = Math.max(0, Math.min(time, result.duration));
    audioRef.current.currentTime = nextTime;
    setCurrentTime(nextTime);
  };

  const download = () => {
    if (!url) return;
    const link = document.createElement("a");
    link.href = url;
    link.download = "processed-audio.wav";
    link.click();
  };

  return (
    <div className="tool-card output-card">
      <div>
        <span className="eyebrow">RESULT</span>
        <h2>Processed audio</h2>
        <p>{result.samples.toLocaleString()} samples · {result.duration.toFixed(2)} seconds</p>
      </div>

      <Waveform
        signal={result.signal}
        duration={result.duration}
        currentTime={currentTime}
        onSeek={seek}
        zoom={1}
      />

      <audio
        ref={audioRef}
        src={url}
        onTimeUpdate={e => setCurrentTime(e.currentTarget.currentTime)}
        onLoadedMetadata={e => setCurrentTime(e.currentTarget.currentTime)}
        onClick={() => seek(currentTime)}
        onEnded={() => setPlaying(false)}
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
      />

      <div className="output-actions">
        <button className="primary-button" onClick={() => playing ? audioRef.current.pause() : audioRef.current.play()}>
          {playing ? "Pause result" : "Play result"}
        </button>
        <button className="secondary-button" onClick={download} disabled={!url}>Export WAV</button>
        <button className="primary-button" onClick={() => onAccept(result)}>Keep as current audio</button>
        <button className="text-button" onClick={onDiscard}>Discard</button>
      </div>
    </div>
  );
}
