import { useEffect, useRef } from "react";

function envelope(signal, width, zoom) {
  const visible = Math.min(signal.length, Math.max(width * 2, Math.floor(signal.length / zoom)));
  const start = Math.max(0, Math.floor((signal.length - visible) / 2));
  const step = Math.max(1, Math.floor(visible / width));
  const result = [];

  for (let i = start; i < start + visible; i += step) {
    const end = Math.min(i + step, signal.length);
    let min = 1, max = -1;
    for (let j = i; j < end; j++) {
      const v = signal[j];
      if (v < min) min = v;
      if (v > max) max = v;
    }
    result.push([min, max]);
  }
  return result;
}

export default function Waveform({ signal, duration, currentTime, onSeek, zoom, fadeInDuration = 0, fadeOutDuration = 0, height = 260 }) {
  const canvasRef = useRef(null);
  const boxRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const box = boxRef.current;
    if (!canvas || !box || !signal?.length) return;

    const dpr = window.devicePixelRatio || 1;
    const width = box.clientWidth;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;

    const ctx = canvas.getContext("2d");
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, width, height);

    ctx.fillStyle = "#fbfcfe";
    ctx.fillRect(0, 0, width, height);

    const mid = height / 2;

    // grid
    ctx.strokeStyle = "#e8edf3";
    ctx.lineWidth = 1;
    for (let i = 0; i <= 8; i++) {
      const x = (i / 8) * width;
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke();
    }
    for (let i = 0; i <= 4; i++) {
      const y = (i / 4) * height;
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(width, y); ctx.stroke();
    }

    // zero axis
    ctx.strokeStyle = "#b9c2ce";
    ctx.beginPath(); ctx.moveTo(0, mid); ctx.lineTo(width, mid); ctx.stroke();

    const env = envelope(signal, Math.floor(width), zoom);

    if (fadeInDuration > 0) {
      ctx.fillStyle = "rgba(239, 68, 68, 0.14)";
      ctx.fillRect(0, 0, Math.min(width, (fadeInDuration / duration) * width), height);
    }
    if (fadeOutDuration > 0) {
      ctx.fillStyle = "rgba(239, 68, 68, 0.14)";
      const fadeWidth = Math.min(width, (fadeOutDuration / duration) * width);
      ctx.fillRect(width - fadeWidth, 0, fadeWidth, height);
    }

    ctx.strokeStyle = "#2563eb";
    ctx.lineWidth = 1.5;
    ctx.beginPath();

    env.forEach(([min, max], x) => {
      const y1 = mid - max * (height * 0.43);
      const y2 = mid - min * (height * 0.43);
      ctx.moveTo(x, y1);
      ctx.lineTo(x, y2);
    });
    ctx.stroke();

    // playhead
    const x = duration ? (currentTime / duration) * width : 0;
    ctx.strokeStyle = "#ef4444";
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke();

    ctx.fillStyle = "#ef4444";
    ctx.beginPath();
    ctx.moveTo(x - 6, 0); ctx.lineTo(x + 6, 0); ctx.lineTo(x, 8); ctx.closePath();
    ctx.fill();
  }, [signal, duration, currentTime, zoom, fadeInDuration, fadeOutDuration, height]);

  const seekFromPointer = (e) => {
    const rect = canvasRef.current.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    onSeek(ratio * duration);
  };

  return (
    <div className="waveform-box" ref={boxRef}>
      <canvas ref={canvasRef} onPointerDown={seekFromPointer} />
      <div className="waveform-axis">
        <span>0:00</span>
        <span>{(duration / 2).toFixed(1)}s</span>
        <span>{duration.toFixed(1)}s</span>
      </div>
    </div>
  );
}
