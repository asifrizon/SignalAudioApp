import { useState } from "react";
import { startMicrophone } from "../audioo/microphone";

export default function TopBar({
  title,
  subtitle,
  onUpload,
  onMicrophoneStop,
  hasAudio,
  processing,
  onExport,
}) {
  const [micActive, setMicActive] = useState(false);
  const [micLevel, setMicLevel] = useState(0);

  const handleMicrophone = async () => {
    // STOP MICROPHONE
    if (micActive) {
      setMicActive(false);
      setMicLevel(0);

      try {
        await onMicrophoneStop();
      } catch (error) {
        console.error("Microphone stop error:", error);
      }

      return;
    }

    // START MICROPHONE
    try {
      await startMicrophone((level) => {
        setMicLevel(level);
      });

      setMicActive(true);

    } catch (error) {
      console.error("Microphone error:", error);

      alert(
        "Could not access the microphone. Please allow microphone permission."
      );
    }
  };

  return (
    <header className="topbar">

      <div>
        <h1>{title}</h1>
        <p>{subtitle}</p>
      </div>

      <div className="topbar-actions">

        {/* Existing Export */}
        {hasAudio && (
          <button
            className="secondary-button"
            onClick={onExport}
            disabled={processing}
          >
            Export WAV
          </button>
        )}

        {/* Existing Upload */}
        <button
          className="upload-button"
          onClick={() =>
            document
              .getElementById("global-audio-input")
              ?.click()
          }
          disabled={processing || micActive}
        >
          {processing
            ? "Processing…"
            : hasAudio
            ? "Import another audio"
            : "Import audio"}
        </button>

        {/* Microphone */}
        <button
          className={`microphone-button ${
            micActive ? "microphone-active" : ""
          }`}
          onClick={handleMicrophone}
          disabled={processing}
        >
          {micActive
            ? "🔴 Stop Microphone"
            : "🎙️ Microphone"}
        </button>

        {/* Microphone Level */}
        {micActive && (
          <div className="microphone-level">

            <span>Mic</span>

            <div className="microphone-level-bar">

              <div
                className="microphone-level-fill"
                style={{
                  width: `${Math.min(
                    micLevel * 500,
                    100
                  )}%`,
                }}
              />

            </div>

          </div>
        )}

      </div>

      {/* Existing File Input */}
      <input
        id="global-audio-input"
        hidden
        type="file"
        accept=".wav,.mp3,audio/wav,audio/mpeg"
        onChange={(e) => {

          if (e.target.files?.[0]) {
            onUpload(e.target.files[0]);
          }

          e.target.value = "";

        }}
      />

    </header>
  );
}