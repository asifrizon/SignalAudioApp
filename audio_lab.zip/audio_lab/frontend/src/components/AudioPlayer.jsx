export default function AudioPlayer({
  audioRef, src, isPlaying, currentTime, duration,
  onPlay, onPause, onStop, onSeek, onTimeUpdate, onEnded, setIsPlaying
}) {
  const format = (seconds) => {
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  };

  return (
    <div className="transport">
      <audio
        ref={audioRef}
        src={src}
        onTimeUpdate={e => onTimeUpdate(e.currentTarget.currentTime)}
        onEnded={onEnded}
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
      />
      <button className="transport-main" onClick={isPlaying ? onPause : onPlay}>
        {isPlaying ? "❚❚" : "▶"}
      </button>
      <button className="transport-stop" onClick={onStop}>■</button>
      <span className="time">{format(currentTime)}</span>
      <input
        className="transport-range"
        type="range"
        min="0"
        max={duration || 0}
        step="0.01"
        value={Math.min(currentTime, duration || 0)}
        onChange={e => onSeek(Number(e.target.value))}
      />
      <span className="time">{format(duration || 0)}</span>
    </div>
  );
}
