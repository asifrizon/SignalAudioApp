import { useEffect, useRef, useState } from "react";

export default function TrimWaveform({ signal, duration, start, end, currentTime, onChange, onSeek, regionLabel = "DELETE", waveformColor = "#64748b", selectionColor = "rgba(239, 68, 68, 0.14)", handleColor = "#dc2626", showLabels = true, showPlaybackControls = true, showPlaybackButtons = true }) {
  const canvasRef = useRef(null);
  const boxRef = useRef(null);
  const [dragging, setDragging] = useState(null);
  const waveformCache = useRef(null);

  const timeFromX = (x) => {
    const rect = canvasRef.current.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (x - rect.left) / rect.width));
    return ratio * duration;
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    const box = boxRef.current;
    if (!canvas || !box || !signal?.length) return;

    const dpr = devicePixelRatio || 1;
    const width = box.clientWidth;
    const height = 280;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;

    const ctx = canvas.getContext("2d");
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = "#fbfcfe";
    ctx.fillRect(0, 0, width, height);

    const mid = height / 2;

    ctx.strokeStyle = "#e7ebf0";
    for (let i = 0; i <= 10; i++) {
      const x = (i / 10) * width;
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke();
    }
    for (let i = 0; i <= 4; i++) {
      const y = (i / 4) * height;
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(width, y); ctx.stroke();
    }

    // Cache the expensive waveform buckets; dragging only redraws the overlays.
    const cacheKey = `${signal.length}:${width}`;
    if (!waveformCache.current || waveformCache.current.key !== cacheKey || waveformCache.current.signal !== signal) {
      const bucket = Math.max(1, Math.floor(signal.length / width));
      const points = [];
      for (let x = 0; x < width; x++) {
        const from = x * bucket;
        const to = Math.min(signal.length, from + bucket);
        let min = 1, max = -1;
        for (let i = from; i < to; i++) {
          min = Math.min(min, signal[i]);
          max = Math.max(max, signal[i]);
        }
        points.push([min, max]);
      }
      waveformCache.current = { key: cacheKey, signal, points };
    }

    ctx.strokeStyle = waveformColor;
    ctx.lineWidth = 1;
    ctx.beginPath();

    waveformCache.current.points.forEach(([min, max], x) => {
      ctx.moveTo(x, mid - max * height * .42);
      ctx.lineTo(x, mid - min * height * .42);
    });
    ctx.stroke();

  }, [signal, waveformColor]);

  useEffect(() => {
    const move = (e) => {
      if (!dragging) return;
      const t = timeFromX(e.clientX);

      if (dragging === "start") {
        onChange(Math.min(t, end - 0.01), end);
      } else {
        onChange(start, Math.max(t, start + 0.01));
      }
    };

    const up = () => setDragging(null);
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    return () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
  }, [dragging, start, end, onChange]);

  const down = (e) => {
    const t = timeFromX(e.clientX);
    if (Math.abs(t - start) < Math.abs(t - end)) setDragging("start");
    else setDragging("end");
  };

  return (
    <div className="trim-waveform" ref={boxRef}>
      <canvas ref={canvasRef} onPointerDown={down} />
      <div className="trim-selection-overlay" style={{ left: `${(start / duration) * 100}%`, width: `${((end - start) / duration) * 100}%`, background: selectionColor }} />
      {[start, end].map((time, index) => (
        <div className="trim-handle-overlay" key={index} style={{ left: `${(time / duration) * 100}%`, background: handleColor, color: handleColor }} onPointerDown={event => { event.stopPropagation(); setDragging(index === 0 ? "start" : "end"); }}>
          {showLabels && <span>{regionLabel} {index === 0 ? "START" : "END"}</span>}
        </div>
      ))}
      <div className="trim-playhead-overlay" style={{ left: `${(currentTime / duration) * 100}%` }} />
      {showPlaybackControls && <div className="trim-times">
        <span>{regionLabel}: {start.toFixed(2)}s → {end.toFixed(2)}s</span>
        {showPlaybackButtons && <>
          <button onClick={(e) => { e.stopPropagation(); onSeek(start); }}>Play from start</button>
          <button onClick={(e) => { e.stopPropagation(); onSeek(end); }}>Play after deletion</button>
        </>}
      </div>}
    </div>
  );
}
