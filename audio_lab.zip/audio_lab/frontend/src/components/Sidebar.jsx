const items = [
  ["overview", "Overview", "⌂"],
  ["trim", "Trim", "✂"],
  ["echo", "Echo", "◌"],
  ["smooth", "Smooth", "≈"],
  ["bass", "Bass & Treble", "♫"],
  ["noise", "Noise Removal", "⌁"],
  ["filter", "Filter", "◒"],
  ["fade", "Fade", "↗"],
  ["reverse", "Reverse", "↔"],
  ["birdid", "Bird Call ID", "🐦"],
  ["bpm", "Heartbeat BPM", "♥"],

  // =========================
  // VOICE STRESS
  // =========================
  ["voicestress", "Voice Stress", "🎙"],

  // =========================
  // AUTO NOISE CANCELLATION
  // =========================
  ["noisecancel", "Auto Noise Cancellation", "🔇"],
];

export default function Sidebar({ page, setPage, hasAudio }) {
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-mark">♫</div>
        <div>
          <strong>Audio_Spectra</strong>
          <small>Signal Editor</small>
        </div>
      </div>

      <div className="nav-label">EDIT</div>

      <nav>
        {items.map(([id, label, icon]) => (
          <button
            key={id}
            className={`nav-item ${page === id ? "active" : ""}`}
            disabled={!hasAudio && id !== "overview"}
            onClick={() => setPage(id)}
          >
            <span className="nav-icon">{icon}</span>
            {label}
          </button>
        ))}
      </nav>

      <div className="sidebar-footer">
        <span>DSP Audio Editor</span>
        <small>WAV / MP3 workflow</small>
      </div>
    </aside>
  );
}