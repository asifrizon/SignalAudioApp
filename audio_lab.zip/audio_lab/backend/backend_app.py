from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import soundfile as sf
import numpy as np
from io import BytesIO
from scipy.signal import fftconvolve

from bird_identifier import (
    identify_bird,
    identify_bird_segments,
)

from heartbeat_analyzer import analyze_heartbeat

from voice_stress_analyzer import analyze_voice_stress

from noise_canceller import remove_background_noise

app = Flask(__name__)
CORS(app)


@app.route("/")
def home():
    return "Audio Editor Backend is running!"


@app.route("/upload", methods=["POST"])
def upload_audio():
    file = request.files["audio"]
    data, fs = sf.read(file)

    if data.ndim == 1:
        channel_data = data.tolist()
    else:
        channel_data = data[:, 0].tolist()

    return jsonify({
        "filename": file.filename,
        "sample_rate": fs,
        "samples": len(channel_data),
        "shape": list(data.shape),
        "dtype": str(data.dtype),
        "channels": 1 if data.ndim == 1 else data.shape[1],
        "duration": len(channel_data) / fs,
        "signal": channel_data
    })


@app.route("/delete-section", methods=["POST"])
def delete_section():
    data = request.get_json()

    signal = np.array(data["signal"], dtype=np.float64)
    sample_rate = data["sample_rate"]

    start_sample = int(data["start_time"] * sample_rate)
    end_sample = int(data["end_time"] * sample_rate)

    start_sample = max(0, start_sample)
    end_sample = min(len(signal), end_sample)

    if start_sample >= end_sample:
        return jsonify({"error": "Invalid deletion range."}), 400

    # Delete x[start_sample:end_sample].
    # Keep everything before and after the selected region.
    result_signal = np.concatenate([
        signal[:start_sample],
        signal[end_sample:]
    ])

    return jsonify({
        "signal": result_signal.tolist(),
        "sample_rate": sample_rate,
        "samples": len(result_signal),
        "duration": len(result_signal) / sample_rate,
        "deleted_start_sample": start_sample,
        "deleted_end_sample": end_sample
    })


@app.route("/create-audio", methods=["POST"])
def create_audio():
    data = request.get_json()
    signal = np.array(data["signal"], dtype=np.float64)
    sample_rate = data["sample_rate"]

    audio_buffer = BytesIO()
    sf.write(audio_buffer, signal, sample_rate, format="WAV")
    audio_buffer.seek(0)

    return send_file(
        audio_buffer,
        mimetype="audio/wav",
        as_attachment=False,
        download_name="processed.wav"
    )


@app.route("/echo", methods=["POST"])
def echo_audio():
    data = request.get_json()
    signal = np.array(data["signal"], dtype=np.float64)
    sample_rate = data["sample_rate"]

    delay = data["delay"]
    gain = data["gain"]
    delay_samples = int(delay * sample_rate)

    if delay_samples <= 0:
        return jsonify({"error": "Delay must be greater than 0."}), 400
    if gain < 0 or gain > 5:
        return jsonify({"error": "Gain must be between 0 and 5."}), 400

    n = len(signal)
    out_len = n + delay_samples

    echo_signal = np.zeros(out_len, dtype=np.float64)
    echo_signal[:n] = signal                                   # dry signal
    echo_signal[delay_samples:delay_samples + n] += gain * signal  # delayed echo

    return jsonify({
        "signal": echo_signal.tolist(),
        "sample_rate": sample_rate,
        "samples": len(echo_signal),
        "duration": len(echo_signal) / sample_rate,
        "delay_samples": delay_samples
    })

@app.route("/smooth", methods=["POST"])
def smooth_audio():
    data = request.get_json()
    signal = np.array(data["signal"], dtype=np.float64)
    sample_rate = data["sample_rate"]
    window_size = int(data["window_size"])

    if window_size < 1:
        return jsonify({"error": "Window size must be at least 1."}), 400
    if window_size % 2 == 0:
        return jsonify({"error": "Window size must be odd."}), 400
    if window_size > len(signal):
        return jsonify({"error": "Window size is larger than the signal."}), 400

    kernel = np.ones(window_size) / window_size
    smoothed_signal = fftconvolve(signal, kernel, mode="same")

    return jsonify({
        "signal": smoothed_signal.tolist(),
        "sample_rate": sample_rate,
        "samples": len(smoothed_signal),
        "duration": len(smoothed_signal) / sample_rate,
        "window_size": window_size
    })


@app.route("/bass-treble", methods=["POST"])
def bass_treble_audio():
    data = request.get_json()
    signal = np.array(data["signal"], dtype=np.float64)
    sample_rate = data["sample_rate"]

    bass_gain_db = float(data["bass_gain"])
    treble_gain_db = float(data["treble_gain"])
    band_start_frequency = float(data.get("band_start_frequency", 0))
    band_end_frequency = float(data.get("band_end_frequency", sample_rate / 2))
    band_gain_db = float(data.get("band_gain", 0))

    if band_start_frequency < 0 or band_end_frequency > sample_rate / 2 or band_start_frequency >= band_end_frequency:
        return jsonify({"error": "Custom frequency range must be within 0 Hz and the Nyquist frequency."}), 400

    X = np.fft.rfft(signal)
    frequencies = np.fft.rfftfreq(len(signal), d=1 / sample_rate)

    H = np.ones(len(frequencies))
    H[frequencies < 300] *= 10 ** (bass_gain_db / 20)
    H[frequencies > 3000] *= 10 ** (treble_gain_db / 20)
    custom_band = (frequencies >= band_start_frequency) & (frequencies <= band_end_frequency)
    H[custom_band] *= 10 ** (band_gain_db / 20)

    result_signal = np.fft.irfft(X * H, n=len(signal))
    result_signal = np.clip(result_signal, -1.0, 1.0)

    return jsonify({
        "signal": result_signal.tolist(),
        "sample_rate": sample_rate,
        "samples": len(result_signal),
        "duration": len(result_signal) / sample_rate
    })


@app.route("/remove-noise", methods=["POST"])
def remove_noise():
    data = request.get_json()
    signal = np.array(data["signal"], dtype=np.float64)
    sample_rate = data["sample_rate"]

    start_frequency = float(data["start_frequency"])
    end_frequency = float(data["end_frequency"])

    if start_frequency < 0 or end_frequency > sample_rate / 2 or start_frequency >= end_frequency:
        return jsonify({"error": "Frequency range must be within 0 Hz and the Nyquist frequency."}), 400

    X = np.fft.rfft(signal)
    frequencies = np.fft.rfftfreq(len(signal), d=1 / sample_rate)

    noise_mask = (
        (frequencies >= start_frequency) &
        (frequencies <= end_frequency)
    )

    X[noise_mask] = 0

    cleaned_signal = np.fft.irfft(X, n=len(signal))
    cleaned_signal = np.clip(cleaned_signal, -1.0, 1.0)

    return jsonify({
        "signal": cleaned_signal.tolist(),
        "sample_rate": sample_rate,
        "samples": len(cleaned_signal),
        "duration": len(cleaned_signal) / sample_rate,
        "removed_start_frequency": start_frequency,
        "removed_end_frequency": end_frequency
    })


@app.route("/add-noise", methods=["POST"])
def add_noise():
    data = request.get_json()
    signal = np.array(data["signal"], dtype=np.float64)
    sample_rate = int(data["sample_rate"])
    start_time = float(data["start_time"])
    end_time = float(data["end_time"])
    noise_frequency = float(data["noise_frequency"])
    noise_amplitude = float(data["noise_amplitude"])

    if start_time < 0 or end_time > len(signal) / sample_rate or start_time >= end_time:
        return jsonify({"error": "Noise time range must be within the audio duration."}), 400
    if noise_frequency < 0 or noise_frequency > sample_rate / 2:
        return jsonify({"error": "Noise frequency must be within 0 Hz and the Nyquist frequency."}), 400
    if noise_amplitude < 0 or noise_amplitude > 1:
        return jsonify({"error": "Noise amplitude must be between 0 and 1."}), 400

    start_sample = max(0, int(start_time * sample_rate))
    end_sample = min(len(signal), int(end_time * sample_rate))
    sample_times = np.arange(start_sample, end_sample) / sample_rate
    noise = noise_amplitude * np.sin(2 * np.pi * noise_frequency * sample_times)
    result_signal = signal.copy()
    result_signal[start_sample:end_sample] += noise
    result_signal = np.clip(result_signal, -1.0, 1.0)
    return jsonify({
        "signal": result_signal.tolist(),
        "sample_rate": sample_rate,
        "samples": len(result_signal),
        "duration": len(result_signal) / sample_rate,
        "noise_start_time": start_sample / sample_rate,
        "noise_end_time": end_sample / sample_rate,
        "noise_frequency": noise_frequency,
        "noise_amplitude": noise_amplitude
    })


@app.route("/filter", methods=["POST"])
def filter_audio():
    data = request.get_json()
    signal = np.array(data["signal"], dtype=np.float64)
    sample_rate = data["sample_rate"]
    filter_type = data["filter_type"]
    nyquist = sample_rate / 2

    if filter_type not in {"high-pass", "low-pass", "band-pass"}:
        return jsonify({"error": "Unknown filter type."}), 400

    frequencies = np.fft.rfftfreq(len(signal), d=1 / sample_rate)
    if filter_type == "band-pass":
        start_frequency = float(data["start_frequency"])
        end_frequency = float(data["end_frequency"])
        if start_frequency < 0 or end_frequency > nyquist or start_frequency >= end_frequency:
            return jsonify({"error": "Band range must be within 0 Hz and the Nyquist frequency."}), 400
        mask = (frequencies >= start_frequency) & (frequencies <= end_frequency)
    else:
        cutoff_frequency = float(data["cutoff_frequency"])
        if cutoff_frequency < 0 or cutoff_frequency > nyquist:
            return jsonify({"error": "Cutoff must be within 0 Hz and the Nyquist frequency."}), 400
        mask = frequencies >= cutoff_frequency if filter_type == "high-pass" else frequencies <= cutoff_frequency

    result_signal = np.fft.irfft(np.fft.rfft(signal) * mask, n=len(signal))
    result_signal = np.clip(result_signal, -1.0, 1.0)

    return jsonify({
        "signal": result_signal.tolist(),
        "sample_rate": sample_rate,
        "samples": len(result_signal),
        "duration": len(result_signal) / sample_rate,
        "filter_type": filter_type
    })


@app.route("/fade", methods=["POST"])
def fade_audio():
    data = request.get_json()
    signal = np.array(data["signal"], dtype=np.float64)
    sample_rate = int(data["sample_rate"])
    fade_in_duration = float(data.get("fade_in_duration", 0))
    fade_out_duration = float(data.get("fade_out_duration", 0))
    curve = data.get("curve", "linear")

    if fade_in_duration < 0 or fade_out_duration < 0:
        return jsonify({"error": "Fade durations cannot be negative."}), 400
    if curve not in {"linear", "exponential"}:
        return jsonify({"error": "Curve must be linear or exponential."}), 400

    fade_in_samples = min(len(signal), int(fade_in_duration * sample_rate))
    fade_out_samples = min(len(signal), int(fade_out_duration * sample_rate))
    envelope = np.ones(len(signal))

    if fade_in_samples > 0:
        progress = np.linspace(0, 1, fade_in_samples)
        envelope[:fade_in_samples] *= progress if curve == "linear" else progress ** 2
    if fade_out_samples > 0:
        progress = np.linspace(1, 0, fade_out_samples)
        envelope[-fade_out_samples:] *= progress if curve == "linear" else progress ** 2

    result_signal = np.clip(signal * envelope, -1.0, 1.0)

    return jsonify({
        "signal": result_signal.tolist(),
        "sample_rate": sample_rate,
        "samples": len(result_signal),
        "duration": len(result_signal) / sample_rate,
        "fade_in_duration": fade_in_samples / sample_rate,
        "fade_out_duration": fade_out_samples / sample_rate,
        "curve": curve
    })


@app.route("/reverse", methods=["POST"])
def reverse_audio():
    data = request.get_json()
    signal = np.array(data["signal"], dtype=np.float64)
    sample_rate = data["sample_rate"]
    reversed_signal = signal[::-1]

    return jsonify({
        "signal": reversed_signal.tolist(),
        "sample_rate": sample_rate,
        "samples": len(reversed_signal),
        "duration": len(reversed_signal) / sample_rate
    })

@app.route("/identify-bird", methods=["POST"])
def identify_bird_route():

    print("\n==============================")
    print("IDENTIFY BIRD REQUEST RECEIVED")
    print("==============================")

    try:
        data = request.get_json()

        if not data:
            print("ERROR: No JSON data received")
            return jsonify({"error": "No JSON data received"}), 400

        if "signal" not in data:
            print("ERROR: signal missing")
            return jsonify({"error": "Audio signal is missing"}), 400

        if "sample_rate" not in data:
            print("ERROR: sample_rate missing")
            return jsonify({"error": "Sample rate is missing"}), 400

        signal = np.array(
            data["signal"],
            dtype=np.float64
        )

        sample_rate = int(data["sample_rate"])

        print("Signal length:", len(signal))
        print("Sample rate:", sample_rate)
        print("Duration:", len(signal) / sample_rate)

        # --------------------------------
        # STEP 1
        # --------------------------------

        print("STEP 1: Running identify_bird()...")

        result = identify_bird(
            signal,
            sample_rate
        )

        print("STEP 1 COMPLETE")

        # --------------------------------
        # STEP 2
        # --------------------------------

        print("STEP 2: Running identify_bird_segments()...")

        try:

            bird_segments = identify_bird_segments(
                signal,
                sample_rate
            )

            print(
                "STEP 2 COMPLETE - segments:",
                len(bird_segments)
            )

        except Exception as e:

            print(
                "STEP 2 FAILED:",
                repr(e)
            )

            bird_segments = []

        # --------------------------------
        # STEP 3
        # --------------------------------

        print("STEP 3: Running frequency analysis...")

        frequency_analysis = analyze_audio_frequency(
            signal,
            sample_rate
        )

        print("STEP 3 COMPLETE")

        # --------------------------------
        # BUILD RESPONSE
        # --------------------------------

        result["audio_analysis"] = frequency_analysis

        result["bird_segments"] = bird_segments

        result["number_of_bird_segments"] = len(
            bird_segments
        )

        print("RESPONSE READY")

        return jsonify(result)

    except ValueError as e:

        print(
            "VALUE ERROR:",
            repr(e)
        )

        return jsonify({
            "error": str(e)
        }), 400

    except Exception as e:

        print(
            "BIRD IDENTIFICATION ERROR:",
            repr(e)
        )

        import traceback

        traceback.print_exc()

        return jsonify({
            "error": "Bird identification failed: " + str(e)
        }), 500
    
def analyze_audio_frequency(signal, sample_rate):
    """
    Analyze the audio signal in the frequency domain using FFT.

    Returns:
        - duration
        - sampling rate
        - dominant frequency
        - significant frequency range
        - distinct major frequency peaks
        - detected sound segments
    """

    signal = np.asarray(signal, dtype=np.float64)

    if len(signal) == 0:
        raise ValueError("Audio signal is empty.")

    # Remove DC component
    signal = signal - np.mean(signal)

    # FFT
    spectrum = np.fft.rfft(signal)

    # Magnitude spectrum
    magnitude = np.abs(spectrum)

    # Frequency corresponding to each FFT bin
    frequencies = np.fft.rfftfreq(
        len(signal),
        d=1 / sample_rate
    )

    # Ignore DC component (0 Hz)
    if len(magnitude) > 1:
        magnitude[0] = 0

    # ---------------------------------------------------------
    # Dominant frequency
    # ---------------------------------------------------------

    dominant_index = np.argmax(magnitude)

    dominant_frequency = frequencies[dominant_index]

    # ---------------------------------------------------------
    # Significant frequency range
    # ---------------------------------------------------------

    if np.max(magnitude) > 0:

        energy_threshold = np.max(magnitude) * 0.10

        significant_indices = np.where(
            magnitude >= energy_threshold
        )[0]

        if len(significant_indices) > 0:

            actual_frequency_range = [
                float(frequencies[significant_indices[0]]),
                float(frequencies[significant_indices[-1]])
            ]

        else:
            actual_frequency_range = [0.0, 0.0]

    else:
        actual_frequency_range = [0.0, 0.0]

    # ---------------------------------------------------------
    # Find distinct frequency peaks
    # ---------------------------------------------------------

    peaks = []

    if len(magnitude) >= 3 and np.max(magnitude) > 0:

        # A frequency bin is considered a local peak if
        # it is stronger than the bins immediately around it.
        local_peak_indices = []

        for i in range(1, len(magnitude) - 1):

            if (
                magnitude[i] > magnitude[i - 1]
                and magnitude[i] >= magnitude[i + 1]
            ):
                local_peak_indices.append(i)

        # Sort peaks from strongest to weakest
        local_peak_indices.sort(
            key=lambda i: magnitude[i],
            reverse=True
        )

        # Minimum separation between two peaks.
        # 100 Hz means nearby bins are treated as one peak.
        minimum_peak_distance = 100.0

        for index in local_peak_indices:

            frequency = frequencies[index]

            # Ignore very weak peaks
            if magnitude[index] < np.max(magnitude) * 0.10:
                continue

            # Check whether this peak is too close
            # to a peak that was already selected.
            too_close = False

            for existing_peak in peaks:

                if abs(
                    frequency -
                    existing_peak["frequency"]
                ) < minimum_peak_distance:

                    too_close = True
                    break

            if too_close:
                continue

            peaks.append({
                "frequency": float(frequency),
                "magnitude": float(magnitude[index])
            })

            # Keep only the 10 strongest distinct peaks
            if len(peaks) >= 10:
                break

    # ---------------------------------------------------------
    # Detect individual sound segments
    # ---------------------------------------------------------

    segments = detect_audio_segments(
        signal,
        sample_rate
    )

    # ---------------------------------------------------------
    # Final result
    # ---------------------------------------------------------

    return {
        "duration": float(
            len(signal) / sample_rate
        ),

        "sampling_rate": int(sample_rate),

        "dominant_frequency": float(
            dominant_frequency
        ),

        "frequency_range": actual_frequency_range,

        "peaks": peaks,

        "segments": segments,

        "number_of_segments": len(segments)
    }
def detect_audio_segments(signal, sample_rate):
    """
    Detect active sound segments using short-time RMS energy.

    Each detected segment is then analyzed using FFT
    to determine its dominant frequency.
    """

    signal = np.asarray(signal, dtype=np.float64)

    if len(signal) == 0:
        return []

    # Remove DC component
    signal = signal - np.mean(signal)

    # ---------------------------------------------------------
    # Frame settings
    # ---------------------------------------------------------

    frame_duration = 0.05
    hop_duration = 0.025

    frame_size = max(
        1,
        int(frame_duration * sample_rate)
    )

    hop_size = max(
        1,
        int(hop_duration * sample_rate)
    )

    # ---------------------------------------------------------
    # Calculate RMS energy
    # ---------------------------------------------------------

    rms_values = []
    frame_positions = []

    for start in range(
        0,
        len(signal) - frame_size + 1,
        hop_size
    ):

        frame = signal[
            start:start + frame_size
        ]

        rms = np.sqrt(
            np.mean(frame ** 2)
        )

        rms_values.append(rms)
        frame_positions.append(start)

    if not rms_values:
        return []

    rms_values = np.array(rms_values)

    # ---------------------------------------------------------
    # Adaptive sound threshold
    # ---------------------------------------------------------

    threshold = max(
        np.max(rms_values) * 0.15,
        np.mean(rms_values) + np.std(rms_values)
    )

    active = rms_values > threshold

    # ---------------------------------------------------------
    # Group consecutive active frames
    # ---------------------------------------------------------

    segments = []

    segment_start = None

    for i, is_active in enumerate(active):

        if is_active and segment_start is None:

            segment_start = frame_positions[i]

        elif not is_active and segment_start is not None:

            segment_end = (
                frame_positions[i]
                + frame_size
            )

            segments.append({
                "start_sample": segment_start,
                "end_sample": min(
                    segment_end,
                    len(signal)
                )
            })

            segment_start = None

    # If the final segment reaches the end
    if segment_start is not None:

        segments.append({
            "start_sample": segment_start,
            "end_sample": len(signal)
        })

    # ---------------------------------------------------------
    # Analyze each segment using FFT
    # ---------------------------------------------------------

    analyzed_segments = []

    for number, segment in enumerate(
        segments,
        start=1
    ):

        start_sample = segment["start_sample"]
        end_sample = segment["end_sample"]

        segment_signal = signal[
            start_sample:end_sample
        ]

        if len(segment_signal) < 2:
            continue

        # FFT
        spectrum = np.fft.rfft(
            segment_signal
        )

        # Magnitude spectrum
        magnitude = np.abs(spectrum)

        # Frequency bins
        frequencies = np.fft.rfftfreq(
            len(segment_signal),
            d=1 / sample_rate
        )

        # Ignore DC component
        if len(magnitude) > 1:
            magnitude[0] = 0

        # Dominant frequency of this segment
        dominant_index = np.argmax(
            magnitude
        )

        dominant_frequency = (
            frequencies[dominant_index]
        )

        analyzed_segments.append({
            "segment": number,

            "start_time": float(
                start_sample / sample_rate
            ),

            "end_time": float(
                end_sample / sample_rate
            ),

            "duration": float(
                (end_sample - start_sample)
                / sample_rate
            ),

            "dominant_frequency": float(
                dominant_frequency
            )
        })

    return analyzed_segments


@app.route("/calculate-bpm", methods=["POST"])
def calculate_bpm_route():
    data = request.get_json()

    signal = np.array(
        data["signal"],
        dtype=np.float64
    )

    sample_rate = int(data["sample_rate"])

    try:
        result = analyze_heartbeat(
            signal,
            sample_rate
        )

    except ValueError as e:
        return jsonify({
            "error": str(e)
        }), 400

    return jsonify(result)

@app.route("/voice-stress", methods=["POST"])
def voice_stress():
    try:
        data = request.get_json()

        if not data:
            return jsonify({
                "error": "No JSON data received"
            }), 400

        signal = data.get("signal")
        sample_rate = data.get("sample_rate")

        if signal is None:
            return jsonify({
                "error": "Audio signal is missing"
            }), 400

        if sample_rate is None:
            return jsonify({
                "error": "Sample rate is missing"
            }), 400

        # Run the non-ML voice stress analyzer
        result = analyze_voice_stress(
            signal,
            int(sample_rate)
        )

        return jsonify(result)

    except Exception as e:
        print("Voice Stress Error:", e)

        return jsonify({
            "error": str(e)
        }), 500



@app.route("/auto-noise-cancellation", methods=["POST"])
def auto_noise_cancellation():
    try:
        data = request.get_json()

        signal = data.get("signal")
        sample_rate = data.get("sample_rate")

        if signal is None:
            return jsonify({
                "error": "Audio signal is required."
            }), 400

        if sample_rate is None:
            return jsonify({
                "error": "Sample rate is required."
            }), 400

        # Run Auto Noise Cancellation
        result = remove_background_noise(
            signal,
            sample_rate
        )

        return jsonify(result)

    except Exception as e:
        print("Auto Noise Cancellation Error:", e)

        return jsonify({
            "error": str(e)
        }), 500    



if __name__ == "__main__":
    app.run(
    debug=True,
    use_reloader=False
)