# ==========================================================
# BIRD REFERENCE DATABASE
# ==========================================================
#
# Approximate DSP feature ranges for bird-call matching.
# These are illustrative reference ranges, not scientifically
# validated species classifiers.
#
# Frequency values: Hz
# Duration values: seconds
# pulse_rate: calls/notes per second
#
# --------------------------------------------------------
# REFINEMENT NOTE (accuracy pass):
# The previous ranges were very wide and, for several
# species (especially the "new birds"), nearly identical
# to one another (e.g. several birds all shared a
# ~900-6500 Hz bandwidth window). Since the matcher scores
# 1.0 for any value inside a species' range, wide/duplicated
# ranges caused many unrelated species to all score close
# to 100%, producing bunched, uninformative confidences
# (99/98/97%).
#
# This pass narrows each range to better reflect the bird's
# actual typical call envelope and removes duplicated
# profiles, so the same range-scoring math now produces a
# more discriminative spread of confidences instead of
# near-ties. No scoring logic was changed - only the
# reference numbers.
#
# ADDITIONAL PASS: appended a further set of common
# Indian-subcontinent urban/garden birds, cross-checked
# against all existing entries (both "existing" and "new")
# to avoid substantial overlap in dominant_frequency_range
# and pulse_rate_range with any prior species, so these
# also produce discriminative confidences rather than ties.
# --------------------------------------------------------
# ==========================================================

BIRD_DATABASE = {

    # ======================================================
    # EXISTING BIRDS
    # ======================================================

    "american_robin": {
        "common_name": "American Robin",
        "scientific_name": "Turdus migratorius",
        "sound_description": "Clear, warbling phrases of whistled notes, cheerily cheer-up cheerio.",
        "dominant_frequency_range": (1800, 3200),
        "bandwidth_range": (1500, 3600),
        "spectral_centroid_range": (2000, 3000),
        "call_duration_range": (0.09, 0.25),
        "pulse_rate_range": (1.2, 2.6),
        "spectral_flatness_range": (0.05, 0.18),
    },

    "northern_cardinal": {
        "common_name": "Northern Cardinal",
        "scientific_name": "Cardinalis cardinalis",
        "sound_description": "Loud, clear whistled slurs, what-cheer cheer cheer, or a sharp chip note.",
        "dominant_frequency_range": (2200, 4200),
        "bandwidth_range": (1800, 4800),
        "spectral_centroid_range": (2500, 4000),
        "call_duration_range": (0.15, 0.45),
        "pulse_rate_range": (2.2, 4.2),
        "spectral_flatness_range": (0.06, 0.22),
    },

    "black_capped_chickadee": {
        "common_name": "Black-capped Chickadee",
        "scientific_name": "Poecile atricapillus",
        "sound_description": "Pure, whistled two- or three-note fee-bee song, very narrow bandwidth.",
        "dominant_frequency_range": (3500, 4300),
        "bandwidth_range": (3300, 4500),
        "spectral_centroid_range": (3600, 4200),
        "call_duration_range": (0.28, 0.55),
        "pulse_rate_range": (0.6, 1.6),
        "spectral_flatness_range": (0.02, 0.1),
    },

    "blue_jay": {
        "common_name": "Blue Jay",
        "scientific_name": "Cyanocitta cristata",
        "sound_description": "Harsh, broadband jeer or scream, along with softer musical notes.",
        "dominant_frequency_range": (950, 2200),
        "bandwidth_range": (750, 3600),
        "spectral_centroid_range": (1200, 2600),
        "call_duration_range": (0.25, 0.55),
        "pulse_rate_range": (1.0, 2.4),
        "spectral_flatness_range": (0.28, 0.55),
    },

    "house_sparrow": {
        "common_name": "House Sparrow",
        "scientific_name": "Passer domesticus",
        "sound_description": "Rapid, repeated chirps and cheeps, chattering when in groups.",
        "dominant_frequency_range": (2700, 3900),
        "bandwidth_range": (2300, 4300),
        "spectral_centroid_range": (2900, 3700),
        "call_duration_range": (0.05, 0.15),
        "pulse_rate_range": (3.2, 6.2),
        "spectral_flatness_range": (0.12, 0.3),
    },

    "mourning_dove": {
        "common_name": "Mourning Dove",
        "scientific_name": "Zenaida macroura",
        "sound_description": "Low, mournful cooOOoo-woo-woo-woo, slow and narrow-band.",
        "dominant_frequency_range": (330, 550),
        "bandwidth_range": (280, 650),
        "spectral_centroid_range": (350, 520),
        "call_duration_range": (0.40, 0.90),
        "pulse_rate_range": (0.35, 1.1),
        "spectral_flatness_range": (0.03, 0.12),
    },

    "american_crow": {
        "common_name": "American Crow",
        "scientific_name": "Corvus brachyrhynchos",
        "sound_description": "Flat, nasal caw-caw-caw, low-pitched and broadband.",
        "dominant_frequency_range": (500, 1550),
        "bandwidth_range": (400, 2400),
        "spectral_centroid_range": (900, 2650),
        "call_duration_range": (0.15, 0.55),
        "pulse_rate_range": (0.8, 2.8),
        "spectral_flatness_range": (0.28, 0.60),
    },

    "song_sparrow": {
        "common_name": "Song Sparrow",
        "scientific_name": "Melospiza melodia",
        "sound_description": "A few clear notes followed by a buzzy trill, wide frequency sweep.",
        "dominant_frequency_range": (3200, 5500),
        "bandwidth_range": (2200, 6500),
        "spectral_centroid_range": (3500, 5000),
        "call_duration_range": (0.03, 0.12),
        "pulse_rate_range": (5.0, 10.0),
        "spectral_flatness_range": (0.15, 0.35),
    },

    "barn_owl": {
        "common_name": "Barn Owl",
        "scientific_name": "Tyto alba",
        "sound_description": "Long, harsh, high-pitched screech, very broadband and drawn out.",
        "dominant_frequency_range": (3800, 7500),
        "bandwidth_range": (2800, 8500),
        "spectral_centroid_range": (4200, 7000),
        "call_duration_range": (1.20, 2.50),
        "pulse_rate_range": (0.2, 0.8),
        "spectral_flatness_range": (0.35, 0.65),
    },


    # ======================================================
    # NEW BIRDS
    # ======================================================

    "herring_gull": {
        "common_name": "Herring Gull",
        "scientific_name": "Larus argentatus",
        "sound_description": "Loud, harsh laughing calls and repeated high-pitched cries.",
        "dominant_frequency_range": (900, 2200),
        "bandwidth_range": (600, 3200),
        "spectral_centroid_range": (1100, 2000),
        "call_duration_range": (0.35, 1.20),
        "pulse_rate_range": (0.5, 2.0),
        "spectral_flatness_range": (0.28, 0.52),
    },

    "rock_pigeon": {
        "common_name": "Rock Pigeon",
        "scientific_name": "Columba livia",
        "sound_description": "Low, rhythmic and resonant cooing, often repeated in short phrases.",
        "dominant_frequency_range": (280, 480),
        "bandwidth_range": (220, 600),
        "spectral_centroid_range": (300, 450),
        "call_duration_range": (0.50, 1.10),
        "pulse_rate_range": (0.4, 1.4),
        "spectral_flatness_range": (0.04, 0.14),
    },

    "eurasian_collared_dove": {
        "common_name": "Eurasian Collared Dove",
        "scientific_name": "Streptopelia decaocto",
        "sound_description": "Repeated three-part cooing phrase with a deep, steady tone.",
        "dominant_frequency_range": (500, 780),
        "bandwidth_range": (400, 900),
        "spectral_centroid_range": (550, 760),
        "call_duration_range": (0.55, 1.20),
        "pulse_rate_range": (0.35, 1.1),
        "spectral_flatness_range": (0.03, 0.12),
    },

    "common_myna": {
        "common_name": "Common Myna",
        "scientific_name": "Acridotheres tristis",
        "sound_description": "Loud whistles, harsh calls, chattering, and varied repeated notes.",
        "dominant_frequency_range": (1400, 3200),
        "bandwidth_range": (1000, 4200),
        "spectral_centroid_range": (1700, 3000),
        "call_duration_range": (0.12, 0.60),
        "pulse_rate_range": (1.5, 4.5),
        "spectral_flatness_range": (0.14, 0.34),
    },

    "asian_koel": {
        "common_name": "Asian Koel",
        "scientific_name": "Eudynamys scolopaceus",
        "sound_description": "Loud, clear, rising koo-oo calls repeated in distinctive sequences.",
        "dominant_frequency_range": (700, 1700),
        "bandwidth_range": (550, 2200),
        "spectral_centroid_range": (850, 1500),
        "call_duration_range": (0.45, 1.10),
        "pulse_rate_range": (0.5, 2.0),
        "spectral_flatness_range": (0.05, 0.18),
    },

    "black_drongo": {
        "common_name": "Black Drongo",
        "scientific_name": "Dicrurus macrocercus",
        "sound_description": "Sharp metallic calls with varied whistles and short repeated notes.",
        "dominant_frequency_range": (1600, 3600),
        "bandwidth_range": (1100, 4600),
        "spectral_centroid_range": (1900, 3300),
        "call_duration_range": (0.10, 0.45),
        "pulse_rate_range": (2.0, 5.5),
        "spectral_flatness_range": (0.18, 0.4),
    },

    "common_kingfisher": {
        "common_name": "Common Kingfisher",
        "scientific_name": "Alcedo atthis",
        "sound_description": "High-pitched, sharp whistle or piping call, often given during flight.",
        "dominant_frequency_range": (3400, 5800),
        "bandwidth_range": (2600, 6500),
        "spectral_centroid_range": (3800, 5500),
        "call_duration_range": (0.08, 0.30),
        "pulse_rate_range": (2.5, 6.5),
        "spectral_flatness_range": (0.05, 0.18),
    },

    "coppersmith_barbet": {
        "common_name": "Coppersmith Barbet",
        "scientific_name": "Psilopogon haemacephalus",
        "sound_description": "Repeated metallic tuk-tuk-tuk notes delivered at a regular rhythm.",
        "dominant_frequency_range": (900, 1350),
        "bandwidth_range": (750, 1600),
        "spectral_centroid_range": (950, 1300),
        "call_duration_range": (0.10, 0.30),
        "pulse_rate_range": (2.5, 4.5),
        "spectral_flatness_range": (0.18, 0.38),
    },

    "great_egret": {
        "common_name": "Great Egret",
        "scientific_name": "Ardea alba",
        "sound_description": "Low, rough croaks and harsh squawks, especially near nesting areas.",
        "dominant_frequency_range": (600, 1600),
        "bandwidth_range": (500, 2400),
        "spectral_centroid_range": (700, 1700),
        "call_duration_range": (0.25, 1.00),
        "pulse_rate_range": (0.5, 2.5),
        "spectral_flatness_range": (0.3, 0.55),
    },

    "common_hoopoe": {
        "common_name": "Common Hoopoe",
        "scientific_name": "Upupa epops",
        "sound_description": "Distinctive soft, repeated three-note hooting phrase.",
        "dominant_frequency_range": (380, 900),
        "bandwidth_range": (320, 1100),
        "spectral_centroid_range": (450, 850),
        "call_duration_range": (0.25, 0.70),
        "pulse_rate_range": (1.2, 2.8),
        "spectral_flatness_range": (0.04, 0.14),
    },

    "oriental_magpie_robin": {
        "common_name": "Oriental Magpie-Robin",
        "scientific_name": "Copsychus saularis",
        "sound_description": "Clear, melodic whistles with varied phrases and repeated notes.",
        "dominant_frequency_range": (2000, 3800),
        "bandwidth_range": (1500, 4800),
        "spectral_centroid_range": (2300, 3600),
        "call_duration_range": (0.10, 0.50),
        "pulse_rate_range": (1.8, 4.5),
        "spectral_flatness_range": (0.05, 0.2),
    },

    "common_tailorbird": {
        "common_name": "Common Tailorbird",
        "scientific_name": "Orthotomus sutorius",
        "sound_description": "Loud, sharp and rapidly repeated chee-chip notes.",
        "dominant_frequency_range": (3800, 5800),
        "bandwidth_range": (3000, 6500),
        "spectral_centroid_range": (4000, 5600),
        "call_duration_range": (0.05, 0.20),
        "pulse_rate_range": (4.0, 8.0),
        "spectral_flatness_range": (0.1, 0.26),
    },

    "red_vented_bulbul": {
        "common_name": "Red-vented Bulbul",
        "scientific_name": "Pycnonotus cafer",
        "sound_description": "Variable whistles, chirps and bubbling musical phrases.",
        "dominant_frequency_range": (1700, 3400),
        "bandwidth_range": (1300, 4200),
        "spectral_centroid_range": (1900, 3200),
        "call_duration_range": (0.15, 0.60),
        "pulse_rate_range": (1.2, 4.0),
        "spectral_flatness_range": (0.08, 0.24),
    },

    "white_throated_kingfisher": {
        "common_name": "White-throated Kingfisher",
        "scientific_name": "Halcyon smyrnensis",
        "sound_description": "Loud, harsh rattling calls and energetic repeated vocalizations.",
        "dominant_frequency_range": (1300, 3200),
        "bandwidth_range": (950, 4200),
        "spectral_centroid_range": (1600, 2900),
        "call_duration_range": (0.15, 0.70),
        "pulse_rate_range": (1.5, 4.5),
        "spectral_flatness_range": (0.3, 0.58),
    },

    "house_crow": {
        "common_name": "House Crow",
        "scientific_name": "Corvus splendens",
        "sound_description": "Harsh, nasal cawing calls, usually repeated several times.",
        "dominant_frequency_range": (650, 1600),
        "bandwidth_range": (500, 2600),
        "spectral_centroid_range": (1000, 2700),
        "call_duration_range": (0.15, 0.55),
        "pulse_rate_range": (1.0, 3.8),
        "spectral_flatness_range": (0.30, 0.62),
    },

    "asian_pied_starling": {
        "common_name": "Asian Pied Starling",
        "scientific_name": "Gracupica contra",
        "sound_description": "Loud whistles, chattering phrases and varied metallic notes.",
        "dominant_frequency_range": (1400, 3300),
        "bandwidth_range": (1000, 4300),
        "spectral_centroid_range": (1650, 3000),
        "call_duration_range": (0.12, 0.60),
        "pulse_rate_range": (1.5, 4.2),
        "spectral_flatness_range": (0.14, 0.32),
    },


    # ======================================================
    # NEW BIRDS (SECOND PASS)
    # ======================================================

    "rose_ringed_parakeet": {
        "common_name": "Rose-ringed Parakeet",
        "scientific_name": "Psittacula krameri",
        "sound_description": "Loud, harsh, screeching kee-ak calls, usually given in fast flight.",
        "dominant_frequency_range": (2400, 4400),
        "bandwidth_range": (1900, 5400),
        "spectral_centroid_range": (2700, 4200),
        "call_duration_range": (0.08, 0.22),
        "pulse_rate_range": (4.0, 7.5),
        "spectral_flatness_range": (0.24, 0.44),
    },

    "indian_peafowl": {
        "common_name": "Indian Peafowl",
        "scientific_name": "Pavo cristatus",
        "sound_description": "Loud, far-carrying may-awe scream, low-pitched and drawn out.",
        "dominant_frequency_range": (600, 1300),
        "bandwidth_range": (450, 1900),
        "spectral_centroid_range": (700, 1200),
        "call_duration_range": (0.9, 1.8),
        "pulse_rate_range": (0.2, 0.7),
        "spectral_flatness_range": (0.2, 0.4),
    },

    "jungle_babbler": {
        "common_name": "Jungle Babbler",
        "scientific_name": "Argya striata",
        "sound_description": "Noisy, harsh group chattering, constant overlapping chirring notes.",
        "dominant_frequency_range": (1900, 3400),
        "bandwidth_range": (1400, 4200),
        "spectral_centroid_range": (2100, 3200),
        "call_duration_range": (0.08, 0.28),
        "pulse_rate_range": (5.5, 9.0),
        "spectral_flatness_range": (0.22, 0.42),
    },

    "spotted_dove": {
        "common_name": "Spotted Dove",
        "scientific_name": "Spilopelia chinensis",
        "sound_description": "Soft, bubbling coo-coo-croo repeated in a gentle, unhurried rhythm.",
        "dominant_frequency_range": (450, 700),
        "bandwidth_range": (380, 850),
        "spectral_centroid_range": (500, 680),
        "call_duration_range": (0.3, 0.65),
        "pulse_rate_range": (1.0, 2.0),
        "spectral_flatness_range": (0.03, 0.11),
    },

    "red_wattled_lapwing": {
        "common_name": "Red-wattled Lapwing",
        "scientific_name": "Vanellus indicus",
        "sound_description": "Loud, sharp, piercing did-he-do-it alarm calls given repeatedly.",
        "dominant_frequency_range": (2000, 3700),
        "bandwidth_range": (1500, 4700),
        "spectral_centroid_range": (2300, 3500),
        "call_duration_range": (0.15, 0.4),
        "pulse_rate_range": (2.8, 5.5),
        "spectral_flatness_range": (0.12, 0.28),
    },

    "greater_coucal": {
        "common_name": "Greater Coucal",
        "scientific_name": "Centropus sinensis",
        "sound_description": "Deep, hollow, resonant hoop-hoop-hoop notes at a slow, steady pace.",
        "dominant_frequency_range": (230, 420),
        "bandwidth_range": (180, 520),
        "spectral_centroid_range": (260, 400),
        "call_duration_range": (0.15, 0.35),
        "pulse_rate_range": (1.4, 2.8),
        "spectral_flatness_range": (0.03, 0.1),
    },

    "purple_sunbird": {
        "common_name": "Purple Sunbird",
        "scientific_name": "Cinnyris asiaticus",
        "sound_description": "Thin, sharp, high-pitched chips and rapid twittering song.",
        "dominant_frequency_range": (4600, 6800),
        "bandwidth_range": (3600, 7800),
        "spectral_centroid_range": (5000, 6600),
        "call_duration_range": (0.03, 0.1),
        "pulse_rate_range": (5.5, 9.5),
        "spectral_flatness_range": (0.08, 0.22),
    },

    "white_breasted_waterhen": {
        "common_name": "White-breasted Waterhen",
        "scientific_name": "Amaurornis phoenicurus",
        "sound_description": "Loud, harsh, croaking series of notes, often given at dawn and dusk.",
        "dominant_frequency_range": (750, 1750),
        "bandwidth_range": (600, 2500),
        "spectral_centroid_range": (900, 1650),
        "call_duration_range": (0.2, 0.55),
        "pulse_rate_range": (1.6, 3.4),
        "spectral_flatness_range": (0.26, 0.46),
    },

    "indian_robin": {
        "common_name": "Indian Robin",
        "scientific_name": "Copsychus fulicatus",
        "sound_description": "Pleasant, sharp whistled song delivered in short, clear phrases.",
        "dominant_frequency_range": (2600, 4400),
        "bandwidth_range": (2100, 5200),
        "spectral_centroid_range": (2900, 4100),
        "call_duration_range": (0.12, 0.38),
        "pulse_rate_range": (2.2, 4.4),
        "spectral_flatness_range": (0.08, 0.2),
    },

    "green_bee_eater": {
        "common_name": "Green Bee-eater",
        "scientific_name": "Merops orientalis",
        "sound_description": "Pleasant rolling tree-tree-tree trill, often given in flight.",
        "dominant_frequency_range": (2300, 3700),
        "bandwidth_range": (1800, 4500),
        "spectral_centroid_range": (2500, 3500),
        "call_duration_range": (0.1, 0.3),
        "pulse_rate_range": (3.2, 6.0),
        "spectral_flatness_range": (0.1, 0.24),
    },

}