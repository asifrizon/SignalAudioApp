import numpy as np

from bird_database import BIRD_DATABASE
from bird_classifier import classify_audio


# ==========================================================
# BIRD CALL IDENTIFICATION
#
# Pipeline:
#   1. Short-Time Fourier Transform (STFT)
#   2. Energy-based call/pulse detection
#   3. Per-call feature extraction         <- signal basics, unchanged
#   4. BirdNET species classification      <- was range-based matching
#   5. Segment-by-segment bird identification
#
# Steps 1-3 and 5 are the original DSP pipeline: they detect
# WHEN calls happen and describe their acoustic shape (pitch,
# bandwidth, duration, etc.) for display in the UI. That work
# is preserved as-is.
#
# Step 4 - deciding WHICH species a call belongs to - now
# comes from BirdNET, a pretrained deep-learning model trained
# on millions of real labeled recordings, instead of comparing
# a handful of hand-guessed numeric ranges. BIRD_DATABASE is
# still used, but only to attach a friendly sound_description
# to species BirdNET returns that happen to be in it.
# ==========================================================


# Most songbird / owl vocalizations live in this band.
BIRD_BAND_LOW_HZ = 250
BIRD_BAND_HIGH_HZ = 9000


# ==========================================================
# STFT
# ==========================================================

def _stft(signal, sample_rate, frame_size=1024, hop_size=256):
    """
    Short-Time Fourier Transform.

    Splits the signal into overlapping Hann-windowed frames
    and calculates the FFT magnitude for every frame.
    """

    n = len(signal)

    if n < frame_size:
        signal = np.pad(
            signal,
            (0, frame_size - n)
        )
        n = len(signal)

    window = np.hanning(frame_size)

    num_frames = (
        1
        + (n - frame_size) // hop_size
    )

    indices = (
        np.arange(frame_size)[None, :]
        +
        (
            np.arange(num_frames)
            * hop_size
        )[:, None]
    )

    frames = signal[indices] * window

    spectrogram = np.abs(
        np.fft.rfft(
            frames,
            axis=1
        )
    )

    frequencies = np.fft.rfftfreq(
        frame_size,
        d=1 / sample_rate
    )

    times = (
        np.arange(num_frames)
        * hop_size
        / sample_rate
    )

    return (
        spectrogram,
        frequencies,
        times
    )


# ==========================================================
# FIND CALL SEGMENTS
# ==========================================================

def _find_call_segments(
    frame_energy,
    times,
    min_gap_frames=3
):
    """
    Groups active frames into individual
    bird-call segments.
    """

    active = frame_energy > 0

    segments = []

    start = None
    gap = 0

    for i, is_active in enumerate(active):

        if is_active:

            if start is None:
                start = i

            gap = 0

        elif start is not None:

            gap += 1

            if gap > min_gap_frames:

                end = i - gap

                segments.append(
                    (start, end)
                )

                start = None
                gap = 0

    if start is not None:

        segments.append(
            (
                start,
                len(active) - 1 - gap
            )
        )

    return [
        (
            times[s],
            times[
                min(e, len(times) - 1)
            ]
        )
        for s, e in segments
        if e >= s
    ]


# ==========================================================
# EXTRACT FEATURES
# ==========================================================

def extract_features(signal, sample_rate):
    """
    Runs the STFT + detection pipeline and returns
    aggregate acoustic features describing the bird calls.
    """

    signal = np.asarray(
        signal,
        dtype=np.float64
    )

    if signal.size == 0:
        raise ValueError(
            "Audio signal is empty."
        )

    spectrogram, frequencies, times = _stft(
        signal,
        sample_rate
    )

    band_mask = (
        (frequencies >= BIRD_BAND_LOW_HZ)
        &
        (frequencies <= BIRD_BAND_HIGH_HZ)
    )

    if not np.any(band_mask):
        raise ValueError(
            "Sample rate is too low to analyze bird-range frequencies."
        )

    band_spectrogram = (
        spectrogram[:, band_mask]
    )

    band_frequencies = (
        frequencies[band_mask]
    )

    # ------------------------------------------------------
    # Energy per frame
    # ------------------------------------------------------

    frame_energy_raw = (
        band_spectrogram.sum(axis=1)
    )

    peak_energy = (
        frame_energy_raw.max()
        if frame_energy_raw.size
        else 0.0
    )

    if peak_energy <= 0:
        raise ValueError(
            "No audio energy detected in the bird frequency range."
        )

    # ------------------------------------------------------
    # Detect active bird frames
    # ------------------------------------------------------

    threshold = peak_energy * 0.15

    frame_energy = np.where(
        frame_energy_raw > threshold,
        frame_energy_raw,
        0.0
    )

    active_mask = frame_energy > 0

    if not np.any(active_mask):
        raise ValueError(
            "No bird call detected in this audio clip."
        )

    # ------------------------------------------------------
    # Find call segments
    # ------------------------------------------------------

    segments = _find_call_segments(
        frame_energy,
        times
    )

    if not segments:
        raise ValueError(
            "No bird call detected in this audio clip."
        )

    # ------------------------------------------------------
    # Dominant frequency
    # ------------------------------------------------------

    active_spectrogram = (
        band_spectrogram[active_mask]
    )

    dominant_bins = np.argmax(
        active_spectrogram,
        axis=1
    )

    dominant_frequencies = (
        band_frequencies[dominant_bins]
    )

    dominant_frequency = float(
        np.median(
            dominant_frequencies
        )
    )

    # ------------------------------------------------------
    # Spectral centroid
    # ------------------------------------------------------

    magnitude_sum = (
        active_spectrogram.sum(axis=1)
    )

    magnitude_sum[
        magnitude_sum == 0
    ] = 1e-12

    centroids = (
        active_spectrogram
        @ band_frequencies
    ) / magnitude_sum

    spectral_centroid = float(
        np.mean(centroids)
    )

    # ------------------------------------------------------
    # Bandwidth
    # ------------------------------------------------------

    aggregate_spectrum = (
        active_spectrogram.max(axis=0)
    )

    energy_mask = (
        aggregate_spectrum
        >
        aggregate_spectrum.max() * 0.2
    )

    energetic_frequencies = (
        band_frequencies[energy_mask]
    )

    bandwidth_low = float(
        energetic_frequencies.min()
    )

    bandwidth_high = float(
        energetic_frequencies.max()
    )

    # ------------------------------------------------------
    # Spectral flatness (tonality vs. harshness/broadband)
    #
    # This is the feature that was previously missing.
    # dominant_frequency / spectral_centroid / bandwidth all
    # describe WHERE in the spectrum the energy sits, but say
    # nothing about WHAT KIND of sound it is. A pure whistled
    # note and a harsh broadband screech can share the exact
    # same frequency range and still sound completely
    # different - that difference shows up here.
    #
    # Flatness = geometric_mean(spectrum) / arithmetic_mean(spectrum)
    # per frame, within the bird band:
    #   - near 0.0  -> energy concentrated in a narrow peak
    #                  (clear, pure, whistled, musical calls)
    #   - near 1.0  -> energy spread evenly across frequencies
    #                  (harsh, broadband, screechy, rattling calls)
    # ------------------------------------------------------

    eps = 1e-12

    frame_geometric_mean = np.exp(
        np.mean(
            np.log(active_spectrogram + eps),
            axis=1
        )
    )

    frame_arithmetic_mean = (
        active_spectrogram.mean(axis=1) + eps
    )

    frame_flatness = (
        frame_geometric_mean
        / frame_arithmetic_mean
    )

    spectral_flatness = float(
        np.median(frame_flatness)
    )

    # ------------------------------------------------------
    # Call duration
    # ------------------------------------------------------

    durations = [
        end - start
        for start, end in segments
    ]

    call_duration = float(
        np.mean(durations)
    )

    total_duration = (
        len(signal) / sample_rate
    )

    pulse_rate = (
        len(segments) / total_duration
        if total_duration > 0
        else 0.0
    )

    return {
        "dominant_frequency":
            dominant_frequency,

        "bandwidth_low":
            bandwidth_low,

        "bandwidth_high":
            bandwidth_high,

        "spectral_centroid":
            spectral_centroid,

        "spectral_flatness":
            spectral_flatness,

        "call_duration":
            call_duration,

        "pulse_rate":
            pulse_rate,

        "num_calls_detected":
            len(segments),

        "analyzed_duration":
            total_duration,
    }


# ==========================================================
# RANGE SCORE
# ==========================================================

# ==========================================================
# MANUAL ACOUSTIC MATCH SCORE
# ==========================================================

def _soft_range_score(value, low, high):
    """Smooth similarity to a species reference range."""
    if value is None or high <= low:
        return 0.0
    center = (float(low) + float(high)) / 2.0
    half_width = max((float(high) - float(low)) / 2.0, 1e-9)
    d = abs(float(value) - center) / half_width
    return float(np.clip(np.exp(-0.5 * d * d), 0.0, 1.0))


def _manual_species_score(features, ref):
    """Interpretable DSP similarity score for one database species."""
    scores = {
        "dominant_frequency": _soft_range_score(features.get("dominant_frequency"), *ref["dominant_frequency_range"]),
        "spectral_centroid": _soft_range_score(features.get("spectral_centroid"), *ref["spectral_centroid_range"]),
        "bandwidth_low": _soft_range_score(features.get("bandwidth_low"), *ref["bandwidth_range"]),
        "bandwidth_high": _soft_range_score(features.get("bandwidth_high"), *ref["bandwidth_range"]),
        "call_duration": _soft_range_score(features.get("call_duration"), *ref["call_duration_range"]),
        "pulse_rate": _soft_range_score(features.get("pulse_rate"), *ref["pulse_rate_range"]),
    }
    scores["bandwidth"] = (scores["bandwidth_low"] + scores["bandwidth_high"]) / 2.0
    if "spectral_flatness_range" in ref and features.get("spectral_flatness") is not None:
        scores["spectral_flatness"] = _soft_range_score(features["spectral_flatness"], *ref["spectral_flatness_range"])
    else:
        scores["spectral_flatness"] = 0.0

    weights = {
        "dominant_frequency": 0.28,
        "spectral_centroid": 0.20,
        "bandwidth": 0.16,
        "call_duration": 0.14,
        "pulse_rate": 0.12,
        "spectral_flatness": 0.10,
    }
    return float(np.clip(sum(scores[k] * weights[k] for k in weights) * 100.0, 0.0, 100.0))


def _add_acoustic_scores(detection, features):
    """Attach manual acoustic and hybrid scores to a BirdNET result."""
    species_id = _COMMON_NAME_TO_SPECIES_ID.get(detection["common_name"].lower())
    ref = BIRD_DATABASE.get(species_id) if species_id else None
    birdnet_score = float(detection.get("confidence", 0.0))
    acoustic_score = None
    hybrid_score = birdnet_score
    if ref is not None:
        acoustic_score = round(_manual_species_score(features, ref), 1)
        hybrid_score = round(0.80 * birdnet_score + 0.20 * acoustic_score, 1)
    enriched = _enrich_detection(detection)
    enriched["birdnet_confidence"] = round(birdnet_score, 1)
    enriched["acoustic_match_score"] = acoustic_score
    enriched["hybrid_score"] = round(hybrid_score, 1)
    return enriched


# ==========================================================
# REFERENCE LOOKUP
# ==========================================================

# Reverse lookup so a BirdNET "common_name" (e.g. "American Crow")
# can be matched back to your curated BIRD_DATABASE entry for its
# sound_description, if you happen to have one for that species.
_COMMON_NAME_TO_SPECIES_ID = {
    ref["common_name"].lower(): species_id
    for species_id, ref in BIRD_DATABASE.items()
}


def _enrich_detection(detection):
    """
    Turns a raw BirdNET detection into the same match shape the
    frontend already expects (common_name, scientific_name,
    confidence, sound_description, ...), attaching your curated
    sound_description when the species is one you've written a
    description for, and a generic one otherwise - BirdNET covers
    6,000+ species, far more than any hand-written database will.
    """

    species_id = _COMMON_NAME_TO_SPECIES_ID.get(
        detection["common_name"].lower()
    )

    ref = BIRD_DATABASE.get(species_id) if species_id else None

    return {

        "species_id":
            species_id,

        "common_name":
            detection["common_name"],

        "scientific_name":
            detection["scientific_name"],

        "sound_description":
            ref["sound_description"]
            if ref
            else "",

        "confidence":
            detection["confidence"],

        "start_time":
            detection.get("start_time"),

        "end_time":
            detection.get("end_time"),

        "expected_frequency_range": (
            {
                "low": ref["dominant_frequency_range"][0],
                "high": ref["dominant_frequency_range"][1],
            }
            if ref
            else None
        ),
    }


# ==========================================================
# MATCH SPECIES (BirdNET-backed)
# ==========================================================

def match_species(signal, sample_rate):
    """
    Classifies real audio against BirdNET's trained model and
    returns matches in the same shape the old range-matcher did.
    """

    detections = classify_audio(signal, sample_rate)

    return [
        _enrich_detection(d)
        for d in detections
    ]


def identify_bird(signal, sample_rate):
    """
    Full pipeline for one audio clip.

    Duplicate BirdNET detections for the same species are merged.
    The highest-confidence detection is kept.
    """

    features = extract_features(
        signal,
        sample_rate
    )

    matches = match_species(
        signal,
        sample_rate
    )

    matches = [
        _add_acoustic_scores(detection, features)
        for detection in matches
    ]

    # ------------------------------------------------------
    # Remove duplicate species
    # ------------------------------------------------------
    # BirdNET may return several detections for the same bird.
    # Use common_name as the species identifier because that is
    # the field produced by _enrich_detection().
    # ------------------------------------------------------

    unique_matches = {}

    for match in matches:

        species = match.get("common_name")

        if not species:
            continue

        existing = unique_matches.get(species)

        if (
            existing is None
            or match.get("confidence", 0)
            > existing.get("confidence", 0)
        ):
            unique_matches[species] = match

    # ------------------------------------------------------
    # Sort by confidence
    # ------------------------------------------------------

    matches = sorted(
        unique_matches.values(),
        key=lambda x: x.get("confidence", 0),
        reverse=True
    )

    # ------------------------------------------------------
    # Best match
    # ------------------------------------------------------

    top_match = matches[0] if matches else None

    # Keep the original 40% confidence threshold
    is_confident = (
        top_match is not None
        and top_match.get("confidence", 0) >= 40.0
    )

    return {
        "features": features,

        "matches": matches[:5],

        "best_match":
            top_match
            if is_confident
            else None,

        "species_considered":
            "with other real data",
    }
# ==========================================================
# GET INDIVIDUAL CALL SEGMENTS
# ==========================================================

def get_call_segments(
    signal,
    sample_rate
):
    """
    Detect individual bird-call segments.

    Returns a list containing:

        segment number
        start time
        end time
        start sample
        end sample
    """

    signal = np.asarray(
        signal,
        dtype=np.float64
    )

    if signal.size == 0:
        return []

    spectrogram, frequencies, times = _stft(
        signal,
        sample_rate
    )

    band_mask = (
        (frequencies >= BIRD_BAND_LOW_HZ)
        &
        (frequencies <= BIRD_BAND_HIGH_HZ)
    )

    if not np.any(band_mask):
        return []

    band_spectrogram = (
        spectrogram[:, band_mask]
    )

    frame_energy_raw = (
        band_spectrogram.sum(axis=1)
    )

    if frame_energy_raw.size == 0:
        return []

    peak_energy = (
        frame_energy_raw.max()
    )

    if peak_energy <= 0:
        return []

    # Same threshold used by the existing
    # bird identification pipeline.
    threshold = (
        peak_energy * 0.15
    )

    frame_energy = np.where(
        frame_energy_raw > threshold,
        frame_energy_raw,
        0.0
    )

    segments = _find_call_segments(
        frame_energy,
        times
    )

    # Length of one STFT frame in seconds.
    frame_duration = (
        1024 / sample_rate
    )

    result = []

    for number, (
        start_time,
        end_time
    ) in enumerate(
        segments,
        start=1
    ):

        # Extend the end by one frame so that
        # a single active STFT frame is not
        # turned into a zero-length audio segment.
        actual_end_time = min(
            end_time + frame_duration,
            len(signal) / sample_rate
        )

        start_sample = max(
            0,
            int(
                start_time
                * sample_rate
            )
        )

        end_sample = min(
            len(signal),
            int(
                actual_end_time
                * sample_rate
            )
        )

        # Ignore extremely tiny segments.
        if end_sample <= start_sample:
            continue

        if (
            end_sample - start_sample
            < int(0.02 * sample_rate)
        ):
            continue

        result.append({

            "segment":
                number,

            "start_time":
                float(start_sample / sample_rate),

            "end_time":
                float(end_sample / sample_rate),

            "start_sample":
                start_sample,

            "end_sample":
                end_sample,

            "duration":
                float(
                    (end_sample - start_sample)
                    / sample_rate
                ),
        })

    return result


# ==========================================================
# IDENTIFY EVERY SEGMENT SEPARATELY
# ==========================================================

def identify_bird_segments(
    signal,
    sample_rate
):
    """
    Detect multiple bird-call segments and identify
    each segment independently.

    This is useful when one recording contains
    multiple birds or multiple different calls.

    Each segment is passed through the existing
    identify_bird() pipeline separately.
    """

    signal = np.asarray(
        signal,
        dtype=np.float64
    )

    if signal.size == 0:
        raise ValueError(
            "Audio signal is empty."
        )

    segments = get_call_segments(
        signal,
        sample_rate
    )

    if not segments:
        raise ValueError(
            "No bird call detected in this audio clip."
        )

    # One BirdNET pass over the whole recording - its model
    # expects ~3s windows of context, so re-running it on every
    # short DSP segment individually would starve it of context.
    detections = [
        _enrich_detection(d)
        for d in classify_audio(signal, sample_rate)
    ]

    identified_segments = []

    for segment in segments:

        start_sample = (
            segment["start_sample"]
        )

        end_sample = (
            segment["end_sample"]
        )

        segment_signal = signal[
            start_sample:end_sample
        ]

        # Descriptive DSP stats for this segment - unchanged.
        try:

            segment_features = extract_features(
                segment_signal,
                sample_rate
            )

        except ValueError:

            segment_features = None

        # BirdNET detections whose analysis window overlaps
        # this DSP-detected call segment in time.
        segment_matches = [
            _add_acoustic_scores(d, segment_features)
            for d in detections
            if d["start_time"] < segment["end_time"]
            and d["end_time"] > segment["start_time"]
        ]

        segment_matches = sorted(
            segment_matches,
            key=lambda d: d["confidence"],
            reverse=True
        )

        top_match = (
            segment_matches[0]
            if segment_matches
            else None
        )

        identified_segments.append({

            "segment":
                segment["segment"],

            "start_time":
                segment["start_time"],

            "end_time":
                segment["end_time"],

            "duration":
                segment["duration"],

            "features":
                segment_features,

            "matches":
                segment_matches[:5],

            "best_match":
                top_match,

            "possible_bird":
                (
                    top_match["common_name"]
                    if top_match
                    else None
                ),

            "confidence":
                (
                    top_match["confidence"]
                    if top_match
                    else 0.0
                ),
        })

    return identified_segments