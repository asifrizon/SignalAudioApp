
import numpy as np


# ---------------------------------------------------------
# Heartbeat signal preprocessing
# ---------------------------------------------------------

def remove_dc(signal):
    """
    Remove the DC component from the audio signal.

    Formula:
        x_ac[n] = x[n] - mean(x)
    """
    signal = np.asarray(signal, dtype=np.float64)

    if len(signal) == 0:
        raise ValueError("Audio signal is empty.")

    mean_value = np.mean(signal)

    return signal - mean_value


# ---------------------------------------------------------
# Simple moving-average smoothing
# ---------------------------------------------------------

def moving_average(signal, window_size):
    """
    Smooth the signal using a moving-average filter.
    """

    signal = np.asarray(signal, dtype=np.float64)

    if len(signal) == 0:
        return signal

    window_size = int(window_size)

    if window_size < 1:
        window_size = 1

    if window_size > len(signal):
        window_size = len(signal)

    kernel = np.ones(window_size) / window_size

    return np.convolve(signal, kernel, mode="same")


# ---------------------------------------------------------
# Heartbeat frequency filtering
# ---------------------------------------------------------

def bandpass_heartbeat(signal, sample_rate):
    """
    Keep the main frequency region useful for heartbeat audio.

    This implementation uses FFT masking rather than requiring
    an external signal-processing library.

    Frequencies below 20 Hz and above 200 Hz are removed.
    """

    signal = np.asarray(signal, dtype=np.float64)

    if len(signal) < 4:
        raise ValueError("Audio signal is too short.")

    if sample_rate <= 0:
        raise ValueError("Sample rate must be positive.")

    n = len(signal)

    # FFT
    spectrum = np.fft.rfft(signal)

    # Frequency values for every FFT bin
    frequencies = np.fft.rfftfreq(n, d=1.0 / sample_rate)

    # Keep the main heartbeat/audio region
    mask = (
        (frequencies >= 20.0) &
        (frequencies <= 200.0)
    )

    filtered_spectrum = spectrum * mask

    # Convert back to time domain
    filtered_signal = np.fft.irfft(
        filtered_spectrum,
        n=n
    )

    return filtered_signal


# ---------------------------------------------------------
# Signal envelope
# ---------------------------------------------------------

def calculate_envelope(signal, sample_rate):
    """
    Calculate a smoothed energy envelope.

    First:
        E[n] = x[n]^2

    Then smooth the energy using a moving average.
    """

    signal = np.asarray(signal, dtype=np.float64)

    if len(signal) == 0:
        raise ValueError("Signal is empty.")

    # Signal energy
    energy = signal ** 2

    # Approximately 50 ms smoothing window
    window_size = max(
        1,
        int(0.05 * sample_rate)
    )

    envelope = moving_average(
        energy,
        window_size
    )

    return envelope


# ---------------------------------------------------------
# Heartbeat peak detection
# ---------------------------------------------------------

def detect_heartbeat_peaks(
    envelope,
    sample_rate,
    minimum_bpm=40,
    maximum_bpm=180
):
    """
    Detect heartbeat peaks from the energy envelope.

    minimum_bpm and maximum_bpm are used to determine
    the minimum allowed distance between two beats.
    """

    envelope = np.asarray(
        envelope,
        dtype=np.float64
    )

    if len(envelope) == 0:
        return []

    if sample_rate <= 0:
        raise ValueError("Sample rate must be positive.")

    # Convert maximum possible BPM into minimum
    # time between beats.

    minimum_interval = 60.0 / maximum_bpm

    minimum_distance_samples = max(
        1,
        int(minimum_interval * sample_rate)
    )

    # Adaptive threshold
    mean_energy = np.mean(envelope)
    std_energy = np.std(envelope)
    maximum_energy = np.max(envelope)

    threshold = max(
        mean_energy + 0.5 * std_energy,
        0.15 * maximum_energy
    )

    # Candidate peaks
    candidate_peaks = []

    for i in range(1, len(envelope) - 1):

        if envelope[i] < threshold:
            continue

        # Local maximum
        if (
            envelope[i] >= envelope[i - 1]
            and
            envelope[i] >= envelope[i + 1]
        ):
            candidate_peaks.append(i)

    if not candidate_peaks:
        return []

    # -----------------------------------------------------
    # Enforce minimum distance between heartbeats
    # -----------------------------------------------------

    peaks = []

    for peak in candidate_peaks:

        if not peaks:
            peaks.append(peak)
            continue

        distance = peak - peaks[-1]

        if distance >= minimum_distance_samples:
            peaks.append(peak)

        else:
            # If two peaks are too close, keep the stronger one
            if envelope[peak] > envelope[peaks[-1]]:
                peaks[-1] = peak

    return peaks


# ---------------------------------------------------------
# BPM calculation
# ---------------------------------------------------------

def calculate_bpm(
    peak_indices,
    sample_rate,
    minimum_bpm=40,
    maximum_bpm=180
):
    """
    Calculate BPM from detected heartbeat peaks.

    Formula:

        T = average(beat-to-beat interval)

        BPM = 60 / T
    """

    if sample_rate <= 0:
        raise ValueError("Sample rate must be positive.")

    if len(peak_indices) < 2:
        return None, []

    # Convert sample positions to seconds
    peak_times = np.asarray(
        peak_indices,
        dtype=np.float64
    ) / sample_rate

    # Time between consecutive heartbeats
    intervals = np.diff(peak_times)

    if len(intervals) == 0:
        return None, []

    # Remove intervals that cannot represent
    # the requested BPM range.
    minimum_interval = 60.0 / maximum_bpm
    maximum_interval = 60.0 / minimum_bpm

    valid_intervals = intervals[
        (intervals >= minimum_interval) &
        (intervals <= maximum_interval)
    ]

    if len(valid_intervals) == 0:
        return None, []

    # Average heartbeat period
    average_interval = np.mean(valid_intervals)

    # BPM formula
    bpm = 60.0 / average_interval

    return float(bpm), valid_intervals.tolist()


# ---------------------------------------------------------
# Complete heartbeat analysis
# ---------------------------------------------------------

def analyze_heartbeat(
    signal,
    sample_rate
):
    """
    Complete heartbeat analysis pipeline.

    Processing:

        Audio signal
             ↓
        DC removal
             ↓
        FFT band-pass filtering
             ↓
        Energy envelope
             ↓
        Peak detection
             ↓
        Beat intervals
             ↓
        BPM
    """

    signal = np.asarray(
        signal,
        dtype=np.float64
    )

    if len(signal) == 0:
        raise ValueError("Audio signal is empty.")

    if sample_rate <= 0:
        raise ValueError("Sample rate must be positive.")

    # -----------------------------------------------------
    # 1. Remove DC component
    # -----------------------------------------------------

    ac_signal = remove_dc(signal)

    # -----------------------------------------------------
    # 2. Filter heartbeat frequency region
    # -----------------------------------------------------

    filtered_signal = bandpass_heartbeat(
        ac_signal,
        sample_rate
    )

    # -----------------------------------------------------
    # 3. Calculate heartbeat energy envelope
    # -----------------------------------------------------

    envelope = calculate_envelope(
        filtered_signal,
        sample_rate
    )

    # -----------------------------------------------------
    # 4. Detect heartbeat peaks
    # -----------------------------------------------------

    peak_indices = detect_heartbeat_peaks(
        envelope,
        sample_rate
    )

    # -----------------------------------------------------
    # 5. Calculate BPM
    # -----------------------------------------------------

    bpm, intervals = calculate_bpm(
        peak_indices,
        sample_rate
    )

    # Convert peak positions to seconds
    peak_times = [
        float(index / sample_rate)
        for index in peak_indices
    ]

    # -----------------------------------------------------
    # Additional signal properties
    # -----------------------------------------------------

    duration = len(signal) / sample_rate

    rms = float(
        np.sqrt(np.mean(ac_signal ** 2))
    )

    maximum_amplitude = float(
        np.max(np.abs(ac_signal))
    )

    average_interval = None

    if intervals:
        average_interval = float(
            np.mean(intervals)
        )

    # -----------------------------------------------------
    # Return complete result
    # -----------------------------------------------------

    return {
        "bpm": bpm,

        "number_of_beats": len(peak_indices),

        "beat_times": peak_times,

        "beat_samples": [
            int(index)
            for index in peak_indices
        ],

        "beat_intervals": intervals,

        "average_interval": average_interval,

        "duration": float(duration),

        "sample_rate": int(sample_rate),

        "rms": rms,

        "maximum_amplitude": maximum_amplitude,

        "filtered_signal": filtered_signal.tolist(),

        "envelope": envelope.tolist()
    }

