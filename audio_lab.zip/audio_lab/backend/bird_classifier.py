
import os
import tempfile

import numpy as np
import soundfile as sf

from birdnetlib import Recording
from birdnetlib.analyzer import Analyzer


# ==========================================================
# BIRDNET CLASSIFIER
#
# Wraps Cornell Lab of Ornithology / Chemnitz University's
# pretrained BirdNET deep-learning model, which was trained
# on millions of real, labeled bird recordings covering
# 6,000+ species worldwide.
#
# This is what actually decides WHICH species are in a clip.
# The DSP pipeline in bird_identifier.py (STFT, call-segment
# detection, feature extraction) is still used - it's kept
# for call timing/segmentation and for the descriptive
# acoustic stats shown in the UI - but species identification
# itself now comes from a real trained model instead of
# comparing a handful of hand-guessed numeric ranges.
# ==========================================================


# Loaded once, at import time. Loading the model (~50MB+) on
# every request would make each API call far too slow.
_analyzer = Analyzer()


def classify_audio(signal, sample_rate, min_confidence=0.1):
    """
    Runs BirdNET on raw audio and returns real species
    detections with real, model-derived confidence scores.

    Returns a list of dicts, sorted by confidence descending:
        {
            "common_name": str,
            "scientific_name": str,
            "confidence": float (0-100),
            "start_time": float (seconds),
            "end_time": float (seconds),
        }

    BirdNET internally analyzes audio in ~3 second windows,
    so a clip will typically produce one detection per window
    it appears confidently in, not one detection per syllable.
    """

    signal = np.asarray(signal, dtype=np.float64)

    if signal.size == 0:
        return []

    # birdnetlib reads from a file path, so the in-memory
    # signal is written to a temporary WAV file for it to
    # analyze, then removed once we have the results.
    tmp_path = None

    try:
        with tempfile.NamedTemporaryFile(
            suffix=".wav",
            delete=False
        ) as tmp:
            tmp_path = tmp.name

        sf.write(tmp_path, signal, sample_rate)

        recording = Recording(
            _analyzer,
            tmp_path,
            min_conf=min_confidence,
        )

        recording.analyze()

        detections = [
            {
                "common_name":
                    d["common_name"],

                "scientific_name":
                    d["scientific_name"],

                "confidence":
                    round(d["confidence"] * 100, 1),

                "start_time":
                    float(d["start_time"]),

                "end_time":
                    float(d["end_time"]),
            }
            for d in recording.detections
        ]

    finally:
        if tmp_path and os.path.exists(tmp_path):
            os.remove(tmp_path)

    detections.sort(
        key=lambda d: d["confidence"],
        reverse=True
    )

    return detections
