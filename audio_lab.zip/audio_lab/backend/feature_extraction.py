import numpy as np
import librosa

from voice_stress_analyzer import (
    remove_dc,
    normalize_signal,
    frame_signal,
    detect_voiced_frames,
    calculate_pitch_features,
    calculate_energy_features,
    calculate_jitter,
    calculate_shimmer,
    calculate_tremor_index,
    calculate_pause_ratio,
    calculate_speaking_activity,
    calculate_speaking_rate,
)

# ============================================================
# ML FEATURE EXTRACTION
#
# Builds on the existing rule-based feature set (pitch, jitter,
# shimmer, tremor, energy, pause/speaking activity) and adds
# spectral features a linear rule-based score can't use well:
# MFCCs, spectral centroid, spectral bandwidth, spectral rolloff.
# These capture timbre/voice-quality information (breathiness,
# tension in the vocal tract) that pitch/energy alone miss.
# ============================================================

FRAME_DURATION = 0.03
HOP_DURATION = 0.015


def _rule_based_features(signal, sample_rate):
    """
    Re-run the existing rule-based pipeline's feature extraction
    (not its scoring) to reuse pitch/jitter/shimmer/tremor/pause
    calculations rather than duplicating that logic.
    """

    signal = remove_dc(signal)
    signal = normalize_signal(signal)

    frames = frame_signal(signal, sample_rate, FRAME_DURATION, HOP_DURATION)

    if len(frames) == 0:
        raise ValueError("Could not create audio frames.")

    voiced_frames = detect_voiced_frames(frames)

    pitch_features = calculate_pitch_features(frames, voiced_frames, sample_rate)
    energy_features = calculate_energy_features(frames, voiced_frames)

    jitter_percent = calculate_jitter(pitch_features["pitch_values"])
    shimmer_percent = calculate_shimmer(energy_features["energy_values"])
    tremor_index = calculate_tremor_index(
        pitch_features["pitch_values"],
        frame_rate_hz=1.0 / HOP_DURATION
    )

    pause_ratio = calculate_pause_ratio(voiced_frames, FRAME_DURATION)
    speaking_activity = calculate_speaking_activity(voiced_frames)
    speaking_rate = calculate_speaking_rate(voiced_frames, sample_rate, FRAME_DURATION)

    return {
        "mean_pitch": pitch_features["mean_pitch"],
        "pitch_std": pitch_features["pitch_variation"],
        "min_pitch": pitch_features["min_pitch"],
        "max_pitch": pitch_features["max_pitch"],
        "jitter_percent": jitter_percent,
        "shimmer_percent": shimmer_percent,
        "tremor_index": tremor_index,
        "mean_energy": energy_features["mean_energy"],
        "energy_variation": energy_features["energy_variation"],
        "pause_ratio": pause_ratio,
        "speaking_activity_percent": speaking_activity,
        "speaking_rate_proxy": speaking_rate,
    }


def _spectral_features(signal, sample_rate):
    """
    MFCCs + spectral shape descriptors via librosa. These pick up
    voice-quality changes (vocal tract tension, breathiness) that
    the time-domain rule-based features can't represent.
    """

    signal = np.asarray(signal, dtype=float)

    # librosa needs float32 and a minimum length; guard tiny clips
    if len(signal) < sample_rate * 0.1:
        raise ValueError("Audio clip too short for spectral feature extraction.")

    y = signal.astype(np.float32)

    mfcc = librosa.feature.mfcc(y=y, sr=sample_rate, n_mfcc=13)
    centroid = librosa.feature.spectral_centroid(y=y, sr=sample_rate)
    bandwidth = librosa.feature.spectral_bandwidth(y=y, sr=sample_rate)
    rolloff = librosa.feature.spectral_rolloff(y=y, sr=sample_rate)
    zcr = librosa.feature.zero_crossing_rate(y=y)

    features = {}

    for i in range(mfcc.shape[0]):
        features[f"mfcc{i+1}_mean"] = float(np.mean(mfcc[i]))
        features[f"mfcc{i+1}_std"] = float(np.std(mfcc[i]))

    features["spectral_centroid_mean"] = float(np.mean(centroid))
    features["spectral_centroid_std"] = float(np.std(centroid))
    features["spectral_bandwidth_mean"] = float(np.mean(bandwidth))
    features["spectral_bandwidth_std"] = float(np.std(bandwidth))
    features["spectral_rolloff_mean"] = float(np.mean(rolloff))
    features["spectral_rolloff_std"] = float(np.std(rolloff))
    features["zcr_mean"] = float(np.mean(zcr))

    return features


# Feature order must be identical between training and inference,
# since the model just sees a vector of numbers. We always derive
# it fresh from sorted(dict.keys()) - deterministic because the
# same feature names are always produced, so no caching needed.

def extract_features(signal, sample_rate):
    """
    Returns (feature_vector: np.ndarray, feature_names: list[str])

    feature_vector is what gets fed to the classifier. feature_names
    is returned alongside it so training and prediction can verify
    they agree on column order. The trained model file stores its
    own copy of feature_names (see train_stress_model.py) so
    prediction re-orders to match it exactly, not just to whatever
    this function currently produces.
    """

    rule_feats = _rule_based_features(signal, sample_rate)
    spectral_feats = _spectral_features(signal, sample_rate)

    combined = {**rule_feats, **spectral_feats}

    feature_names = sorted(combined.keys())
    vector = np.array([combined[name] for name in feature_names], dtype=float)

    return vector, feature_names
