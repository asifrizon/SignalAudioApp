"""
Professional acoustic voice-stress analysis.

Important:
    This module estimates acoustic patterns that can be associated with
    vocal stress/arousal. It does NOT diagnose psychological stress,
    anxiety, deception, or a medical condition.

Design goals:
    * robust pitch tracking using Praat/Parselmouth
    * true Praat jitter/shimmer/HNR measurements
    * spectral tension / voice-quality descriptors
    * adaptive voice activity detection
    * robust statistics instead of raw frame averages
    * data-quality/confidence reporting
    * no emotion->stress shortcut and no uncalibrated ML classifier
    * interpretable contributing indicators
"""

from __future__ import annotations

import numpy as np
import librosa
import parselmouth
from parselmouth.praat import call
from scipy import signal as scipy_signal


EPS = 1e-10
MIN_DURATION_SEC = 2.0
MAX_ANALYSIS_SEC = 120.0
FRAME_SEC = 0.025
HOP_SEC = 0.010
PITCH_FLOOR = 60.0
PITCH_CEILING = 500.0


def _finite(values):
    values = np.asarray(values, dtype=float).reshape(-1)
    return values[np.isfinite(values)]


def _robust_median(values, default=0.0):
    values = _finite(values)
    return float(np.median(values)) if values.size else float(default)


def _robust_std(values, default=0.0):
    values = _finite(values)
    return float(1.4826 * np.median(np.abs(values - np.median(values)))) if values.size else float(default)


def _percentile(values, q, default=0.0):
    values = _finite(values)
    return float(np.percentile(values, q)) if values.size else float(default)


def _clip01(x):
    return float(np.clip(x, 0.0, 1.0))


def _scale(value, low, high):
    if high <= low:
        return 0.0
    return _clip01((value - low) / (high - low))


def _voice_level_factor(energy_dbfs):
    """
    Convert absolute recording level into a conservative confidence/gating
    factor.

    The stress indicators are intentionally based mostly on *changes* inside
    the recording, but a very quiet recording should not be allowed to become
    Moderate/High simply because relative changes are large.  This is not
    treated as a stress cue; it is a safeguard against over-scoring quiet
    speech/near-silence.

    Approximate interpretation:
        <= -48 dBFS : very quiet -> strong suppression
        -42 dBFS    : quiet -> noticeable suppression
        -30 dBFS    : usable speech level -> little suppression
        >= -22 dBFS : normal/strong recording -> no suppression
    """
    if energy_dbfs <= -48.0:
        return 0.20
    if energy_dbfs >= -22.0:
        return 1.00
    return 0.20 + 0.80 * _scale(energy_dbfs, -48.0, -22.0)


def _two_sided_scale(value, low, high):
    """Score unusually high or low values, with 0 at the center."""
    if low <= value <= high:
        return 0.0
    if value < low:
        return _clip01((low - value) / max(abs(low), EPS))
    return _clip01((value - high) / max(abs(high), EPS))


def _normalize_audio(signal):
    x = np.asarray(signal, dtype=float).reshape(-1)
    x = x[np.isfinite(x)]
    if x.size == 0:
        raise ValueError("Audio signal is empty.")

    # Remove DC offset but do not peak-normalize. Peak normalization would
    # destroy useful intensity information and make loudness comparisons less
    # meaningful.
    x = x - np.mean(x)
    peak = np.max(np.abs(x))
    if peak < EPS:
        raise ValueError("Audio signal contains no usable acoustic energy.")

    # Prevent pathological integer/full-scale values from dominating the
    # feature calculations while preserving relative dynamics.
    if peak > 1.0:
        x = x / peak
    return x


def _preprocess_for_analysis(x, sr):
    """Gentle speech-band conditioning used only for acoustic analysis."""
    # Speech stress features are most reliable above very low-frequency rumble
    # and below strong ultrasonic/mic noise.
    low = 60.0
    high = min(8000.0, sr * 0.45)
    if high <= low:
        return x

    sos = scipy_signal.butter(4, [low, high], btype="bandpass", fs=sr, output="sos")
    return scipy_signal.sosfiltfilt(sos, x)


def _frame_rms(x, sr):
    frame = max(1, int(FRAME_SEC * sr))
    hop = max(1, int(HOP_SEC * sr))
    if len(x) < frame:
        x = np.pad(x, (0, frame - len(x)))
    rms = librosa.feature.rms(y=x.astype(np.float32), frame_length=frame, hop_length=hop, center=False)[0]
    times = librosa.frames_to_time(np.arange(len(rms)), sr=sr, hop_length=hop, n_fft=frame)
    return rms, times


def _adaptive_voiced_mask(rms, sr):
    """Energy VAD with a relative floor; conservative for background noise."""
    if rms.size == 0:
        return np.array([], dtype=bool)

    floor = _percentile(rms, 20, 0.0)
    upper = _percentile(rms, 85, floor)
    dynamic_floor = floor + 0.18 * max(upper - floor, EPS)
    threshold = max(dynamic_floor, upper * 0.08)

    voiced = rms >= threshold

    # Remove isolated single-frame decisions and bridge tiny gaps.
    kernel = np.ones(3, dtype=int)
    smoothed = np.convolve(voiced.astype(int), kernel, mode="same") >= 2
    return smoothed


def _pitch_measurements(sound):
    pitch = sound.to_pitch_cc(
        time_step=HOP_SEC,
        pitch_floor=PITCH_FLOOR,
        max_number_of_candidates=15,
        very_accurate=True,
        silence_threshold=0.03,
        voicing_threshold=0.45,
        octave_cost=0.01,
        octave_jump_cost=0.35,
        voiced_unvoiced_cost=0.14,
        pitch_ceiling=PITCH_CEILING,
    )
    freq = np.asarray(pitch.selected_array["frequency"], dtype=float)
    freq = freq[np.isfinite(freq) & (freq > 0)]
    return freq


def _praat_voice_quality(sound):
    """True Praat measurements: jitter, shimmer and HNR."""
    duration = sound.duration
    start, end = 0.0, duration
    try:
        point_process = call(
            sound,
            "To PointProcess (periodic, cc)",
            PITCH_FLOOR,
            PITCH_CEILING,
        )

        jitter = float(call(
            point_process,
            "Get jitter (local)",
            start, end,
            0.0001, 0.02,
            1.3,
        ))

        shimmer = float(call(
            [sound, point_process],
            "Get shimmer (local)",
            start, end,
            0.0001, 0.02,
            1.3, 1.6,
        ))
    except Exception:
        jitter = float("nan")
        shimmer = float("nan")

    try:
        harmonicity = sound.to_harmonicity_cc(
            time_step=HOP_SEC,
            minimum_pitch=PITCH_FLOOR,
            silence_threshold=0.1,
            periods_per_window=4.5,
        )
        hnr_values = _finite(harmonicity.values[0])
        hnr_values = hnr_values[np.abs(hnr_values) < 100]
        hnr = _robust_median(hnr_values, 0.0)
    except Exception:
        hnr = 0.0

    return jitter, shimmer, hnr


def _spectral_features(x, sr, voiced_mask=None):
    """Extract robust spectral/voice-quality descriptors from the analysis copy."""
    y = x.astype(np.float32)
    n_fft = 1024 if sr >= 16000 else 512
    hop = max(1, int(HOP_SEC * sr))

    centroid = librosa.feature.spectral_centroid(
        y=y, sr=sr, n_fft=n_fft, hop_length=hop, center=False
    )[0]
    bandwidth = librosa.feature.spectral_bandwidth(
        y=y, sr=sr, n_fft=n_fft, hop_length=hop, center=False
    )[0]
    rolloff = librosa.feature.spectral_rolloff(
        y=y,
        sr=sr,
        roll_percent=0.85,
        n_fft=n_fft,
        hop_length=hop,
        center=False,
    )[0]
    zcr = librosa.feature.zero_crossing_rate(
        y=y, frame_length=n_fft, hop_length=hop, center=False
    )[0]

    mfcc = librosa.feature.mfcc(
        y=y, sr=sr, n_mfcc=13, n_fft=n_fft, hop_length=hop, center=False
    )

    stft_complex = librosa.stft(
        y, n_fft=n_fft, hop_length=hop, center=False
    )
    stft = np.abs(stft_complex) + EPS
    power = stft ** 2

    # All frame-based features must use the same time grid.  Keep a
    # defensive alignment step as a safeguard against version-specific
    # framing differences.
    frame_lengths = [
        len(centroid),
        len(bandwidth),
        len(rolloff),
        len(zcr),
        mfcc.shape[1],
        stft.shape[1],
    ]
    common_frames = min(frame_lengths)

    centroid = centroid[:common_frames]
    bandwidth = bandwidth[:common_frames]
    rolloff = rolloff[:common_frames]
    zcr = zcr[:common_frames]
    mfcc = mfcc[:, :common_frames]
    stft = stft[:, :common_frames]
    power = power[:, :common_frames]

    if voiced_mask is not None:
        use = np.asarray(voiced_mask[:common_frames], dtype=bool)
    else:
        use = np.ones(common_frames, dtype=bool)

    if len(use) != common_frames:
        use = np.ones(common_frames, dtype=bool)

    if not np.any(use):
        use = np.ones(common_frames, dtype=bool)

    freqs = librosa.fft_frequencies(sr=sr, n_fft=n_fft)

    # Spectral tilt in the speech band.
    band = (freqs >= 300) & (freqs <= min(5000, sr * 0.45))
    if np.sum(band) >= 8:
        log_f = np.log10(freqs[band])
        slopes = []
        for col in stft.T:
            log_a = 20 * np.log10(col[band])
            slopes.append(np.polyfit(log_f, log_a, 1)[0])
        spectral_slope = _robust_median(np.asarray(slopes)[use], 0.0)
    else:
        spectral_slope = 0.0

    # Spectral flux: frame-to-frame spectral change. Normalize each frame so
    # microphone distance/loudness has less influence on the descriptor.
    normalized = power / (np.sum(power, axis=0, keepdims=True) + EPS)
    flux = np.sqrt(np.sum(np.diff(normalized, axis=1) ** 2, axis=0))
    flux_use = use[1:] if len(use) == len(flux) + 1 else use[:len(flux)]
    if not np.any(flux_use):
        flux_use = np.ones_like(flux, dtype=bool)

    # Spectral flatness: low = tonal/harmonic, high = broadband/noisy.
    flatness = np.exp(np.mean(np.log(stft), axis=0)) / (
        np.mean(stft, axis=0) + EPS
    )

    return {
        "spectral_centroid_hz": _robust_median(centroid[use]),
        "spectral_bandwidth_hz": _robust_median(bandwidth[use]),
        "spectral_rolloff_hz": _robust_median(rolloff[use]),
        "zero_crossing_rate": _robust_median(zcr[use]),
        "spectral_slope_db_per_octave": spectral_slope,
        "spectral_flux": _robust_median(flux[flux_use]),
        "spectral_flatness": _robust_median(flatness[use]),
        "mfcc1_std": _robust_std(mfcc[0, use]),
        "mfcc2_std": _robust_std(mfcc[1, use]),
        "mfcc3_std": _robust_std(mfcc[2, use]),
    }


def _relative_change(first, last):
    """Stable relative change, with a small denominator floor."""
    first = float(first)
    last = float(last)
    denom = max(abs(first), EPS)
    return float((last - first) / denom)


def _trajectory_features(values, n_segments=5):
    """Describe whether an acoustic measure rises/falls consistently over time."""
    values = _finite(values)
    if values.size < max(10, n_segments * 2):
        return {
            "trend": 0.0,
            "monotonicity": 0.0,
            "segment_cv": 0.0,
        }

    chunks = np.array_split(values, n_segments)
    meds = np.asarray([np.median(c) for c in chunks if len(c)], dtype=float)
    if meds.size < 3:
        return {"trend": 0.0, "monotonicity": 0.0, "segment_cv": 0.0}

    x = np.linspace(0.0, 1.0, meds.size)
    slope = float(np.polyfit(x, meds, 1)[0])
    scale = max(float(np.median(np.abs(meds))), EPS)
    normalized_slope = slope / scale

    diffs = np.diff(meds)
    nonzero = diffs[np.abs(diffs) > EPS]
    if nonzero.size:
        monotonicity = float(abs(np.sum(np.sign(nonzero))) / nonzero.size)
    else:
        monotonicity = 0.0

    segment_cv = float(np.std(meds) / (abs(np.mean(meds)) + EPS))
    return {
        "trend": normalized_slope,
        "monotonicity": monotonicity,
        "segment_cv": segment_cv,
    }


def _temporal_features(voiced_mask, sr):
    """Pause/continuity descriptors from the existing energy VAD."""
    if voiced_mask.size == 0:
        return {
            "pause_count": 0.0,
            "mean_pause_sec": 0.0,
            "long_pause_ratio": 0.0,
            "voiced_run_sec": 0.0,
        }

    mask = voiced_mask.astype(bool)
    changes = np.diff(np.concatenate(([False], mask, [False])).astype(int))
    starts = np.where(changes == 1)[0]
    ends = np.where(changes == -1)[0]

    voiced_runs = (ends - starts) * HOP_SEC
    pause_lengths = []
    for i in range(len(ends) - 1):
        pause_frames = starts[i + 1] - ends[i]
        if pause_frames > 0:
            pause_lengths.append(pause_frames * HOP_SEC)

    pause_lengths = np.asarray(pause_lengths, dtype=float)
    long_pause_ratio = (
        float(np.mean(pause_lengths >= 0.70)) if pause_lengths.size else 0.0
    )

    return {
        "pause_count": float(pause_lengths.size),
        "mean_pause_sec": float(np.median(pause_lengths)) if pause_lengths.size else 0.0,
        "long_pause_ratio": long_pause_ratio,
        "voiced_run_sec": float(np.median(voiced_runs)) if voiced_runs.size else 0.0,
    }


def _within_clip_change(values, split=0.30):
    values = _finite(values)
    if values.size < 10:
        return 0.0
    n = max(4, int(values.size * split))
    first = np.median(values[:n])
    last = np.median(values[-n:])
    return _relative_change(first, last)


def _segment_consistency(values, window=5):
    values = _finite(values)
    if values.size < window * 2:
        return 0.5
    chunks = np.array_split(values, min(window, values.size))
    meds = np.array([np.median(c) for c in chunks if len(c)])
    if len(meds) < 2 or np.median(np.abs(meds)) < EPS:
        return 0.5
    cv = np.std(meds) / (abs(np.mean(meds)) + EPS)
    return float(1.0 / (1.0 + cv))


def _score_indicators(features, changes):
    """Score acoustic activation using multiple complementary cues.

    The score is deliberately based mainly on *within-recording changes*.
    Absolute F0 is only a weak supporting cue because speakers naturally have
    very different baseline pitch ranges.
    """
    # 1) Phonation instability: true Praat measures.
    jitter_score = _scale(features["jitter_percent"], 1.0, 4.0)
    shimmer_score = _scale(features["shimmer_percent"], 4.0, 12.0)
    hnr_score = _scale(16.0 - features["hnr_db"], 0.0, 12.0)

    voice_instability = (
        0.30 * jitter_score +
        0.30 * shimmer_score +
        0.40 * hnr_score
    )

    # 2) Pitch activation: change + range/variability. Absolute pitch is weak.
    pitch_change = _scale(abs(changes["pitch_relative_change"]), 0.08, 0.40)
    pitch_range = features["pitch_range_semitones"]
    pitch_range_score = _scale(pitch_range, 8.0, 24.0)
    pitch_trend = _scale(abs(features["pitch_trend"]), 0.08, 0.35)
    pitch_abs = _scale(features["mean_pitch_hz"], 140.0, 260.0)

    pitch_score = 100 * (
        0.35 * pitch_change +
        0.25 * pitch_range_score +
        0.25 * pitch_trend +
        0.15 * pitch_abs
    )

    # 3) Energy dynamics: use relative change and within-clip variability.
    energy_change = _scale(abs(changes["energy_relative_change"]), 0.12, 0.55)
    energy_cv = _scale(features["energy_cv"], 0.08, 0.35)
    energy_trend = _scale(abs(features["energy_trend"]), 0.08, 0.45)
    energy_score = 100 * (
        0.45 * energy_change +
        0.30 * energy_cv +
        0.25 * energy_trend
    )

    # 4) Spectral tension: several weak descriptors together are more useful
    # than relying on spectral slope alone.
    slope_score = _scale(features["spectral_slope_db_per_octave"], -16.0, -7.0)
    flux_score = _scale(features["spectral_flux"], 0.015, 0.15)
    flatness_score = _scale(features["spectral_flatness"], 0.08, 0.35)
    centroid_score = _scale(features["spectral_centroid_hz"], 1800.0, 4000.0)
    spectral_score = 100 * (
        0.30 * slope_score +
        0.25 * flux_score +
        0.20 * flatness_score +
        0.25 * centroid_score
    )

    # 5) Fragmentation: don't punish ordinary conversational pauses too much.
    pause_score = _scale(features["pause_ratio"], 0.55, 0.85)
    long_pause_score = _scale(features["long_pause_ratio"], 0.15, 0.55)
    fragmentation_score = 100 * (
        0.45 * pause_score +
        0.55 * long_pause_score
    )

    return {
        "pitch": float(np.clip(pitch_score, 0, 100)),
        "voice_instability": float(np.clip(100 * voice_instability, 0, 100)),
        "energy_change": float(np.clip(energy_score, 0, 100)),
        "spectral_tension": float(np.clip(spectral_score, 0, 100)),
        "speech_fragmentation": float(np.clip(fragmentation_score, 0, 100)),
    }


def _quality_score(duration, voiced_ratio, pitch_coverage, jitter, shimmer, hnr):
    duration_score = _clip01((duration - MIN_DURATION_SEC) / 5.0)
    voiced_score = _clip01((voiced_ratio - 0.10) / 0.35)
    pitch_score = _clip01((pitch_coverage - 0.20) / 0.50)
    quality_metrics = []
    if np.isfinite(jitter): quality_metrics.append(1.0)
    if np.isfinite(shimmer): quality_metrics.append(1.0)
    if hnr > 0: quality_metrics.append(_clip01(hnr / 20.0))
    metric_score = np.mean(quality_metrics) if quality_metrics else 0.0
    return float(100 * (0.20 * duration_score + 0.30 * voiced_score + 0.35 * pitch_score + 0.15 * metric_score))


def _level(score):
    # User-facing interpretation of the 0-100 acoustic activation score.
    # 50+ is treated as High so a score such as 56.2 is not displayed as Moderate.
    if score < 35:
        return "Low"
    if score < 50:
        return "Moderate"
    return "High"


def _build_drivers(scores):
    labels = {
        "voice_instability": "Voice instability",
        "pitch": "Pitch activation",
        "energy_change": "Energy change",
        "spectral_tension": "Spectral tension",
        "speech_fragmentation": "Speech fragmentation",
    }
    ranked = sorted(scores.items(), key=lambda item: item[1], reverse=True)
    return [
        {"feature": labels[k], "score": round(float(v), 1)}
        for k, v in ranked[:3]
        if v >= 25
    ]


def analyze_voice_stress(signal, sample_rate):
    """Analyze acoustic stress-related patterns in one speech recording."""
    try:
        sr = int(sample_rate)
    except Exception as exc:
        raise ValueError("Invalid sample rate.") from exc

    if sr < 8000 or sr > 96000:
        raise ValueError("Sample rate should be between 8 kHz and 96 kHz.")

    x = _normalize_audio(signal)
    duration = len(x) / sr
    if duration < MIN_DURATION_SEC:
        raise ValueError(f"Please provide at least {MIN_DURATION_SEC:.0f} seconds of speech for a reliable analysis.")
    if duration > MAX_ANALYSIS_SEC:
        # Keep the first two minutes deterministic and responsive.
        x = x[: int(MAX_ANALYSIS_SEC * sr)]
        duration = MAX_ANALYSIS_SEC

    analysis_signal = _preprocess_for_analysis(x, sr)
    sound = parselmouth.Sound(analysis_signal, sampling_frequency=sr)

    rms, _ = _frame_rms(analysis_signal, sr)
    voiced_mask = _adaptive_voiced_mask(rms, sr)
    voiced_ratio = float(np.mean(voiced_mask)) if voiced_mask.size else 0.0

    if voiced_ratio < 0.08:
        raise ValueError("Very little speech was detected. Use a clearer speech recording with less background noise.")

    pitch_values = _pitch_measurements(sound)
    pitch_coverage = len(pitch_values) / max(1, len(rms))

    jitter, shimmer, hnr = _praat_voice_quality(sound)
    spectral = _spectral_features(analysis_signal, sr, voiced_mask)

    mean_pitch = _robust_median(pitch_values)
    pitch_std = _robust_std(pitch_values)
    pitch_p10 = _percentile(pitch_values, 10)
    pitch_p90 = _percentile(pitch_values, 90)
    pitch_range_semitones = (
        12.0 * np.log2(max(pitch_p90, PITCH_FLOOR) / max(pitch_p10, PITCH_FLOOR))
        if pitch_p10 > 0 and pitch_p90 > 0 else 0.0
    )

    voiced_rms = rms[voiced_mask[: len(rms)]] if len(voiced_mask) == len(rms) else rms
    voiced_rms = _finite(voiced_rms)
    mean_energy = _robust_median(voiced_rms)
    energy_db = 20 * np.log10(max(mean_energy, EPS))
    energy_std = _robust_std(voiced_rms)
    energy_cv = energy_std / max(mean_energy, EPS)
    pause_ratio = float(1.0 - voiced_ratio)

    pitch_change = _within_clip_change(pitch_values)
    energy_change = _within_clip_change(voiced_rms)
    pitch_trajectory = _trajectory_features(pitch_values)
    energy_trajectory = _trajectory_features(voiced_rms)
    temporal = _temporal_features(voiced_mask, sr)

    # Pitch/energy trajectory consistency helps distinguish one isolated burst
    # from a sustained pattern.
    consistency = np.mean([
        _segment_consistency(pitch_values),
        _segment_consistency(voiced_rms),
    ])

    features = {
        "mean_pitch_hz": mean_pitch,
        "pitch_variation_hz": pitch_std,
        "pitch_p10_hz": pitch_p10,
        "pitch_p90_hz": pitch_p90,
        "pitch_range_semitones": float(pitch_range_semitones),
        "pitch_trend": float(pitch_trajectory["trend"]),
        "pitch_monotonicity": float(pitch_trajectory["monotonicity"]),
        "mean_energy": mean_energy,
        "mean_energy_dbfs": energy_db,
        "voice_level_factor": _voice_level_factor(energy_db),
        "energy_variation": energy_std,
        "energy_cv": float(energy_cv),
        "energy_trend": float(energy_trajectory["trend"]),
        "pause_ratio": pause_ratio,
        "voiced_activity_percent": voiced_ratio * 100,
        **temporal,
        "jitter_percent": float(jitter * 100) if np.isfinite(jitter) else 0.0,
        "shimmer_percent": float(shimmer * 100) if np.isfinite(shimmer) else 0.0,
        "hnr_db": float(hnr),
        **spectral,
    }

    changes = {
        "pitch_relative_change": pitch_change,
        "energy_relative_change": energy_change,
    }

    indicator_scores = _score_indicators(features, changes)

    # Balanced multi-cue fusion. No single acoustic feature can determine
    # psychological stress, so isolated pitch, pauses, or voice-quality values
    # should not dominate the result.
    raw_score = (
        0.28 * indicator_scores["voice_instability"] +
        0.28 * indicator_scores["pitch"] +
        0.18 * indicator_scores["energy_change"] +
        0.16 * indicator_scores["spectral_tension"] +
        0.10 * indicator_scores["speech_fragmentation"]
    )

    # IMPORTANT: relative features alone can over-score a very quiet voice.
    # For example, a low-amplitude recording can still have a large relative
    # pitch/energy change and therefore look "Moderate".  Apply an absolute
    # recording-level safeguard before the final consistency adjustment.
    #
    # This does NOT say that "quiet = unstressed".  It says that a recording
    # with insufficient acoustic level should not be assigned a high acoustic
    # activation score from relative fluctuations alone.
    level_factor = _voice_level_factor(features["mean_energy_dbfs"])

    # For quiet speech, cap the contribution of relative fluctuations as well
    # as reducing the final score.  This prevents a very quiet recording from
    # reaching Moderate just because one feature is noisy.
    if level_factor < 0.60:
        quiet_cap = 30.0 + 20.0 * level_factor
        raw_score = min(raw_score * (0.55 + 0.45 * level_factor), quiet_cap)

    # If the evidence is inconsistent, pull the result toward the center
    # rather than pretending the system is certain.
    consistency_factor = 0.70 + 0.30 * consistency
    score = float(np.clip(raw_score * consistency_factor, 0, 100))

    quality = _quality_score(
        duration,
        voiced_ratio,
        pitch_coverage,
        jitter,
        shimmer,
        hnr,
    )

    confidence = float(np.clip(
        0.55 * quality +
        0.25 * pitch_coverage * 100 +
        0.20 * consistency * 100,
        0,
        100,
    ))

    return {
        "stress_score": round(score, 1),
        "stress_level": _level(score),
        "confidence": round(confidence, 1),
        "data_quality": {
            "score": round(quality, 1),
            "duration_seconds": round(duration, 2),
            "speech_activity_percent": round(voiced_ratio * 100, 1),
            "pitch_coverage_percent": round(pitch_coverage * 100, 1),
            "consistency_percent": round(consistency * 100, 1),
        },
        "features": {k: round(float(v), 4) for k, v in features.items()},
        "changes": {k: round(float(v * 100), 2) for k, v in changes.items()},
        "feature_scores": {k: round(float(v), 1) for k, v in indicator_scores.items()},
        "drivers": _build_drivers(indicator_scores),
        "method": (
            "Praat/Parselmouth + librosa acoustic analysis + adaptive VAD + "
            "robust multi-feature scoring + absolute-level safeguard"
        ),
        "warning": (
            "Acoustic voice-stress analysis can identify patterns such as vocal instability, "
            "pitch activation and phonation changes, but these signals are not specific to "
            "psychological stress. Use this as a screening/monitoring aid, not as a diagnosis "
            "or a lie/deception detector. Results are sensitive to microphone quality, illness, "
            "fatigue, emotion, speaking style and background noise. Very quiet "
            "recordings are conservatively down-weighted because relative acoustic "
            "changes can otherwise be exaggerated by low signal levels."
        ),
    }


# Backward-compatible name for the existing backend route.
def analyze_voice_stress_hybrid(signal, sample_rate, *args, **kwargs):
    return analyze_voice_stress(signal, sample_rate)
